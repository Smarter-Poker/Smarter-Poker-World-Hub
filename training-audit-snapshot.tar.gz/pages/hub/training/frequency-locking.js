/**
 * FREQUENCY LOCKING 2.0 — Node-Level Frequency Constraints
 * ═══════════════════════════════════════════════════════════════════════════
 * Lock specific action frequencies at any decision node and see how
 * the rest of the game tree adjusts to maintain equilibrium.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// TRAIN-CSS-TOKENS-BATCH4-19 — hex sweep batch 4: literals routed to --sp-* tokens
// TRAIN-CSS-TOKENS-BATCH6-5 — hex sweep batch 6: extended palette literals routed
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Head from 'next/head';
import { useRouter } from 'next/router';
import useTrainingBus from '../../../src/hooks/useTrainingBus';
import { eventBus, EventType, busEmit } from '../../../src/engine/EventBus';
import { getAuthUser } from '../../../src/lib/authUtils';

// TRAIN-CSS-MOTION-ADOPT-14 — durations routed through MOTION tokens matched to
// --sp-motion-* CSS contract (TRAIN-CSS-MOTION-1). Values kept in seconds (the
// framer-motion contract) while the CSS sweep still collapses them under
// prefers-reduced-motion via the body.world-training override.
const MOTION = { fast: 0.12, standard: 0.2, slow: 0.32, glacial: 0.52 };

// ═══════════════════════════════════════════════════════════════════════════
// DECISION TREE NODES
// ═══════════════════════════════════════════════════════════════════════════

const DEFAULT_TREE = [
  {
    id: 'root',
    label: 'Preflop Decision',
    street: 'preflop',
    actions: [
      { name: 'Raise', freq: 68, locked: false, color: 'var(--sp-accent-red)' },
      { name: 'Call', freq: 18, locked: false, color: 'var(--sp-accent-green)' },
      { name: 'Fold', freq: 14, locked: false, color: 'var(--sp-fg-dim)' },
    ],
  },
  {
    id: 'flop',
    label: 'Flop C-Bet',
    street: 'flop',
    actions: [
      { name: 'Bet 33%', freq: 35, locked: false, color: 'var(--sp-accent-amber)' },
      { name: 'Bet 67%', freq: 20, locked: false, color: 'var(--sp-accent-red)' },
      { name: 'Check', freq: 45, locked: false, color: 'var(--sp-accent-blue)' },
    ],
  },
  {
    id: 'turn',
    label: 'Turn Barrel',
    street: 'turn',
    actions: [
      { name: 'Bet 67%', freq: 38, locked: false, color: 'var(--sp-accent-red)' },
      { name: 'Bet 100%', freq: 12, locked: false, color: 'var(--sp-accent-red)' },
      { name: 'Check', freq: 50, locked: false, color: 'var(--sp-accent-blue)' },
    ],
  },
  {
    id: 'river',
    label: 'River Decision',
    street: 'river',
    actions: [
      { name: 'Value Bet', freq: 30, locked: false, color: 'var(--sp-accent-green)' },
      { name: 'Bluff', freq: 15, locked: false, color: 'var(--sp-accent-red)' },
      { name: 'Check', freq: 55, locked: false, color: 'var(--sp-accent-blue)' },
    ],
  },
];

function rebalanceFrequencies(actions, changedIdx) {
  if (!Array.isArray(actions) || actions.length === 0) return actions || [];
  // Clamp the changed value first
  const clamped = actions.map((a, i) => ({
    ...a,
    freq: Math.max(0, Math.min(100, Number.isFinite(a.freq) ? a.freq : 0)),
  }));
  const locked = clamped.filter((a, i) => a.locked || i === changedIdx);
  const lockedSum = locked.reduce((s, a) => s + a.freq, 0);
  const unlocked = clamped.filter((a, i) => !a.locked && i !== changedIdx);

  if (unlocked.length === 0 || lockedSum >= 100) return clamped;

  const remaining = Math.max(0, 100 - lockedSum);
  const equalShare = remaining / unlocked.length;

  return clamped.map((a, i) => {
    if (a.locked || i === changedIdx) return a;
    return { ...a, freq: Math.max(0, Math.round(equalShare)) };
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// FREQUENCY SLIDER COMPONENT
// ═══════════════════════════════════════════════════════════════════════════

function FreqSlider({ action, onChange, onToggleLock }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 4,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: 2, background: action.color }} />
          <span style={{ fontSize: 12, fontWeight: 600, color: '#e4e6eb' }}>{action.name}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: action.color }}>{action.freq}%</span>
          <button
            onClick={onToggleLock}
            style={{
              padding: '2px 8px',
              borderRadius: 4,
              fontSize: 10,
              fontWeight: 700,
              cursor: 'pointer',
              background: action.locked ? 'rgba(245,158,11,0.15)' : 'rgba(255,255,255,0.04)',
              border: `1px solid ${action.locked ? 'var(--sp-accent-amber)' : 'rgba(255,255,255,0.1)'}`,
              color: action.locked ? 'var(--sp-accent-amber)' : 'var(--sp-fg-dim)',
              letterSpacing: '0.05em',
            }}
          >
            {action.locked ? 'LOCKED' : 'LOCK'}
          </button>
        </div>
      </div>
      <div style={{ position: 'relative' }}>
        <input
          type="range"
          min="0"
          max="100"
          value={action.freq}
          onChange={(e) => onChange(parseInt(e.target.value, 10))}
          style={{ width: '100%', accentColor: action.color }}
        />
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════════════════

export default function FrequencyLockingPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [tree, setTree] = useState(DEFAULT_TREE);
  const [activeNode, setActiveNode] = useState(0);
  const [showImpact, setShowImpact] = useState(false);

  useTrainingBus('frequency-locking');

  useEffect(() => {
    try {
      setUser(getAuthUser());
    } catch (_) { console.warn('[App] Handled exception:', _?.message || _); }
  }, []);

  const handleFreqChange = useCallback((nodeIdx, actionIdx, newFreq) => {
    setTree((prev) => {
      const updated = [...prev];
      const node = { ...updated[nodeIdx] };
      const actions = [...node.actions];
      actions[actionIdx] = { ...actions[actionIdx], freq: newFreq };
      node.actions = rebalanceFrequencies(actions, actionIdx);
      updated[nodeIdx] = node;
      return updated;
    });
  }, []);

  const handleToggleLock = useCallback((nodeIdx, actionIdx) => {
    setTree((prev) => {
      const updated = [...prev];
      const node = { ...updated[nodeIdx] };
      const actions = [...node.actions];
      actions[actionIdx] = { ...actions[actionIdx], locked: !actions[actionIdx].locked };
      node.actions = actions;
      updated[nodeIdx] = node;
      return updated;
    });
  }, []);

  const handleReset = useCallback(() => {
    setTree(DEFAULT_TREE);
    // HARDENED: safe eventBus access
    try {
      eventBus?.emit?.(
        EventType?.SESSION_END || 'session:end',
        { source: 'FrequencyLocking', action: 'reset' },
        'FrequencyLocking'
      );
      eventBus?.emit?.('training:session-complete', {
        game_id: 'frequency-locking',
        accuracy: 100,
        correct_answers: 1,
        total_questions: 1,
        hands_played: 1,
      });
    } catch (e) {
      console.warn('[FreqLocking] EventBus error:', e);
    }
  }, []);

  const lockedCount = tree.reduce((s, n) => s + n.actions.filter((a) => a.locked).length, 0);

  return (
    <>
      <Head>
        <title>Frequency Locking 2.0 | Smarter.Poker</title>
        <meta
          name="description"
          content="Lock action frequencies at decision nodes and see how the game tree adjusts"
        />
      </Head>

      <div
        style={{
          minHeight: '100vh', paddingBottom: 70, width: '100%', maxWidth: '100vw', overflowX: 'hidden', boxSizing: 'border-box',
          background: '#0a0a1a',
          color: '#e4e6eb',
          fontFamily: "'Inter', -apple-system, sans-serif",
        }}
      >
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #3a3b3c' }}>
          <button
            onClick={() => router.back()}
            style={{
              background: 'none',
              border: 'none',
              color: '#b0b3b8',
              fontSize: 14,
              cursor: 'pointer',
              marginBottom: 4,
            }}
          >
            Back to Training
          </button>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <h1
                style={{
                  fontSize: 22,
                  fontWeight: 700,
                  margin: 0,
                  fontFamily: "'Rajdhani', sans-serif",
                }}
              >
                Frequency Locking 2.0
              </h1>
              <p style={{ fontSize: 14, color: '#b0b3b8', margin: '2px 0 0' }}>
                Lock frequencies at nodes — see how the tree adjusts
              </p>
            </div>
            <button
              onClick={handleReset}
              style={{
                padding: '6px 14px',
                borderRadius: 6,
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.1)',
                color: '#b0b3b8',
              }}
            >
              Reset All
            </button>
          </div>
        </div>

        <div style={{ padding: '16px 20px', maxWidth: 900, margin: '0 auto' }}>
          {/* Locked Count */}
          <div
            style={{
              padding: '8px 14px',
              borderRadius: 8,
              marginBottom: 16,
              background: lockedCount > 0 ? 'rgba(245,158,11,0.08)' : 'rgba(255,255,255,0.03)',
              border: `1px solid ${lockedCount > 0 ? 'rgba(245,158,11,0.2)' : 'rgba(255,255,255,0.06)'}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: lockedCount > 0 ? 'var(--sp-accent-amber)' : '#b0b3b8',
              }}
            >
              {lockedCount} node{lockedCount !== 1 ? 's' : ''} locked
            </span>
            <span style={{ fontSize: 11, color: '#b0b3b8' }}>
              Unlocked nodes auto-rebalance to 100%
            </span>
          </div>

          {/* Decision Tree Visual */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto' }}>
            {tree.map((node, i) => (
              <button
                key={node.id}
                onClick={() => setActiveNode(i)}
                style={{
                  minWidth: 90,
                  padding: '10px 14px',
                  borderRadius: 8,
                  cursor: 'pointer',
                  textAlign: 'center',
                  background: activeNode === i ? 'rgba(99,102,241,0.12)' : 'rgba(255,255,255,0.03)',
                  border: `2px solid ${activeNode === i ? 'var(--sp-accent-blue)' : 'rgba(255,255,255,0.06)'}`,
                }}
              >
                <div
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    color: activeNode === i ? 'var(--sp-accent-blue)' : 'var(--sp-fg-dim)',
                    letterSpacing: '0.1em',
                    marginBottom: 4,
                  }}
                >
                  {node.street.toUpperCase()}
                </div>
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 600,
                    color: activeNode === i ? '#e4e6eb' : '#b0b3b8',
                  }}
                >
                  {node.label}
                </div>
                {node.actions.some((a) => a.locked) && (
                  <div style={{ fontSize: 9, color: 'var(--sp-accent-amber)', marginTop: 4 }}>LOCKED</div>
                )}
              </button>
            ))}
          </div>

          {/* Active Node Editor */}
          <div
            style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(99,102,241,0.15)',
              borderRadius: 12,
              padding: 20,
              marginBottom: 16,
            }}
          >
            <h3
              style={{
                fontSize: 15,
                fontWeight: 700,
                color: '#e4e6eb',
                margin: '0 0 16px',
                fontFamily: "'Rajdhani', sans-serif",
              }}
            >
              {tree[activeNode].label}
            </h3>

            {tree[activeNode].actions.map((action, i) => (
              <FreqSlider
                key={`${activeNode}-${i}`}
                action={action}
                onChange={(val) => handleFreqChange(activeNode, i, val)}
                onToggleLock={() => handleToggleLock(activeNode, i)}
              />
            ))}

            {/* Frequency Bar Visualization */}
            <div
              style={{
                display: 'flex',
                height: 24,
                borderRadius: 6,
                overflow: 'hidden',
                marginTop: 12,
              }}
            >
              {tree[activeNode].actions.map((a, i) => (
                <motion.div
                  key={i}
                  animate={{ width: `${a.freq}%` }}
                  transition={{ duration: MOTION.standard }}
                  style={{
                    background: a.color,
                    height: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {a.freq > 10 && (
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#000' }}>{a.freq}%</span>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Impact Analysis Toggle */}
          <button
            onClick={() => setShowImpact(!showImpact)}
            style={{
              width: '100%',
              padding: '14px',
              borderRadius: 10,
              cursor: 'pointer',
              background: 'linear-gradient(135deg, rgba(99,102,241,0.1), rgba(139,92,246,0.06))',
              border: '1px solid rgba(99,102,241,0.2)',
              fontSize: 14,
              fontWeight: 700,
              color: 'var(--sp-accent-blue)',
              fontFamily: "'Rajdhani', sans-serif",
              letterSpacing: '0.08em',
            }}
          >
            {showImpact ? 'HIDE' : 'SHOW'} TREE IMPACT ANALYSIS
          </button>

          <AnimatePresence>
            {showImpact && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                style={{ overflow: 'hidden' }}
              >
                <div
                  style={{
                    marginTop: 12,
                    background: 'rgba(99,102,241,0.04)',
                    border: '1px solid rgba(99,102,241,0.15)',
                    borderRadius: 10,
                    padding: 16,
                  }}
                >
                  <h4
                    style={{
                      fontSize: 13,
                      fontWeight: 700,
                      color: 'var(--sp-accent-blue)',
                      margin: '0 0 12px',
                      letterSpacing: '0.08em',
                    }}
                  >
                    FREQUENCY LOCK IMPACT ACROSS STREETS
                  </h4>
                  {tree.map((node, i) => {
                    const hasLocked = node.actions.some((a) => a.locked);
                    const deviation = node.actions.reduce((sum, a) => {
                      const gto = DEFAULT_TREE[i].actions.find((d) => d.name === a.name);
                      return sum + Math.abs(a.freq - (gto?.freq || 0));
                    }, 0);
                    return (
                      <div
                        key={node.id}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          padding: '8px 12px',
                          marginBottom: 6,
                          borderRadius: 6,
                          background: hasLocked ? 'rgba(245,158,11,0.06)' : 'rgba(0,0,0,0.15)',
                          borderLeft: `3px solid ${hasLocked ? 'var(--sp-accent-amber)' : '#3a3b3c'}`,
                        }}
                      >
                        <span style={{ fontSize: 12, fontWeight: 600, color: '#e4e6eb' }}>
                          {node.label}
                        </span>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                          <span
                            style={{
                              fontSize: 12,
                              fontWeight: 700,
                              color:
                                deviation > 20 ? 'var(--sp-accent-red)' : deviation > 5 ? 'var(--sp-accent-amber)' : 'var(--sp-accent-green)',
                            }}
                          >
                            {deviation > 0 ? `${(Number.isFinite(Number(deviation)) ? Number(deviation) : 0).toFixed(0)}% deviation` : 'Balanced'}
                          </span>
                          {hasLocked && (
                            <span
                              style={{
                                fontSize: 10,
                                fontWeight: 700,
                                color: 'var(--sp-accent-amber)',
                                padding: '1px 6px',
                                background: 'rgba(245,158,11,0.15)',
                                borderRadius: 3,
                              }}
                            >
                              LOCKED
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
}