/**
 * 🏥 TRAINING CLINICS — 28 Specialized Leak-Fixing Drills
 * ═══════════════════════════════════════════════════════════════════════════
 * From the GTO Training Engine Blueprint:
 * - Each clinic targets a specific leak category
 * - 10-level progressive difficulty
 * - 2.5x diamond multiplier for remediation mode
 * - Awards badges on completion
 * ═══════════════════════════════════════════════════════════════════════════
 */

// Clinic categories map to leak detection categories
export const LEAK_CATEGORY_MAP = {
    FOLD_TO_AGGRESSION: 'clinic-01',
    CBET_DEFENSE: 'clinic-05',
    THIN_VALUE: 'clinic-02',
    BLUFF_FREQUENCY: 'clinic-03',
    POSITION_AWARENESS: 'clinic-04',
    ICM_AWARENESS: 'clinic-13',
    TIMING_TELLS: 'clinic-06',
    TILT_PLAY: 'clinic-07'
};

// Full 28 Training Clinics from the Blueprint
export const TRAINING_CLINICS = [
    // ═══════════════════════════════════════════════════════════════════════
    // DEFENSE CLINICS (1-4)
    // ═══════════════════════════════════════════════════════════════════════
    {
        id: 'clinic-01',
        name: 'The Iron Wall',
        title: 'Defending the Big-Blind',
        subtitle: 'Clinic #1: Defense',
        category: 'DEFENSE',
        targetLeak: 'FOLD_TO_AGGRESSION',
        description: 'Stop Folding Bottom-of-range Winners Against Aggressive Opponents',
        icon: '🛡️',
        badge: 'Iron Wall Master',
        laws: [8, 9], // Stack Awareness, Bully Archetype
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        villainArchetype: 'BULLY',
        visualEffects: ['VILLAIN_SCALE_1.4x', 'INTIMIDATION_GLOW'],
        startingState: {
            heroCards: ['Ks', 'Qc'],
            villainCards: ['??', '??'],
            board: [],
            pot: 5.5,
            dealerBtn: 'villain',
            heroStack: 40,
            villainStack: 40,
            // Data-Driven GameLoop fields
            topology: 9,              // 9-max table
            buttonPosition: 6,        // BTN at seat 6
            heroPosition: 'BB',       // Hero in Big-Blind
            effectiveStacks: {
                hero: 40,
                villains: [45, 38, 52, 40, 35, 40, 42]  // UTG→SB stacks
            },
            actionHistory: [
                { seat: 0, position: 'UTG', action: 'fold' },
                { seat: 1, position: 'UTG+1', action: 'fold' },
                { seat: 2, position: 'MP', action: 'fold' },
                { seat: 3, position: 'MP+1', action: 'fold' },
                { seat: 4, position: 'CO', action: 'fold' },
                { seat: 5, position: 'BTN', action: 'raise', amount: 2.5 }
            ]
        },
        questions: [
            {
                id: 'q1',
                street: 'preflop',
                villainAction: 'Raises to 2.5BB',
                correctAction: 'call',
                explanation: 'With KQo, you are getting the right price to call and realize equity against a wide button range.'
            }
        ]
    },
    {
        id: 'clinic-02',
        name: 'The Value Extractor',
        title: 'Thin Value Betting',
        subtitle: 'Clinic #2: Sizing',
        category: 'SIZING',
        targetLeak: 'THIN_VALUE',
        description: 'Maximize EV with Strong Holdings Through Precise Bet Sizing',
        icon: '💎',
        badge: 'Value Assassin',
        laws: [6], // Physical Slider
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        requiresSlider: true,
        visualEffects: ['SIZING_GLOW', 'EV_METER'],
        startingState: {
            heroCards: ['As', 'Jh'],
            villainCards: ['??', '??'],
            board: ['Ah', '9c', '4d', '2s', '7h'],
            pot: 45,
            dealerBtn: 'hero',
            heroStack: 60,
            villainStack: 55,
            // Data-Driven GameLoop fields
            topology: 6,              // 6-max table
            buttonPosition: 3,        // BTN at seat 3 (hero)
            heroPosition: 'BTN',      // Hero on Button
            effectiveStacks: {
                hero: 60,
                villains: [55, 48, 62, 45]  // UTG→BB stacks (excluding hero)
            },
            actionHistory: [
                { seat: 0, position: 'UTG', action: 'fold' },
                { seat: 1, position: 'MP', action: 'call', amount: 2 },
                { seat: 2, position: 'CO', action: 'fold' }
                // Hero acts next from BTN
            ]
        },
        questions: [
            {
                id: 'q1',
                street: 'river',
                villainAction: 'Checks',
                correctAction: 'raise',
                explanation: 'With top pair on a dry board, you should bet for thin value. Villain will call with worse Ax hands.'
            }
        ]
    },
    {
        id: 'clinic-03',
        name: 'The Indifference',
        title: 'Minimum Defense Frequency',
        subtitle: 'Clinic #3: Defense Math',
        category: 'DEFENSE',
        targetLeak: 'BLUFF_FREQUENCY',
        description: 'Master Minimum Defense Frequency (MDF) to Prevent Profitable Villain Bluffs',
        icon: '⚖️',
        badge: 'MDF Master',
        laws: [9], // River Pressure
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        focusStreet: 'RIVER',
        visualEffects: ['LARGE_POT_1.5x', 'MATH_OVERLAY'],
        startingState: {
            heroCards: ['Kd', 'Qd'],
            villainCards: ['??', '??'],
            board: ['Ac', 'Jh', '7s', '3c', '2d'],
            pot: 80,
            dealerBtn: 'villain',
            heroStack: 45,
            villainStack: 50,
            // Data-Driven GameLoop fields
            topology: 6,              // 6-max table
            buttonPosition: 4,        // BTN at seat 4
            heroPosition: 'BB',       // Hero in Big-Blind
            effectiveStacks: {
                hero: 45,
                villains: [50, 42, 55, 38]  // UTG→SB stacks
            },
            actionHistory: [
                { seat: 0, position: 'UTG', action: 'fold' },
                { seat: 1, position: 'MP', action: 'fold' },
                { seat: 2, position: 'CO', action: 'fold' },
                { seat: 3, position: 'BTN', action: 'raise', amount: 3 },
                { seat: 4, position: 'SB', action: 'fold' }
                // Hero acts next from BB
            ]
        },
        questions: [
            {
                id: 'q1',
                street: 'river',
                villainAction: 'Bets 60BB (Pot-sized)',
                correctAction: 'call',
                explanation: 'Villain is betting pot, so you need to defend 50% of your range (MDF). KQ high is a bluff-catcher that should call.'
            }
        ]
    },
    {
        id: 'clinic-04',
        name: 'The Positional Blitz',
        title: 'Position Awareness Drill',
        subtitle: 'Clinic #4: Seat Mastery',
        category: 'POSITION',
        targetLeak: 'POSITION_AWARENESS',
        description: 'Train Seat-relative Range Mastery Through Rapid-fire Drills',
        icon: '🔄',
        badge: 'Position Master',
        laws: [2, 3], // Table Re-orient, Button Motion
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        timeLimit: 2, // Blitz mode: 2 seconds
        visualEffects: ['BUTTON_ROTATION', 'SEAT_HIGHLIGHT'],
        startingState: {
            heroCards: ['Ts', '9s'],
            villainCards: ['??', '??'],
            board: [],
            pot: 3.5,
            dealerBtn: 'hero',
            heroStack: 40,
            villainStack: 40,
            // Data-Driven GameLoop fields
            topology: 9,              // 9-max for position training
            buttonPosition: 5,        // BTN at seat 5 (hero)
            heroPosition: 'BTN',      // Hero on Button
            effectiveStacks: {
                hero: 40,
                villains: [50, 45, 38, 42, 55, 48, 40]  // UTG→BB stacks
            },
            actionHistory: [
                { seat: 0, position: 'UTG', action: 'raise', amount: 3 }
                // Hero acts next from BTN facing UTG open
            ]
        },
        questions: [
            {
                id: 'q1',
                street: 'preflop',
                villainAction: 'Raises to 3BB from UTG',
                correctAction: 'fold',
                explanation: 'T9s is too weak to call a UTG raise when out of position. Fold and wait for a better spot.'
            }
        ]
    },

    // ═══════════════════════════════════════════════════════════════════════
    // STRATEGY CLINICS (5-8)
    // ═══════════════════════════════════════════════════════════════════════
    {
        id: 'clinic-05',
        name: 'The C-Bet Clinic',
        subtitle: 'Clinic #5: Strategic Logic',
        category: 'STRATEGY',
        targetLeak: 'CBET_DEFENSE',
        description: 'Master Continuation Betting Logic by Identifying Range vs Nut Advantage',
        icon: '💥',
        badge: 'C-Bet Pro',
        laws: [10], // Concept Mastery
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        boardTypes: ['HIGH_DRY', 'HIGH_WET', 'MIDDLE', 'LOW_CONNECTED'],
        visualEffects: ['BOARD_ANALYZER', 'RANGE_ADVANTAGE_GLOW']
    },
    {
        id: 'clinic-06',
        name: 'The Metronome',
        subtitle: 'Clinic #6: Timing Discipline',
        category: 'PSYCHOLOGY',
        targetLeak: 'TIMING_TELLS',
        description: 'Eliminate Timing Tells by Enforcing Consistent Action-rhythm',
        icon: '⏱️',
        badge: 'Rhythm Master',
        laws: [9], // Visual Rhythm
        difficulty: 2,
        levels: 10,
        passThreshold: 85,
        detectsSnapActions: true,
        detectsTanking: true,
        visualEffects: ['SAFE_ZONE_PULSE', 'RHYTHM_GLOW']
    },
    {
        id: 'clinic-07',
        name: 'The Cooler Cage',
        subtitle: 'Clinic #7: Tilt Resistance',
        category: 'PSYCHOLOGY',
        targetLeak: 'TILT_PLAY',
        description: 'Test Emotional Discipline Through Deliberate Bad-beat Sequences',
        icon: '🧊',
        badge: 'Ice Master',
        laws: [9], // Immersion
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        inducedBadBeats: true,
        testHandAfterCooler: true,
        visualEffects: ['SOUL_CRUSH', 'TILT_DETECTOR']
    },
    {
        id: 'clinic-08',
        name: 'The Reviewer',
        subtitle: 'Clinic #8: Result Bias',
        category: 'PSYCHOLOGY',
        targetLeak: 'RESULT_BIAS',
        description: 'Separate Decision Quality From Outcome Through Self-assessment',
        icon: '🔍',
        badge: 'Clear Thinker',
        laws: [10], // Feedback
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        requiresSelfGrade: true,
        visualEffects: ['GRADE_CARD', 'REVEAL_TRUTH']
    },

    // ═══════════════════════════════════════════════════════════════════════
    // ADVANCED CLINICS (9-12)
    // ═══════════════════════════════════════════════════════════════════════
    {
        id: 'clinic-09',
        name: 'Context Switcher',
        subtitle: 'Clinic #9: Agility',
        category: 'ADVANCED',
        targetLeak: 'CONTEXT_ADAPTATION',
        description: 'Adapt to Switching Table Types and Stack Depths Mid-session',
        icon: '⚡',
        badge: 'Agility Master',
        laws: [2], // Instant Orientation
        difficulty: 5,
        levels: 10,
        passThreshold: 100, // Fail-on-First
        switchesTableTypes: true,
        tableTypes: ['HU', '6MAX', 'FULL_RING'],
        visualEffects: ['TABLE_MORPH', 'STACK_SHIFT']
    },
    {
        id: 'clinic-10',
        name: 'Exploitative Deviation',
        subtitle: 'Clinic #10: Exploit',
        category: 'ADVANCED',
        targetLeak: 'MISSED_EXPLOIT',
        description: 'Punish Non-GTO Opponents by Identifying Villain Leaks',
        icon: '🎣',
        badge: 'Exploit Hunter',
        laws: [9], // Villain Immersion
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        villainArchetypes: ['NIT', 'STATION', 'LAG', 'PASSIVE'],
        rewardsMaxEVAdjustment: true,
        visualEffects: ['VILLAIN_PROFILE', 'LEAK_HIGHLIGHT']
    },
    {
        id: 'clinic-11',
        name: 'Capped Range Defense',
        subtitle: 'Clinic #11: Capped',
        category: 'ADVANCED',
        targetLeak: 'CAPPED_FOLDING',
        description: 'Stop Folding When Your Range is Condensed Due to Pre-flop Calling',
        icon: '📦',
        badge: 'Range Defender',
        laws: [9], // Danger Immersion
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        targetDefendPercent: 35,
        visualEffects: ['RED_BORDER_DANGER', 'CAPPED_WARNING']
    },
    {
        id: 'clinic-12',
        name: 'Asymmetric Stack',
        subtitle: 'Clinic #12: Stack Math',
        category: 'ADVANCED',
        targetLeak: 'EFFECTIVE_STACK',
        description: 'Master Effective Stack Math and Price-commitment Thresholds',
        icon: '📐',
        badge: 'Stack Mathematician',
        laws: [8], // Effective Stack Math
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        autoCallThreshold: 15, // ≤15BB
        visualEffects: ['EFFECTIVE_STACK_GLOW', 'COMMIT_WARNING']
    },

    // ═══════════════════════════════════════════════════════════════════════
    // MTT CLINICS (13-18)
    // ═══════════════════════════════════════════════════════════════════════
    {
        id: 'clinic-13',
        name: 'Tournament World',
        title: 'ICM Fundamentals',
        subtitle: 'Clinic #13: MTT',
        category: 'MTT',
        targetLeak: 'ICM_AWARENESS',
        description: 'Comprehensive 150-level Tournament Engine: Push/Fold, ICM, ChipEV',
        icon: '🏆',
        badge: 'Tournament Master',
        laws: [3, 8, 9], // Button Rotation, Adaptive Difficulty, Environmental Pulse
        difficulty: 4,
        levels: 150,
        passThreshold: 85,
        modes: ['PUSH_FOLD', 'ICM', 'CHIP_EV'],
        visualEffects: ['MODE_SPECIFIC_GLOW', 'BUTTON_ROTATION'],
        startingState: {
            heroCards: ['Ah', 'Ks'],
            villainCards: ['??', '??'],
            board: [],
            pot: 4.5,
            dealerBtn: 'villain',
            heroStack: 15,
            villainStack: 25,
            // Data-Driven GameLoop fields
            topology: 9,              // 9-max MTT table
            buttonPosition: 4,        // BTN at seat 4
            heroPosition: 'BTN',      // Hero on Button
            effectiveStacks: {
                hero: 15,
                villains: [25, 18, 32, 12, 45, 22, 28]  // UTG→BB stacks
            },
            actionHistory: [
                { seat: 0, position: 'UTG', action: 'fold' },
                { seat: 1, position: 'UTG+1', action: 'fold' },
                { seat: 2, position: 'MP', action: 'fold' },
                { seat: 3, position: 'CO', action: 'raise', amount: 2.5 }
                // Hero acts next from BTN facing CO open
            ]
        },
        // Level 1 Questions (20) - ICM Fundamentals
        levels: [
            {
                level: 1,
                name: 'ICM Basics',
                passThreshold: 85,
                questions: [
                    { id: 'L1Q01', heroCards: ['Ah', 'Ks'], position: 'BTN', stackDepth: 15, villainAction: 'Shoves All-In (25BB)', correctAction: 'call', lawId: 'LAW_07', explanation: 'AKs vs wide shove = call. ICM adjusted, you have 45% equity.' },
                    { id: 'L1Q02', heroCards: ['Ah', 'Ks'], position: 'BTN', stackDepth: 15, villainAction: 'Raises to 2.5BB', correctAction: 'raise', lawId: 'LAW_06', explanation: '3-bet for value with AKs. Denies equity from worse hands.' },
                    { id: 'L1Q03', heroCards: ['Ah', 'Ks'], position: 'BB', stackDepth: 15, villainAction: 'Limps', correctAction: 'raise', lawId: 'LAW_03', explanation: 'Isolate the limper. Premium hand + position = raise.' },
                    { id: 'L1Q04', heroCards: ['Qs', 'Qh'], position: 'CO', stackDepth: 20, villainAction: 'Shoves All-In (12BB)', correctAction: 'call', lawId: 'LAW_07', explanation: 'QQ vs 12BB shove is a snap call. You dominate most shoving ranges.' },
                    { id: 'L1Q05', heroCards: ['Jc', 'Jd'], position: 'BB', stackDepth: 10, villainAction: 'Shoves All-In (15BB)', correctAction: 'call', lawId: 'LAW_07', explanation: 'JJ with 10BB effective = call. You are ahead of villain range.' },
                    { id: 'L1Q06', heroCards: ['As', 'Qc'], position: 'BTN', stackDepth: 18, villainAction: 'Raises to 3BB', correctAction: 'raise', lawId: 'LAW_06', explanation: 'AQo in position vs open = 3-bet for value and position.' },
                    { id: 'L1Q07', heroCards: ['Kh', 'Qh'], position: 'SB', stackDepth: 12, villainAction: 'Folds to You', correctAction: 'raise', lawId: 'LAW_01', explanation: 'KQs in SB = steal the blinds. Fold equity + equity when called.' },
                    { id: 'L1Q08', heroCards: ['Ts', 'Tc'], position: 'CO', stackDepth: 25, villainAction: '3-Bets to 9BB', correctAction: 'call', lawId: 'LAW_08', explanation: 'TT vs 3-bet = call with deep stacks. Set mining + implied odds.' },
                    { id: 'L1Q09', heroCards: ['9h', '9c'], position: 'BTN', stackDepth: 8, villainAction: 'Folds to You', correctAction: 'raise', lawId: 'LAW_01', explanation: 'With 8BB and 99, shove for fold equity. Push/fold territory.' },
                    { id: 'L1Q10', heroCards: ['As', 'Js'], position: 'BB', stackDepth: 20, villainAction: 'Raises to 2.2BB', correctAction: 'call', lawId: 'LAW_03', explanation: 'AJs defends well OOP. Can call or 3-bet, calling is fine.' },
                    { id: 'L1Q11', heroCards: ['Kc', 'Jc'], position: 'BTN', stackDepth: 30, villainAction: 'Min-raises to 2BB', correctAction: 'raise', lawId: 'LAW_06', explanation: 'KJs vs min-raise in position = 3-bet for value and position.' },
                    { id: 'L1Q12', heroCards: ['8h', '8d'], position: 'CO', stackDepth: 15, villainAction: 'Shoves All-In (10BB)', correctAction: 'call', lawId: 'LAW_07', explanation: '88 vs short stack shove = call. Flipping at worst, often ahead.' },
                    { id: 'L1Q13', heroCards: ['Ac', '5c'], position: 'BTN', stackDepth: 10, villainAction: 'Folds to You', correctAction: 'raise', lawId: 'LAW_01', explanation: 'A5s with 10BB = shove. Good blockers and fold equity.' },
                    { id: 'L1Q14', heroCards: ['Kh', 'Ts'], position: 'SB', stackDepth: 20, villainAction: 'BB Only', correctAction: 'raise', lawId: 'LAW_01', explanation: 'KTo in SB vs BB only = steal. Wide stealing range here.' },
                    { id: 'L1Q15', heroCards: ['7s', '7c'], position: 'BB', stackDepth: 22, villainAction: 'Raises to 2.5BB', correctAction: 'call', lawId: 'LAW_08', explanation: '77 in BB vs raise = call. Set mining with good odds.' },
                    { id: 'L1Q16', heroCards: ['Ad', 'Td'], position: 'CO', stackDepth: 18, villainAction: 'Folds to You', correctAction: 'raise', lawId: 'LAW_06', explanation: 'ATs in CO = standard open. Premium suited broadway.' },
                    { id: 'L1Q17', heroCards: ['6c', '6h'], position: 'BTN', stackDepth: 6, villainAction: 'Folds to You', correctAction: 'raise', lawId: 'LAW_01', explanation: '66 with 6BB = push. Any pair in push/fold zone is a shove.' },
                    { id: 'L1Q18', heroCards: ['Ks', 'Qs'], position: 'BB', stackDepth: 14, villainAction: 'Shoves All-In (18BB)', correctAction: 'call', lawId: 'LAW_07', explanation: 'KQs vs shove with 14BB = call. Good equity vs shoving range.' },
                    { id: 'L1Q19', heroCards: ['As', '8s'], position: 'SB', stackDepth: 11, villainAction: 'BB Only', correctAction: 'raise', lawId: 'LAW_01', explanation: 'A8s in SB = shove vs BB. Strong stealing candidate.' },
                    { id: 'L1Q20', heroCards: ['5d', '5h'], position: 'CO', stackDepth: 9, villainAction: 'Folds to You', correctAction: 'raise', lawId: 'LAW_01', explanation: '55 with 9BB = shove. Push/fold mode, pairs have fold equity.' }
                ]
            },
            {
                level: 2,
                name: 'Bubble Pressure',
                passThreshold: 85,
                questions: [
                    { id: 'L2Q01', heroCards: ['Ah', 'Jh'], position: 'BTN', stackDepth: 12, villainAction: 'Folds to You (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'On bubble, aggression = survival. AJs is a clear shove.' },
                    { id: 'L2Q02', heroCards: ['Kd', 'Td'], position: 'CO', stackDepth: 18, villainAction: 'UTG Raises 2.5BB (Bubble)', correctAction: 'fold', lawId: 'LAW_07', explanation: 'Bubble ICM pressure. KTo cant call vs UTG open range.' },
                    { id: 'L2Q03', heroCards: ['As', 'Ac'], position: 'BB', stackDepth: 25, villainAction: 'BTN Shoves 15BB (Bubble)', correctAction: 'call', lawId: 'LAW_07', explanation: 'AA always calls. ICM matters but not with the nuts.' },
                    { id: 'L2Q04', heroCards: ['Qh', 'Jh'], position: 'SB', stackDepth: 8, villainAction: 'Folds to You (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'Short stack on bubble = shove. QJs has good equity.' },
                    { id: 'L2Q05', heroCards: ['Tc', 'Td'], position: 'BTN', stackDepth: 20, villainAction: 'CO Raises 2.2BB (Bubble)', correctAction: 'call', lawId: 'LAW_08', explanation: 'TT vs CO open = call. Set mining + strong postflop.' },
                    { id: 'L2Q06', heroCards: ['9s', '8s'], position: 'BB', stackDepth: 30, villainAction: 'BTN Min-raises (Bubble)', correctAction: 'call', lawId: 'LAW_08', explanation: 'Deep stacks, suited connector = call and outplay.' },
                    { id: 'L2Q07', heroCards: ['Kh', 'Kc'], position: 'CO', stackDepth: 15, villainAction: 'UTG Shoves 12BB (Bubble)', correctAction: 'call', lawId: 'LAW_07', explanation: 'KK vs any shove = call. You dominate most hands.' },
                    { id: 'L2Q08', heroCards: ['Ad', '4d'], position: 'BTN', stackDepth: 10, villainAction: 'Folds to You (1 from Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'A4s on button = shove. Maximum fold equity spot.' },
                    { id: 'L2Q09', heroCards: ['7h', '6h'], position: 'SB', stackDepth: 22, villainAction: 'BB Only (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'Any two vs BB on bubble = aggressive. 76s is fine.' },
                    { id: 'L2Q10', heroCards: ['Qs', 'Tc'], position: 'BB', stackDepth: 14, villainAction: 'SB Shoves 18BB (Bubble)', correctAction: 'fold', lawId: 'LAW_07', explanation: 'QTo vs SB shove on bubble = fold. Not worth the risk.' },
                    { id: 'L2Q11', heroCards: ['Jh', 'Jc'], position: 'UTG', stackDepth: 20, villainAction: 'You Open (Bubble)', correctAction: 'raise', lawId: 'LAW_06', explanation: 'JJ in UTG = open for value. Strong but controlled.' },
                    { id: 'L2Q12', heroCards: ['As', '9c'], position: 'CO', stackDepth: 11, villainAction: 'Folds to You (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'A9o with 11BB in CO = shove. Standard push/fold.' },
                    { id: 'L2Q13', heroCards: ['6d', '6c'], position: 'BTN', stackDepth: 25, villainAction: 'CO Opens 2.5BB (Bubble)', correctAction: 'call', lawId: 'LAW_08', explanation: '66 vs CO = call. Set mining + position.' },
                    { id: 'L2Q14', heroCards: ['Kc', '9c'], position: 'SB', stackDepth: 9, villainAction: 'Folds to You (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'K9s with 9BB in SB = shove. Fold equity + decent equity.' },
                    { id: 'L2Q15', heroCards: ['Ah', 'Qh'], position: 'BB', stackDepth: 16, villainAction: 'BTN Shoves 14BB (Bubble)', correctAction: 'call', lawId: 'LAW_07', explanation: 'AQs vs BTN shove = call. Great equity vs wide range.' },
                    { id: 'L2Q16', heroCards: ['8c', '8h'], position: 'CO', stackDepth: 12, villainAction: 'Folds to You (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: '88 with 12BB = shove. Pairs are strong enough.' },
                    { id: 'L2Q17', heroCards: ['Ks', 'Jd'], position: 'BTN', stackDepth: 30, villainAction: 'CO Min-raises (Bubble)', correctAction: 'raise', lawId: 'LAW_06', explanation: 'KJo in position vs min-raise = 3-bet bluff.' },
                    { id: 'L2Q18', heroCards: ['4c', '4s'], position: 'SB', stackDepth: 7, villainAction: 'Folds to You (Bubble)', correctAction: 'raise', lawId: 'LAW_01', explanation: '44 with 7BB = shove. Push any pair short-stacked.' },
                    { id: 'L2Q19', heroCards: ['Qd', 'Qc'], position: 'BB', stackDepth: 22, villainAction: 'SB Shoves 10BB (Bubble)', correctAction: 'call', lawId: 'LAW_07', explanation: 'QQ vs short stack shove = always call on bubble.' },
                    { id: 'L2Q20', heroCards: ['Ts', '9s'], position: 'BTN', stackDepth: 15, villainAction: 'Folds to You (ITM)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'T9s once ITM = aggressive. Ladder pressure over.' }
                ]
            },
            {
                level: 3,
                name: 'Final Table Dynamics',
                passThreshold: 85,
                questions: [
                    { id: 'L3Q01', heroCards: ['Ah', 'Kh'], position: 'BTN', stackDepth: 40, villainAction: 'CO Opens 2.2BB (Final Table)', correctAction: 'raise', lawId: 'LAW_06', explanation: 'AKs deep at FT = 3-bet for value. Build the pot.' },
                    { id: 'L3Q02', heroCards: ['Jc', 'Ts'], position: 'BB', stackDepth: 8, villainAction: 'SB Completes (Final Table)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'JTs vs limp at FT = shove. Punish passivity.' },
                    { id: 'L3Q03', heroCards: ['Ks', 'Kd'], position: 'SB', stackDepth: 25, villainAction: 'BTN Raises 2.5BB (Final Table)', correctAction: 'raise', lawId: 'LAW_06', explanation: 'KK at FT = 3-bet always. Max value from premium.' },
                    { id: 'L3Q04', heroCards: ['9h', '9d'], position: 'CO', stackDepth: 15, villainAction: '3 Left, Chip Leader Opens', correctAction: 'fold', lawId: 'LAW_07', explanation: '99 vs chip leader at 3-handed = fold. ICM suicide.' },
                    { id: 'L3Q05', heroCards: ['Ac', '8c'], position: 'BTN', stackDepth: 20, villainAction: 'Heads Up (Big-Blind)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'A8s heads up = raise. Aggression wins HU.' },
                    { id: 'L3Q06', heroCards: ['Qh', 'Qd'], position: 'SB', stackDepth: 30, villainAction: 'Now Heads Up', correctAction: 'raise', lawId: 'LAW_06', explanation: 'QQ HU in SB = raise. Premium + aggression.' },
                    { id: 'L3Q07', heroCards: ['7d', '6d'], position: 'BTN', stackDepth: 45, villainAction: 'Heads Up (Villain Limps)', correctAction: 'raise', lawId: 'LAW_01', explanation: '76s HU vs limp = raise. Punish passive play.' },
                    { id: 'L3Q08', heroCards: ['As', '2s'], position: 'SB', stackDepth: 12, villainAction: 'Heads Up Only', correctAction: 'raise', lawId: 'LAW_01', explanation: 'A2s HU with 12BB = shove. Any ace is strong.' },
                    { id: 'L3Q09', heroCards: ['Tc', '9c'], position: 'BB', stackDepth: 35, villainAction: 'Heads Up (SB Min-raises)', correctAction: 'call', lawId: 'LAW_03', explanation: 'T9s vs HU min-raise = call. Play postflop.' },
                    { id: 'L3Q10', heroCards: ['Ad', 'Jd'], position: 'SB', stackDepth: 18, villainAction: 'Heads Up Only', correctAction: 'raise', lawId: 'LAW_01', explanation: 'AJd HU = raise. Strong hand + position.' },
                    { id: 'L3Q11', heroCards: ['Kh', 'Qc'], position: 'BB', stackDepth: 22, villainAction: 'HU (SB Shoves 15BB)', correctAction: 'call', lawId: 'LAW_07', explanation: 'KQo vs HU shove = call. Top of calling range.' },
                    { id: 'L3Q12', heroCards: ['5s', '5c'], position: 'SB', stackDepth: 10, villainAction: 'Heads Up Only', correctAction: 'raise', lawId: 'LAW_01', explanation: '55 HU with 10BB = shove. Pairs are gold HU.' },
                    { id: 'L3Q13', heroCards: ['Jh', 'Tc'], position: 'BTN', stackDepth: 28, villainAction: '3-Handed (SB Short)', correctAction: 'raise', lawId: 'LAW_01', explanation: 'JTo 3-handed vs short = open wide. Pressure counts.' },
                    { id: 'L3Q14', heroCards: ['Ac', 'Tc'], position: 'SB', stackDepth: 35, villainAction: 'Big Stack in BB (3 Left)', correctAction: 'raise', lawId: 'LAW_06', explanation: 'ATs 3-handed vs BB = open. Strong + position.' },
                    { id: 'L3Q15', heroCards: ['8h', '8s'], position: 'BB', stackDepth: 15, villainAction: 'HU (SB Raises 3BB)', correctAction: 'raise', lawId: 'LAW_06', explanation: '88 HU vs raise = 3-bet shove. Strong value hand.' },
                    { id: 'L3Q16', heroCards: ['Ks', 'Ts'], position: 'SB', stackDepth: 25, villainAction: 'Heads Up Only', correctAction: 'raise', lawId: 'LAW_01', explanation: 'KTs HU = raise. Broadway + suited = aggression.' },
                    { id: 'L3Q17', heroCards: ['Ad', 'Ad'], position: 'BB', stackDepth: 40, villainAction: 'HU (SB 3x Opens)', correctAction: 'raise', lawId: 'LAW_06', explanation: 'AA HU vs 3x = 3-bet. Max value from the best.' },
                    { id: 'L3Q18', heroCards: ['6c', '5c'], position: 'SB', stackDepth: 20, villainAction: 'Heads Up Only', correctAction: 'raise', lawId: 'LAW_01', explanation: '65s HU = raise. Suited connector plays well.' },
                    { id: 'L3Q19', heroCards: ['Qd', 'Jh'], position: 'BB', stackDepth: 18, villainAction: 'HU (SB Shoves 12BB)', correctAction: 'call', lawId: 'LAW_07', explanation: 'QJo vs HU short shove = call. Solid equity.' },
                    { id: 'L3Q20', heroCards: ['2h', '2d'], position: 'SB', stackDepth: 8, villainAction: 'Heads Up Only', correctAction: 'raise', lawId: 'LAW_01', explanation: '22 HU with 8BB = shove. Any pair HU = win.' }
                ]
            }
        ]
    },
    {
        id: 'clinic-14',
        name: 'PKO Bounty Engine',
        subtitle: 'Clinic #14: PKO',
        category: 'MTT',
        targetLeak: 'BOUNTY_MATH',
        description: 'Adjust Calling Ranges Based on Bounty Chip Equivalents',
        icon: '💰',
        badge: 'Bounty Hunter',
        laws: [8, 9], // Bounty Math, Bounty Visuals
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        convertsBountyToChips: true,
        visualEffects: ['BOUNTY_CHIP_GLOW', 'CHIP_CASCADE']
    },
    {
        id: 'clinic-15',
        name: 'Satellite Bubble',
        subtitle: 'Clinic #15: Satellites',
        category: 'MTT',
        targetLeak: 'SATELLITE_ICM',
        description: 'Absolute Survival GTO for Tournament Ticket Bubbles',
        icon: '🎫',
        badge: 'Ticket Master',
        laws: [9, 10], // Survival Pressure, Survival Concepts
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        foldFrequency: 1.0, // Extreme discipline
        visualEffects: ['TICKET_PULSE', 'GOLDEN_TICKET_GLOW']
    },
    {
        id: 'clinic-16',
        name: 'Bubble Bully',
        subtitle: 'Clinic #16: Big Stack',
        category: 'MTT',
        targetLeak: 'BIG_STACK_PRESSURE',
        description: 'Exploit ICM Pressure When Playing as a Big Stack',
        icon: '🦈',
        badge: 'Shark',
        laws: [8, 9], // Stack Awareness, Shark Mode
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        rangeExpansion: 2.0, // 2x vs fearful stacks
        visualEffects: ['SHARK_PULSE', 'SHARK_CHOMP']
    },
    {
        id: 'clinic-17',
        name: 'BB Ante Defense',
        subtitle: 'Clinic #17: Large Pot',
        category: 'MTT',
        targetLeak: 'ANTE_DEFENSE',
        description: 'Correct Defense Frequencies for BB Ante Formats (67% Larger Pots)',
        icon: '🃏',
        badge: 'Ante Master',
        laws: [9, 12], // Large Pot Visual, Format Consistency
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        defenseExpansion: 0.18, // +18% hands
        visualEffects: ['LARGE_POT_GLOW']
    },
    {
        id: 'clinic-18',
        name: 'Ladder Jump Patience',
        subtitle: 'Clinic #18: Discipline',
        category: 'MTT',
        targetLeak: 'PAY_JUMP_PATIENCE',
        description: 'Extreme Discipline for Pay-jump Maximization',
        icon: '🪜',
        badge: 'Ladder Master',
        laws: [9, 10], // Patience Visual, ICM Survival
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        visualEffects: ['HOURGLASS_WAIT', 'GOLDEN_LADDER']
    },

    // ═══════════════════════════════════════════════════════════════════════
    // SPECIALIZED CLINICS (19-28)
    // ═══════════════════════════════════════════════════════════════════════
    {
        id: 'clinic-19',
        name: 'Final Table Pressure',
        subtitle: 'Clinic #19: Final Table',
        category: 'MTT',
        targetLeak: 'FINAL_TABLE_ICM',
        description: 'Master Pay-jump Optimization at the Final Table',
        icon: '👑',
        badge: 'Final Table Champion',
        laws: [8, 9], // Stack Asymmetry, Pressure
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        detectsHeroicFolds: true,
        visualEffects: ['CROWN_GLOW', 'PAY_LADDER']
    },
    {
        id: 'clinic-20',
        name: 'Heads-Up Mastery',
        subtitle: 'Clinic #20: 1v1',
        category: 'MTT',
        targetLeak: 'HEADS_UP_PLAY',
        description: 'Specialized Training for Heads-up Tournament Finales',
        icon: '⚔️',
        badge: 'Duel Champion',
        laws: [2, 3], // Table Re-orient, Button Rotation
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        tableSize: 2,
        visualEffects: ['DUEL_MODE', 'BUTTON_RAPID']
    },
    {
        id: 'clinic-21',
        name: 'Short Stack Ninja',
        subtitle: 'Clinic #21: 10-20BB',
        category: 'MTT',
        targetLeak: 'SHORT_STACK',
        description: 'Master Push/fold Ranges with 10-20BB Stacks',
        icon: '🥷',
        badge: 'Short Stack Ninja',
        laws: [8], // Stack Awareness
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        stackRange: [10, 20],
        visualEffects: ['DANGER_STACK', 'PUSH_FOLD_MODE']
    },
    {
        id: 'clinic-22',
        name: 'Deep Stack Strategy',
        subtitle: 'Clinic #22: 100BB+',
        category: 'CASH',
        targetLeak: 'DEEP_STACK',
        description: 'Master Deep-stack Play with 100BB+ Effective Stacks',
        icon: '📚',
        badge: 'Deep Stack Pro',
        laws: [8], // Stack Awareness
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        minStack: 100,
        visualEffects: ['DEEP_GLOW', 'MULTI_STREET']
    },
    {
        id: 'clinic-23',
        name: 'Blind vs Blind',
        subtitle: 'Clinic #23: SB vs BB',
        category: 'CASH',
        targetLeak: 'BVB_RANGES',
        description: 'Master Blind vs Blind Battles with Wide Ranges',
        icon: '🥊',
        badge: 'Blind Warrior',
        laws: [2, 3], // Position awareness
        difficulty: 3,
        levels: 10,
        passThreshold: 85,
        positions: ['SB', 'BB'],
        visualEffects: ['BLIND_BATTLE', 'WIDE_RANGE']
    },
    {
        id: 'clinic-24',
        name: 'Multi-Way Pots',
        subtitle: 'Clinic #24: 3+ Players',
        category: 'CASH',
        targetLeak: 'MULTI_WAY',
        description: 'Adjust Strategy for Multi-way Pot Dynamics',
        icon: '👥',
        badge: 'Multi-Way Master',
        laws: [6, 8], // Dynamic Sizing, Stack Awareness
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        minPlayers: 3,
        visualEffects: ['MULTI_PLAYER_GLOW']
    },
    {
        id: 'clinic-25',
        name: 'River Decision',
        subtitle: 'Clinic #25: Final Street',
        category: 'STRATEGY',
        targetLeak: 'RIVER_PLAY',
        description: 'Master the Final Street Where Decisions Are Most Critical',
        icon: '🌊',
        badge: 'River Pro',
        laws: [9, 10], // Pressure, Concepts
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        focusStreet: 'RIVER',
        visualEffects: ['RIVER_FOCUS', 'DECISION_WEIGHT']
    },
    {
        id: 'clinic-26',
        name: 'Overbetting',
        subtitle: 'Clinic #26: Polarized Bets',
        category: 'ADVANCED',
        targetLeak: 'OVERBET_FREQUENCY',
        description: 'Master Polarized Overbetting for Maximum EV Extraction',
        icon: '💣',
        badge: 'Overbet Master',
        laws: [6], // Dynamic Sizing
        difficulty: 5,
        levels: 10,
        passThreshold: 85,
        betSizes: ['1.5x', '2x', '3x'],
        visualEffects: ['OVERBET_GLOW', 'POLARIZED_RANGE']
    },
    {
        id: 'clinic-27',
        name: 'Check-Raise Clinic',
        subtitle: 'Clinic #27: Aggression',
        category: 'STRATEGY',
        targetLeak: 'CHECK_RAISE_FREQUENCY',
        description: 'Master the Check-raise for Both Value and Bluffs',
        icon: '📈',
        badge: 'Check-Raise Artist',
        laws: [9], // Pressure
        difficulty: 4,
        levels: 10,
        passThreshold: 85,
        actionSequence: ['CHECK', 'RAISE'],
        visualEffects: ['TRAP_GLOW', 'AGGRESSION_METER']
    },
    {
        id: 'clinic-28',
        name: 'Frequency Execution',
        subtitle: 'Clinic #28: Mixed Strategy',
        category: 'ADVANCED',
        targetLeak: 'MIXED_FREQUENCY',
        description: 'Execute Mixed Strategies with Precise Solver Frequencies',
        icon: '🎲',
        badge: 'Frequency Master',
        laws: [6], // Physical Slider
        difficulty: 5,
        levels: 10,
        passThreshold: 90, // Higher threshold for precision
        requiresSlider: true,
        precisionTiers: ['GOLD', 'GREEN', 'YELLOW'],
        visualEffects: ['FREQUENCY_METER', 'PRECISION_GLOW']
    }
];

// Helper functions
export const getClinicById = (id) =>
    TRAINING_CLINICS.find(c => c.id === id);

export const getClinicsByCategory = (category) =>
    TRAINING_CLINICS.filter(c => c.category === category);

export const getClinicsByDifficulty = (min, max) =>
    TRAINING_CLINICS.filter(c => c.difficulty >= Min && C.difficulty <= max);

export const getClinicForLeak = (leakCategory) => {
    const clinicId = LEAK_CATEGORY_MAP[leakCategory];
    return clinicId ? getClinicById(clinicId) : null;
};

export const getAllCategories = () =>
    [...new Set(TRAINING_CLINICS.map(c => c.category))];

export const getRemediationXPMultiplier = (clinicId) => {
    const clinic = getClinicById(clinicId);
    return clinic ? clinic.xpMultiplier * 2.5 : 1.0; // 2.5x base for remediation
};

export default TRAINING_CLINICS;
