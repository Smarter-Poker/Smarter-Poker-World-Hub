export const FULL_VIDEOS = [
    // ═══════════════════════════════════════════════════════════════════
    // HUSTLER CASINO LIVE - 28 Premium Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'hcl1', videoId: 'D5R_ZQZDR1Q', source: 'HCL', type: 'cash', title: 'Doug Polk Goes FULL DEGEN in LA Poker Game!', views: '1.2M', duration: '18:34' },
    { id: 'hcl2', videoId: 'bjSK8Ajhm2g', source: 'HCL', type: 'cash', title: 'Jungleman & Senor Tilt Attempt to BLUFF Mariano', views: '890K', duration: '15:22' },
    { id: 'hcl3', videoId: 'fif_M-C7uxM', source: 'HCL', type: 'cash', title: 'Jungleman Makes 3 IMPOSSIBLE HERO CALLS in 1 Game!', views: '750K', duration: '14:45' },
    { id: 'hcl4', videoId: '4ErqhJMdTqE', source: 'HCL', type: 'cash', title: 'Nik Airball RUNS OVER The Table & Wins All The Money', views: '980K', duration: '16:18' },
    { id: 'hcl5', videoId: '2aaQ8D5mQiQ', source: 'HCL', type: 'cash', title: 'Top 10 Hands of 2025', views: '1.5M', duration: '22:52' },
    { id: 'hcl6', videoId: 'Tvt3ib08foo', source: 'HCL', type: 'cash', title: 'Top 10 Biggest Pots of 2025', views: '1.8M', duration: '25:44' },
    { id: 'hcl7', videoId: 'TKuwraMHM4s', source: 'HCL', type: 'cash', title: 'Martin Kabrhel is the ULTIMATE TROLL with Jack Five', views: '670K', duration: '13:22' },
    { id: 'hcl8', videoId: 'wMpb2U4bogY', source: 'HCL', type: 'cash', title: 'JBoogs Activates FULL TILT & Cannot Comprehend Runout!', views: '2.1M', duration: '18:45' },
    { id: 'hcl9', videoId: 'hJkpOdcC9b4', source: 'HCL', type: 'cash', title: 'Alan Keating Terrorizes Senor Tilt in 3 MASSIVE Pots', views: '3.2M', duration: '22:18' },
    { id: 'hcl10', videoId: 'q-LPKh4BcDU', source: 'HCL', type: 'cash', title: 'Martin Kabrhel Plays a $1.5M Pot vs Senor Tilt', views: '2.4M', duration: '19:33' },
    { id: 'hcl11', videoId: '7fe18ZyRR3o', source: 'HCL', type: 'cash', title: 'Nik Airball Biggest Win of All Time | $1.3 MILLION', views: '4.5M', duration: '28:12' },
    { id: 'hcl12', videoId: '9BHqoXOGwqo', source: 'HCL', type: 'cash', title: 'How Brandon Steven Lost $2 MILLION in Million Dollar Marathon', views: '2.8M', duration: '24:45' },
    { id: 'hcl13', videoId: 'ZXBCQHCcQDQ', source: 'HCL', type: 'cash', title: 'The Most INSANE Tank in Poker History', views: '1.9M', duration: '16:33' },
    { id: 'hcl14', videoId: 'Z54GrBrtjEY', source: 'HCL', type: 'cash', title: 'Can Alan Keating Hero Call vs MASSIVE Bluff From Peter?!', views: '1.6M', duration: '14:22' },
    { id: 'hcl15', videoId: 'BBiMGvjyjfc', source: 'HCL', type: 'cash', title: 'Alan Keating Plays $2.1M Pot vs Martin Kabrhel', views: '3.8M', duration: '26:18' },
    { id: 'hcl16', videoId: 'XWNNilCpZDs', source: 'HCL', type: 'cash', title: 'Senor Tilt Gets Owned by Mariano in INSANE HAND', views: '1.4M', duration: '15:44' },
    { id: 'hcl17', videoId: 'd-MMWutIvhQ', source: 'HCL', type: 'cash', title: 'QUADS vs STRAIGHT FLUSH! Craziest Hand in HCL HISTORY!', views: '5.2M', duration: '18:55' },
    { id: 'hcl18', videoId: 'nIkqI5ERmoQ', source: 'HCL', type: 'cash', title: 'Mariano & Henry Meet in a NASTY COOLER Situation', views: '920K', duration: '13:22' },
    { id: 'hcl19', videoId: 'yPmtNaw_AZo', source: 'HCL', type: 'cash', title: 'Mariano Wants to Make an INSANE HERO CALL', views: '780K', duration: '12:18' },
    { id: 'hcl20', videoId: 'PjrbLrCDBNQ', source: 'HCL', type: 'cash', title: 'Doug Polk Plays a $686K Pot vs Nik Airball', views: '2.3M', duration: '20:33' },
    { id: 'hcl21', videoId: '2JLbcXyse1I', source: 'HCL', type: 'cash', title: 'Two of the MOST INSANE Hands in HCL History!!', views: '1.7M', duration: '17:44' },
    { id: 'hcl22', videoId: 'kujjBSyB4Dk', source: 'HCL', type: 'cash', title: 'The Biggest Pot in Max Pain Monday History', views: '1.1M', duration: '14:22' },
    { id: 'hcl23', videoId: 'OiLx18q92uM', source: 'HCL', type: 'cash', title: 'STRAIGHT FLUSH vs NUT FLUSH He Cannot Believe His Luck!', views: '2.9M', duration: '16:55' },
    { id: 'hcl24', videoId: 'TSVNEFxZ4D0', source: 'HCL', type: 'cash', title: 'Can Mariano HERO CALL vs Gigantic Bluff From Peter?', views: '850K', duration: '13:18' },
    { id: 'hcl25', videoId: '8ZIrPIbvCyA', source: 'HCL', type: 'cash', title: 'Nik Airball SLOWROLLS Martin Kabrhel in a $401K Pot', views: '1.5M', duration: '15:44' },
    { id: 'hcl26', videoId: 'fuZU0SF5uy4', source: 'HCL', type: 'cash', title: 'SET OVER SET...Nik Airball Plays a $468K Pot', views: '1.8M', duration: '17:22' },
    { id: 'hcl27', videoId: 'V_A47QWTN98', source: 'HCL', type: 'cash', title: 'Martin Kabrhel Runs ACE HIGH BLUFF in $380K Pot!', views: '1.3M', duration: '14:55' },
    { id: 'hcl28', videoId: 'FCHdw4wyrhI', source: 'HCL', type: 'cash', title: 'Senor Tilt Plays CRAZY Hand After CRAZY Hand', views: '990K', duration: '16:33' },

    // ═══════════════════════════════════════════════════════════════════
    // THE LODGE LIVE - 20 Premium Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'lodge1', videoId: 'yJZxw9u7_DU', source: 'LODGE', type: 'cash', title: 'Craziest Straight Flushes of 2025', views: '680K', duration: '18:22' },
    { id: 'lodge2', videoId: 'yIZcxafGzXQ', source: 'LODGE', type: 'cash', title: 'STRAIGHT FLUSH! QUADS! Insane Poker Game!', views: '920K', duration: '22:15' },
    { id: 'lodge3', videoId: '9ZjGeSFzCgE', source: 'LODGE', type: 'cash', title: 'POCKET ACES For $36,185', views: '540K', duration: '14:33' },
    { id: 'lodge4', videoId: 'hpcKG_xl16c', source: 'LODGE', type: 'cash', title: '25 Minutes of Amazing Xuan Liu Moments', views: '780K', duration: '25:00' },
    { id: 'lodge5', videoId: '6I10JPRg-XM', source: 'LODGE', type: 'cash', title: 'MASSIVE Pot With Ace-King!', views: '450K', duration: '12:18' },
    { id: 'lodge6', videoId: 'fHbEUDTuT68', source: 'LODGE', type: 'cash', title: '7 Best Quad Moments', views: '890K', duration: '16:44' },
    { id: 'lodge7', videoId: 'jQjuBFFbGbo', source: 'LODGE', type: 'cash', title: 'She Has Pocket Aces, But...', views: '620K', duration: '11:55' },
    { id: 'lodge8', videoId: 'JycXMxdnk2M', source: 'LODGE', type: 'cash', title: 'Corey Eyring Had a Terrible Day', views: '380K', duration: '15:22' },
    { id: 'lodge9', videoId: 'PA8XtrwroQ8', source: 'LODGE', type: 'cash', title: '10 Biggest Poker Hands of 2025', views: '1.2M', duration: '28:45' },
    { id: 'lodge10', videoId: 'favMEUKGNKc', source: 'LODGE', type: 'cash', title: 'Biggest Pots From Wild Cash Game', views: '560K', duration: '19:33' },
    { id: 'lodge11', videoId: 'hBo4-DsVx5A', source: 'LODGE', type: 'cash', title: 'ROYAL FLUSH Draw For Jenny', views: '720K', duration: '13:18' },
    { id: 'lodge12', videoId: 'liWPL5KvURk', source: 'LODGE', type: 'cash', title: 'Corey Eyring Always Wins', views: '340K', duration: '14:55' },
    { id: 'lodge13', videoId: 'GIKWvbclg7I', source: 'LODGE', type: 'cash', title: 'FULL HOUSE vs FLUSH vs TWO PAIR! Unreal Poker Hand', views: '480K', duration: '11:22' },
    { id: 'lodge14', videoId: 's8waPVJwsZU', source: 'LODGE', type: 'cash', title: 'BIGGEST POTS OF 2025', views: '950K', duration: '24:18' },
    { id: 'lodge15', videoId: 'cYbuojMWC-8', source: 'LODGE', type: 'cash', title: 'SET OVER SET! Corey Eyring vs Poker Bunny', views: '1.1M', duration: '16:44' },
    { id: 'lodge16', videoId: '0UFWJNZ1eZ0', source: 'LODGE', type: 'cash', title: 'Wow! Genuinely Bad Beat', views: '420K', duration: '10:55' },
    { id: 'lodge17', videoId: 'FqiS7LaQSsg', source: 'LODGE', type: 'cash', title: 'She is ALL-IN 6 Times In One Game', views: '580K', duration: '18:22' },
    { id: 'lodge18', videoId: 'pqP_8xMOezc', source: 'LODGE', type: 'cash', title: 'Nightmare Day for Corey Eyring', views: '390K', duration: '15:33' },
    { id: 'lodge19', videoId: 'ckArt7M5hbs', source: 'LODGE', type: 'cash', title: 'Luckiest Poker Moments Ever', views: '850K', duration: '20:18' },
    { id: 'lodge20', videoId: 'vWVwhXeILoX', source: 'LODGE', type: 'cash', title: '2 Royal Flushes Caught on Video', views: '1.4M', duration: '12:44' },

    // ═══════════════════════════════════════════════════════════════════
    // TRITON POKER - 20 Premium Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'triton1', videoId: '524_3UypGkU', source: 'TRITON', type: 'tournament', title: '$150K NLH 8-Handed Final Table Highlights', views: '1.2M', duration: '32:18' },
    { id: 'triton2', videoId: '185vMNh9ECc', source: 'TRITON', type: 'tournament', title: '$150K NLH 8-Handed Final Table', views: '890K', duration: '45:22' },
    { id: 'triton3', videoId: '5wTToeCyu6I', source: 'TRITON', type: 'tournament', title: '$100K NLH Main Event Final Table Highlights', views: '1.5M', duration: '38:45' },
    { id: 'triton4', videoId: 'CbXDixknmeM', source: 'TRITON', type: 'tournament', title: '$100K NLH Main Event Final Table', views: '980K', duration: '52:18' },
    { id: 'triton5', videoId: '4441ee7htt0', source: 'TRITON', type: 'tournament', title: '$125K NLH 7-Handed Final Table Highlights', views: '720K', duration: '28:33' },
    { id: 'triton6', videoId: 'LA4z0Hi0Jf8', source: 'TRITON', type: 'tournament', title: '$125K NLH 7-Handed Final Table', views: '650K', duration: '48:44' },
    { id: 'triton7', videoId: 'jJeZntAfOp4', source: 'TRITON', type: 'tournament', title: '10 Years of Triton Poker | 2026 Gets Bigger', views: '340K', duration: '15:22' },
    { id: 'triton8', videoId: 'pFbHkHhJO4Y', source: 'TRITON', type: 'tournament', title: '$250K NLH Triton Invitational Final Table Highlights', views: '1.8M', duration: '35:18' },
    { id: 'triton9', videoId: 'KQRZs6ytdWc', source: 'TRITON', type: 'tournament', title: '$250K NLH Triton Invitational Final Table', views: '1.1M', duration: '58:44' },
    { id: 'triton10', videoId: 'fzNt4SdBGuQ', source: 'TRITON', type: 'tournament', title: '$100K PLO Main Event Final Table Highlights', views: '680K', duration: '30:22' },
    { id: 'triton11', videoId: '-rjQT0JOhGA', source: 'TRITON', type: 'tournament', title: '$100K PLO Main Event Final Table', views: '520K', duration: '55:33' },
    { id: 'triton12', videoId: 'oINUSqHq_ck', source: 'TRITON', type: 'tournament', title: '$75K PLO 6-Handed Final Table Highlights', views: '450K', duration: '26:18' },
    { id: 'triton13', videoId: 'TXarmUgk02Q', source: 'TRITON', type: 'tournament', title: '$75K PLO 6-Handed Final Table', views: '380K', duration: '48:44' },
    { id: 'triton14', videoId: 'RpU9bwH-2WI', source: 'TRITON', type: 'tournament', title: 'Largest Poker Pot Ever: Ossi Ketola vs Alex Foxen!', views: '2.4M', duration: '18:55' },
    { id: 'triton15', videoId: 'JVJrPh0s1JQ', source: 'TRITON', type: 'tournament', title: '$1.36 Million for 1st! Triton ONE Main Event Final', views: '1.6M', duration: '42:18' },
    { id: 'triton16', videoId: 'OYgw9TiNqZY', source: 'TRITON', type: 'tournament', title: '$564K for 1st! $3K NLH Triton ONE QQPK Genesis', views: '890K', duration: '35:33' },
    { id: 'triton17', videoId: '9PrLmIWU0mU', source: 'TRITON', type: 'tournament', title: 'Pocket Aces in a $1.1M Pot - Rob Yong Mystery!', views: '1.3M', duration: '16:44' },
    { id: 'triton18', videoId: 'slTxYV5S5n0', source: 'TRITON', type: 'tournament', title: '3 Mystery Poker Hands with BRUTAL River Runouts', views: '720K', duration: '22:18' },
    { id: 'triton19', videoId: 'jdiDizWlIz0', source: 'TRITON', type: 'tournament', title: 'Phil Ivey INSANE All-In with Queens Gets Interrupted!', views: '1.9M', duration: '14:55' },
    { id: 'triton20', videoId: 'pIZW-gmcKio', source: 'TRITON', type: 'tournament', title: 'Jungleman Destroys the Table With a $1.5M Pot!', views: '2.1M', duration: '20:33' },

    // ═══════════════════════════════════════════════════════════════════
    // LIVE AT THE BIKE (LATB) - 16 Premium Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'latb1', videoId: 'hg02g0fgIGU', source: 'LATB', type: 'cash', title: 'Almost $50,000 On The Line! Can He Hold With KK?', views: '450K', duration: '14:22' },
    { id: 'latb2', videoId: 'udgiZS2DjUA', source: 'LATB', type: 'cash', title: 'Phil Laak Gets Caught Bluffing In $36,000 Pot!', views: '680K', duration: '16:18' },
    { id: 'latb3', videoId: 'y4f0KyFQCYY', source: 'LATB', type: 'cash', title: 'Heartbreaking Runout In This Crazy Hand For KK!', views: '520K', duration: '12:44' },
    { id: 'latb4', videoId: 'uzse0R3DRIE', source: 'LATB', type: 'cash', title: 'Absolutely DEVASTATING River For Hapa In $24,000 Pot!', views: '380K', duration: '11:55' },
    { id: 'latb5', videoId: '9LwPkMqmWVs', source: 'LATB', type: 'cash', title: 'Phil Laak Hits A DREAM Turn For A $10,000 Pot!', views: '290K', duration: '10:33' },
    { id: 'latb6', videoId: 'tzf6iyT4PPA', source: 'LATB', type: 'cash', title: 'Would You Fold Top Pair For Almost $30,000?', views: '420K', duration: '13:18' },
    { id: 'latb7', videoId: 'a6e2ZJAxFA4', source: 'LATB', type: 'cash', title: 'Dream Flop But Lose $20,000 Anyway', views: '350K', duration: '12:22' },
    { id: 'latb8', videoId: 'CBUvuMqxtOI', source: 'LATB', type: 'cash', title: 'Can He Hold On With A Set Of 6s For Almost $30,000?', views: '480K', duration: '14:44' },
    { id: 'latb9', videoId: 'xaQPx_woep8', source: 'LATB', type: 'cash', title: 'Absolutely INSANE Flop For Almost $40,000!', views: '560K', duration: '15:18' },
    { id: 'latb10', videoId: 'H6asYQPdNLI', source: 'LATB', type: 'cash', title: 'Crazy Preflop Action For Almost $30,000 Pot!', views: '390K', duration: '13:55' },
    { id: 'latb11', videoId: 'WUNTafGZ3hg', source: 'LATB', type: 'cash', title: 'Crazy 3-Way Allin DISASTER For KK!', views: '620K', duration: '11:33' },
    { id: 'latb12', videoId: 'VSY5wuJntQQ', source: 'LATB', type: 'cash', title: 'Would You Believe Him When He Puts You ALL-IN For $27K?', views: '440K', duration: '14:18' },
    { id: 'latb13', videoId: '8WRZavyihfE', source: 'LATB', type: 'cash', title: 'When You Think You Hit The Miracle Card For $20,000...', views: '380K', duration: '12:44' },
    { id: 'latb14', videoId: 'ok-qJesuBxM', source: 'LATB', type: 'cash', title: 'He Sets The PERFECT Trap And Then THIS Happens!', views: '520K', duration: '15:22' },
    { id: 'latb15', videoId: 'GJq0P7mqRac', source: 'LATB', type: 'cash', title: 'Would You Bluff On This River for $25,000+ Pot?', views: '470K', duration: '13:55' },
    { id: 'latb16', videoId: 'cXGygoHy6qE', source: 'LATB', type: 'cash', title: 'He Ran a MASSIVE Bluff For Over $67,000!', views: '780K', duration: '18:33' },

    // ═══════════════════════════════════════════════════════════════════
    // TCH LIVE - 10 Premium Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'tch1', videoId: 'obkeMpIYOqY', source: 'TCH', type: 'tournament', title: 'Daniel Negreanu Headlines EPIC $1M PGT Championship!', views: '1.2M', duration: '28:44' },
    { id: 'tch2', videoId: 'Fy6I9DmPrmA', source: 'TCH', type: 'tournament', title: 'Negreanu SHINES on Day 1 of $1M PGT Championship!', views: '680K', duration: '22:18' },
    { id: 'tch3', videoId: 'SrMLGKLwDZU', source: 'TCH', type: 'tournament', title: '$1,100,000 to the CHAMPION! Super High Roller Bowl FINAL!', views: '1.5M', duration: '45:33' },
    { id: 'tch4', videoId: 'fwMTUYka6C8', source: 'TCH', type: 'tournament', title: 'Negreanu Chases 2nd Super High Roller Bowl Title!', views: '890K', duration: '32:18' },
    { id: 'tch5', videoId: 'jRRBUjmB1Cc', source: 'TCH', type: 'tournament', title: 'MILLIONS On The Line! $100K Super High Roller PLO Day 2!', views: '720K', duration: '38:44' },
    { id: 'tch6', videoId: 'dEcwQDyzXsc', source: 'TCH', type: 'tournament', title: '$1,250,000 Up Top! Super High Roller Bowl PLO Final!', views: '980K', duration: '42:55' },
    { id: 'tch7', videoId: 'VJ7WnbHXRCw', source: 'TCH', type: 'tournament', title: 'WSOP Main Event 2010 - Day 2 with Negreanu & Antonius', views: '450K', duration: '55:18' },
    { id: 'tch8', videoId: 'mNhXY4U1kfo', source: 'TCH', type: 'tournament', title: 'Turning $500 to $542,540 at WSOP Colossus Final Table!', views: '1.8M', duration: '35:44' },
    { id: 'tch9', videoId: 'Vqi3JkPpEQ8', source: 'TCH', type: 'tournament', title: 'WSOP 2025 Main Event | Final Table - FINAL FIVE!', views: '2.4M', duration: '58:22' },
    { id: 'tch10', videoId: 'qPSGmSw9-H0', source: 'TCH', type: 'tournament', title: 'WSOP Top 100 Best Hands of All Time!', views: '3.2M', duration: '65:18' },

    // ═══════════════════════════════════════════════════════════════════
    // WSOP - 15 Tournament Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'wsop1', videoId: 'BdUvr_CXSxk', source: 'WSOP', type: 'tournament', title: 'WSOP Main Event 2022 - Final Table', views: '4.5M', duration: '78:33' },
    { id: 'wsop2', videoId: 'NqPmIAvR82A', source: 'WSOP', type: 'tournament', title: 'WSOP 2025 Main Event Day 2D with Liv Boeree & Sean Perry', views: '1.1M', duration: '45:18' },
    { id: 'wsop3', videoId: 'bSwP4w2apPA', source: 'WSOP', type: 'tournament', title: '2025 WSOP $1,000 Battle of Ages Final Table! $335K at Stake!', views: '890K', duration: '42:44' },
    { id: 'wsop4', videoId: 'dLBj_EziMKk', source: 'WSOP', type: 'tournament', title: 'WSOP 2024 Main Event Final Table - Full Broadcast', views: '3.8M', duration: '156:22' },
    { id: 'wsop5', videoId: '-dXBX-iUw0Q', source: 'WSOP', type: 'tournament', title: 'WSOP 2023 Main Event Final Table', views: '2.9M', duration: '142:18' },
    { id: 'wsop6', videoId: 'yRJMtgIK9C8', source: 'WSOP', type: 'tournament', title: 'Phil Hellmuth\'s 17th Bracelet Win! $10K No Limit 2-7 Draw', views: '1.2M', duration: '38:44' },
    { id: 'wsop7', videoId: 'ZRSfWVI950c', source: 'WSOP', type: 'tournament', title: '$1 Million Buy-in Big One For One Drop Final Table', views: '2.1M', duration: '95:33' },
    { id: 'wsop8', videoId: 'wFHgCRnx_JU', source: 'WSOP', type: 'tournament', title: 'Daniel Negreanu Wins $10K 2-7 Bracelet', views: '980K', duration: '42:18' },
    { id: 'wsop9', videoId: 'gqH0Og9Z--k', source: 'WSOP', type: 'tournament', title: 'BIGGEST Cash Game in Vegas with Esfandiari & Robl!', views: '2.3M', duration: '55:22' },
    { id: 'wsop10', videoId: 'FAKEn51odop', source: 'WSOP', type: 'tournament', title: '$250K Super High Roller Championship Final Table', views: '1.5M', duration: '88:44' },
    { id: 'wsop11', videoId: 'FAKE55t5pd5', source: 'WSOP', type: 'tournament', title: 'Phil Ivey Returns to WSOP - $100K High Roller', views: '1.8M', duration: '65:22' },
    { id: 'wsop12', videoId: '49FxwnBtCFQ', source: 'WSOP', type: 'tournament', title: '$50K Poker Players Championship Final Table', views: '920K', duration: '72:18' },
    { id: 'wsop13', videoId: 'o1SIuqZDz2E', source: 'WSOP', type: 'tournament', title: 'Phil Hellmuth vs Daniel Negreanu - Heads Up Championship', views: '2.4M', duration: '45:33' },
    { id: 'wsop14', videoId: 'FAKEgswfzsu', source: 'WSOP', type: 'tournament', title: '$10K PLO Championship Final Table', views: '780K', duration: '58:44' },
    { id: 'wsop15', videoId: 'FAKEigvh110', source: 'WSOP', type: 'tournament', title: 'Massive Bad Beat - WSOP Main Event 2024', views: '1.6M', duration: '22:18' },

    // ═══════════════════════════════════════════════════════════════════
    // WPT (World Poker Tour) - 15 Tournament Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'wpt1', videoId: '_4nrOGfFssE', source: 'WPT', type: 'tournament', title: 'WPT World Championship $40M GTD Final Table', views: '2.8M', duration: '125:33' },
    { id: 'wpt2', videoId: 'jAtJ6byQnxs', source: 'WPT', type: 'tournament', title: 'Bellagio Cup Final Table - $3.4M Prize Pool', views: '1.9M', duration: '45:22' },
    { id: 'wpt3', videoId: 'uLEWtsmyark', source: 'WPT', type: 'tournament', title: 'WPT World Championship - $5.3M Final Table', views: '1.2M', duration: '95:18' },
    { id: 'wpt4', videoId: 'mxB5zK7fRBs', source: 'WPT', type: 'tournament', title: 'WPT Showdown: Over $8.9 MILLION at Stake', views: '980K', duration: '88:44' },
    { id: 'wpt5', videoId: 'XvxZSSX88Ac', source: 'WPT', type: 'tournament', title: '$7.1M Championship Title Showdown', views: '850K', duration: '82:33' },
    { id: 'wpt6', videoId: 'w1cpoOSqZ2o', source: 'WPT', type: 'tournament', title: 'Festa al Lago Final Table - $3.2M Prize', views: '1.1M', duration: '92:18' },
    { id: 'wpt7', videoId: 'c0RqYhgRxH0', source: 'WPT', type: 'tournament', title: 'WPT L.A. Poker Classic Final Table', views: '920K', duration: '78:44' },
    { id: 'wpt8', videoId: 'iDPJ3tHK6rA', source: 'WPT', type: 'tournament', title: 'WPT bestbet Bounty Scramble Final Table', views: '680K', duration: '72:22' },
    { id: 'wpt9', videoId: 'D1lPQFCDRLg', source: 'WPT', type: 'tournament', title: 'WPT Choctaw Final Table - Epic Showdown', views: '1.3M', duration: '85:33' },
    { id: 'wpt10', videoId: 'bZqKGJz2HoE', source: 'WPT', type: 'tournament', title: 'WPT Bobby Baldwin Classic Final Table', views: '750K', duration: '68:18' },
    { id: 'wpt11', videoId: 'fQ9Lklp6AuA', source: 'WPT', type: 'tournament', title: 'WPT Borgata Poker Open Final Table', views: '890K', duration: '75:44' },
    { id: 'wpt12', videoId: 'hA7c3HHFRUE', source: 'WPT', type: 'tournament', title: 'WPT Thunder Valley Final Table', views: '620K', duration: '70:22' },
    { id: 'wpt13', videoId: 'n0fHHMfvWck', source: 'WPT', type: 'tournament', title: 'WPT Prime Championship Final Table', views: '1.5M', duration: '102:33' },
    { id: 'wpt14', videoId: 'GH5sEqf5p9Y', source: 'WPT', type: 'tournament', title: 'WPT Montreal Final Table - Canadian Showdown', views: '780K', duration: '65:18' },
    { id: 'wpt15', videoId: 'aVGVP7Oj8Jg', source: 'WPT', type: 'tournament', title: 'WPT Legends of Poker Final Table', views: '940K', duration: '80:44' },

    // ═══════════════════════════════════════════════════════════════════
    // EPT (European Poker Tour) - 12 Tournament Episodes
    // ═══════════════════════════════════════════════════════════════════
    { id: 'ept1', videoId: 'IMbKeXfKb4c', source: 'EPT', type: 'tournament', title: 'EPT Cyprus 2024 Main Event Highlights', views: '2.1M', duration: '118:33' },
    { id: 'ept2', videoId: 'KLgwpOWXiyE', source: 'EPT', type: 'tournament', title: 'Greatest Final Table in EPT History', views: '1.8M', duration: '95:22' },
    { id: 'ept3', videoId: 'X4oygINf-uo', source: 'EPT', type: 'tournament', title: 'EPT Monte-Carlo 2024 Highlights', views: '1.4M', duration: '105:18' },
    { id: 'ept4', videoId: '0Wxi_hzgFGo', source: 'EPT', type: 'tournament', title: 'EPT Barcelona 2024 Final Table', views: '1.2M', duration: '88:44' },
    { id: 'ept5', videoId: 'FpEJkBJVd00', source: 'EPT', type: 'tournament', title: 'EPT Barcelona 2024 Highlights', views: '980K', duration: '72:33' },
    { id: 'ept6', videoId: '33p282rfivw', source: 'EPT', type: 'tournament', title: 'EPT Prague 2025 Final Day', views: '850K', duration: '82:18' },
    { id: 'ept7', videoId: 'FAKEc1v448x', source: 'EPT', type: 'tournament', title: 'Adrian Mateos Wins EPT Super High Roller', views: '1.1M', duration: '78:44' },
    { id: 'ept8', videoId: 'FAKEvp9q9qm', source: 'EPT', type: 'tournament', title: 'EPT Barcelona €25K High Roller Final Table', views: '920K', duration: '85:22' },
    { id: 'ept9', videoId: 'FAKEfn79mbg', source: 'EPT', type: 'tournament', title: 'EPT Monte Carlo €100K Final Table', views: '1.5M', duration: '102:33' },
    { id: 'ept10', videoId: 'FAKExszt7pv', source: 'EPT', type: 'tournament', title: 'EPT London High Roller Final Table', views: '780K', duration: '68:18' },
    { id: 'ept11', videoId: 'FAKE710frrv', source: 'EPT', type: 'tournament', title: 'Incredible Royal Flush at EPT Barcelona', views: '2.4M', duration: '18:44' },
    { id: 'ept12', videoId: 'FAKEa8a5u37', source: 'EPT', type: 'tournament', title: 'EPT Prague €25K Single-Day High Roller', views: '680K', duration: '65:22' },

    // ═══════════════════════════════════════════════════════════════════
    // POKER VLOGGERS - 12 Premium Episodes  
    // ═══════════════════════════════════════════════════════════════════
    { id: 'vlog1', videoId: 'P5OT-cOcTRs', source: 'BRAD_OWEN', type: 'cash', title: 'MANIAC Wants To Get STACKED!! Nashville Poker Is WILD!!', views: '520K', duration: '38:22' },
    { id: 'vlog2', videoId: 'PalPSvIIxUg', source: 'BRAD_OWEN', type: 'cash', title: 'My BIGGEST WIN EVER!! $50,000+ In DREAM Session!!', views: '890K', duration: '42:18' },
    { id: 'vlog3', videoId: 'I-dJDxwatNo', source: 'BRAD_OWEN', type: 'cash', title: 'I Play $60,000+ Pot vs Mariano!! GIGANTIC ALL IN Pots!', views: '1.2M', duration: '45:33' },
    { id: 'vlog4', videoId: 'NKFFVY6Q37s', source: 'BRAD_OWEN', type: 'cash', title: 'I Have STRAIGHT FLUSH vs Flopped NUTS!! $15,000+!', views: '680K', duration: '36:44' },
    { id: 'vlog5', videoId: 'HFPNAXxQjvQ', source: 'BRAD_OWEN', type: 'cash', title: 'Player Lies About His Hand! $10,000+ 5-bet ALL IN!', views: '450K', duration: '32:18' },
    { id: 'vlog6', videoId: 'pQ423SML2gc', source: 'BRAD_OWEN', type: 'cash', title: 'I Have FULL HOUSE IN $30,000+ ALL IN!! BOBBY ROOM!', views: '780K', duration: '40:55' },
    { id: 'vlog7', videoId: 'Ls4b65169-k', source: 'BRAD_OWEN', type: 'cash', title: 'Ive Got $100,000+ In BOBBY ROOM!! High Stakes 100/200!', views: '920K', duration: '48:22' },
    { id: 'vlog8', videoId: 'zfDgGWh-si0', source: 'BRAD_OWEN', type: 'cash', title: 'My ABSOLUTE BEST Performance On HIGH STAKES Livestream!', views: '1.1M', duration: '44:18' },
    { id: 'vlog9', videoId: '_BeB0OkwCTw', source: 'BRAD_OWEN', type: 'cash', title: 'Opponent DOMINATED In $18,000 Pot!! 5-Bet ALL IN!', views: '560K', duration: '35:44' },
    { id: 'vlog10', videoId: '8XHhGlAfi-E', source: 'BRAD_OWEN', type: 'cash', title: 'I Hit Three SETS And CRUSH Souls!! Back 5-bet Jams KINGS!', views: '480K', duration: '38:22' },
    { id: 'vlog11', videoId: 'mPHrT249LJ8', source: 'BRAD_OWEN', type: 'cash', title: 'I Flop QUADS!!! ACES And Three Players Raised In Front!', views: '720K', duration: '34:55' },
    { id: 'vlog12', videoId: 'Pv6yB5uM1Hw', source: 'BRAD_OWEN', type: 'cash', title: 'I Make RARE STRAIGHT FLUSH!! Unbelievable ALL IN!!', views: '650K', duration: '36:18' },

    // ═══════════════════════════════════════════════════════════════════
    // POKERGO - 6 Premium Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'pgo1', videoId: 'FAKE89dbizc', source: 'POKERGO', type: 'cash', title: 'High Stakes Poker Season 10 - Best Moments', views: '2.8M', duration: '45:22' },
    { id: 'pgo2', videoId: 'FAKEfxvj1wx', source: 'POKERGO', type: 'cash', title: 'No Gamble, No Future - Phil Hellmuth vs Tom Dwan', views: '1.9M', duration: '38:44' },
    { id: 'pgo3', videoId: 'FAKEdxruw08', source: 'POKERGO', type: 'cash', title: 'Super High Roller Bowl Final Table', views: '1.5M', duration: '82:18' },
    { id: 'pgo4', videoId: 'FAKEi57mbzp', source: 'POKERGO', type: 'tournament', title: 'US Poker Open $25K Main Event', views: '980K', duration: '55:33' },
    { id: 'pgo5', videoId: 'FAKEip93sk4', source: 'POKERGO', type: 'cash', title: 'Poker After Dark - Million Dollar Cash Game', views: '1.2M', duration: '42:18' },
    { id: 'pgo6', videoId: 'FAKErr1evhg', source: 'POKERGO', type: 'cash', title: 'Best Bluffs from High Stakes Poker', views: '890K', duration: '28:44' },

    // ═══════════════════════════════════════════════════════════════════
    // ANDREW NEEME - 5 Premium Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'neeme1', videoId: 'VknSBaSAX2I', source: 'NEEME', type: 'cash', title: 'Playing the Lodge with Doug Polk', views: '680K', duration: '42:18' },
    { id: 'neeme2', videoId: 'qeItZFws2Hk', source: 'NEEME', type: 'cash', title: 'My Biggest Pot EVER at Bellagio 10/20', views: '890K', duration: '38:55' },
    { id: 'neeme3', videoId: 'Dwv4ekxyS3A', source: 'NEEME', type: 'cash', title: 'I Ran My Trip Aces Into Quads...', views: '520K', duration: '35:22' },
    { id: 'neeme4', videoId: 'rSQpzr24-fY', source: 'NEEME', type: 'cash', title: 'Vegas Cash Game Session - Crushing 5/10', views: '450K', duration: '44:18' },
    { id: 'neeme5', videoId: 'vXBrOA-AHKY', source: 'NEEME', type: 'cash', title: 'The Reality of Professional Poker', views: '620K', duration: '32:44' },

    // ═══════════════════════════════════════════════════════════════════
    // RAMPAGE POKER - 5 Premium Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'ramp1', videoId: '6vyO89eugpA', source: 'RAMPAGE', type: 'cash', title: 'I BLUFFED $100,000 vs Mariano!!', views: '1.4M', duration: '38:22' },
    { id: 'ramp2', videoId: 'IVGRM1OF-oo', source: 'RAMPAGE', type: 'cash', title: 'Playing $100,000 Pot with POCKET KINGS!', views: '980K', duration: '42:18' },
    { id: 'ramp3', videoId: 'Fx3TLCUpRNc', source: 'RAMPAGE', type: 'tournament', title: 'DEEP RUN in WSOP Main Event', views: '1.8M', duration: '55:44' },
    { id: 'ramp4', videoId: '9ucgJSjFZc4', source: 'RAMPAGE', type: 'cash', title: 'GOING ON TILT at the Lodge!', views: '720K', duration: '35:22' },
    { id: 'ramp5', videoId: 'UNDaUcrBGPY', source: 'RAMPAGE', type: 'cash', title: 'MY CRAZIEST BLUFF EVER CAUGHT ON STREAM', views: '1.1M', duration: '28:55' },

    // ═══════════════════════════════════════════════════════════════════
    // MARIANO - 4 Premium Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'mari1', videoId: 'uYVmCE6meLI', source: 'MARIANO', type: 'cash', title: 'My TOP 10 Best Poker Hands', views: '1.2M', duration: '32:18' },
    { id: 'mari2', videoId: 'Wo1mGd8_XXE', source: 'MARIANO', type: 'cash', title: 'Crushing High Stakes at the Lodge $179K Pot!', views: '890K', duration: '28:44' },
    { id: 'mari3', videoId: 'uvCjBlQXupw', source: 'MARIANO', type: 'cash', title: 'I HERO CALLED with Queen High and WON!', views: '680K', duration: '22:22' },
    { id: 'mari4', videoId: 'kCfNqGeHWpM', source: 'MARIANO', type: 'cash', title: 'The Most BRUTAL Hands This Year', views: '950K', duration: '35:55' },

    // ═══════════════════════════════════════════════════════════════════
    // WOLFGANG POKER - 4 Premium Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'wolf1', videoId: 'CTZeYizF-g0', source: 'WOLFGANG', type: 'cash', title: 'Playing High Stakes with Rampage and Mariano', views: '580K', duration: '42:18' },
    { id: 'wolf2', videoId: 'clZ-r2QDcbY', source: 'WOLFGANG', type: 'tournament', title: 'WSOP Vlog - Deep Run Dreams', views: '450K', duration: '38:44' },
    { id: 'wolf3', videoId: 's0WWs2e2Vhc', source: 'WOLFGANG', type: 'cash', title: 'I Win My BIGGEST Pot EVER at $5/10', views: '620K', duration: '35:22' },
    { id: 'wolf4', videoId: '8XbnLzZIy7Q', source: 'WOLFGANG', type: 'cash', title: 'Short Form Poker Content is INSANE!', views: '380K', duration: '18:55' },

    // ═══════════════════════════════════════════════════════════════════
    // JONATHAN LITTLE - 5 Training Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'jl1', videoId: 'dg016Stpa2k', source: 'JLITTLE', type: 'cash', title: 'Avoid These 5 COSTLY Poker Mistakes', views: '2.1M', duration: '22:18' },
    { id: 'jl2', videoId: 'GSzOSY_IcB4', source: 'JLITTLE', type: 'cash', title: 'When and How to BLUFF Like a Pro', views: '1.5M', duration: '28:44' },
    { id: 'jl3', videoId: 'nvFsvh4FNok', source: 'JLITTLE', type: 'cash', title: 'Hand Reading Explained - From Beginner to Pro', views: '1.8M', duration: '35:22' },
    { id: 'jl4', videoId: 'Dhlr255j55o', source: 'JLITTLE', type: 'tournament', title: 'How to Play Deep Stack Tournaments', views: '980K', duration: '42:18' },
    { id: 'jl5', videoId: 'VrQCQnYlTaM', source: 'JLITTLE', type: 'cash', title: 'River Betting Strategy Masterclass', views: '720K', duration: '25:55' },

    // ═══════════════════════════════════════════════════════════════════
    // DOUG POLK - 5 Premium Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'polk1', videoId: 'fhgYiIyxtSE', source: 'POLK', type: 'cash', title: 'My HEADS UP Battle vs Daniel Negreanu', views: '4.5M', duration: '55:22' },
    { id: 'polk2', videoId: '4kkx1r3YaAU', source: 'POLK', type: 'cash', title: 'Roasting These TERRIBLE Poker Hands', views: '1.8M', duration: '22:18' },
    { id: 'polk3', videoId: '1RdN2cOf9do', source: 'POLK', type: 'cash', title: 'Playing the BIGGEST Game at the Lodge', views: '2.1M', duration: '48:44' },
    { id: 'polk4', videoId: 'fdY9bxBd_Sw', source: 'POLK', type: 'cash', title: 'I Played $1,000,000 Pot vs Tom Dwan', views: '3.2M', duration: '35:22' },
    { id: 'polk5', videoId: 'c_CMqUjKYCQ', source: 'POLK', type: 'cash', title: 'Analyzing Phil Hellmuths WORST Plays', views: '1.5M', duration: '28:55' },

    // ═══════════════════════════════════════════════════════════════════
    // BART HANSON - 4 Training Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'bart1', videoId: '6kzQkQD_UaM', source: 'BART', type: 'cash', title: 'Crush Live Poker - Complete Hand Breakdown', views: '890K', duration: '45:22' },
    { id: 'bart2', videoId: '8BJVttAf2Xo', source: 'BART', type: 'cash', title: 'How to Play Live Poker for a Living', views: '1.2M', duration: '38:18' },
    { id: 'bart3', videoId: 'IQRbD9z5sso', source: 'BART', type: 'cash', title: 'Reading Your Opponents at the Table', views: '680K', duration: '28:44' },
    { id: 'bart4', videoId: 'uRdY2woHpcw', source: 'BART', type: 'cash', title: 'My Top 10 Poker Tips', views: '550K', duration: '22:55' },

    // ═══════════════════════════════════════════════════════════════════
    // DANIEL NEGREANU - 5 Celebrity Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'dn1', videoId: '9RMgHjToDFw', source: 'NEGREANU', type: 'cash', title: 'My SOUL READ Destroyed Him at High Stakes', views: '3.8M', duration: '28:22' },
    { id: 'dn2', videoId: 'FGytzJRnXsg', source: 'NEGREANU', type: 'tournament', title: 'WSOP Main Event Vlog - Day 1', views: '1.5M', duration: '42:18' },
    { id: 'dn3', videoId: 'AhfeoNu7EnA', source: 'NEGREANU', type: 'cash', title: 'Playing High Stakes Poker on PokerGO', views: '2.1M', duration: '55:44' },
    { id: 'dn4', videoId: '3RQ5CyN_VGE', source: 'NEGREANU', type: 'tournament', title: 'My BIGGEST Tournament Win Ever', views: '2.8M', duration: '48:22' },
    { id: 'dn5', videoId: 'RTvaz9x7ER0', source: 'NEGREANU', type: 'cash', title: 'Daniel vs Doug Polk - The Rematch', views: '1.9M', duration: '35:55' },

    // ═══════════════════════════════════════════════════════════════════
    // PHIL HELLMUTH - 4 Celebrity Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'ph1', videoId: 'mjGLuIFfDAA', source: 'HELLMUTH', type: 'cash', title: 'THE POKER BRAT - Phil Hellmuths Greatest Moments', views: '4.2M', duration: '18:44' },
    { id: 'ph2', videoId: '2FrUMbm-xuE', source: 'HELLMUTH', type: 'tournament', title: 'Phil Hellmuth Best Poker Hands 2021', views: '2.8M', duration: '45:22' },
    { id: 'ph3', videoId: 'mYRLf222v9g', source: 'HELLMUTH', type: 'cash', title: 'Phil Hellmuth BIGGEST Blow-Ups', views: '1.9M', duration: '22:18' },
    { id: 'ph4', videoId: '1WqM3CCw5rY', source: 'HELLMUTH', type: 'tournament', title: 'Bay 101 Shooting Star Final Table - $3.1M', views: '3.1M', duration: '55:44' },

    // ═══════════════════════════════════════════════════════════════════
    // PHIL IVEY - 4 Celebrity Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'pi1', videoId: 'HY2V4mHdQJw', source: 'IVEY', type: 'cash', title: 'Phil Ivey Best Bluff Ever vs Paul Jackson', views: '5.2M', duration: '18:22' },
    { id: 'pi2', videoId: 'RC3ddhyKFOo', source: 'IVEY', type: 'cash', title: 'Phil Ivey Folds Kings to Sick Bluff - High Stakes', views: '3.8M', duration: '22:44' },
    { id: 'pi3', videoId: 'SMJ7C4atMi0', source: 'IVEY', type: 'tournament', title: 'PHIL IVEY TOP 5 POKER READS - PokerStars', views: '2.1M', duration: '48:55' },
    { id: 'pi4', videoId: 'SIfMqu_IkaA', source: 'IVEY', type: 'cash', title: 'Greatest Poker Moments From Phil Ivey', views: '2.9M', duration: '35:22' },

    // ═══════════════════════════════════════════════════════════════════
    // TOM DWAN - 4 Celebrity Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'td1', videoId: 'AnGZfqtXIJk', source: 'DWAN', type: 'cash', title: 'Best of Tom Dwan - High Stakes Poker Season 9', views: '4.8M', duration: '22:18' },
    { id: 'td2', videoId: 'dS_uv88YuPs', source: 'DWAN', type: 'cash', title: 'Every Tom Dwan Bluff on High Stakes Poker', views: '6.2M', duration: '28:44' },
    { id: 'td3', videoId: 'uC1pmdBTn6U', source: 'DWAN', type: 'cash', title: 'Tom Dwan High Stakes MEGA COMPILATION', views: '2.5M', duration: '55:22' },
    { id: 'td4', videoId: 'mmcKrIqLfrk', source: 'DWAN', type: 'cash', title: '38 Minutes of Tom Dwans INSANE Bluffs', views: '3.1M', duration: '42:55' },

    // ═══════════════════════════════════════════════════════════════════
    // GARRETT ADELSTEIN - 4 Celebrity Episodes (Real YouTube IDs)
    // ═══════════════════════════════════════════════════════════════════
    { id: 'ga1', videoId: '9NNKjWscKWo', source: 'GARRETT', type: 'cash', title: 'Most INSANE Hero Call In Poker History - HCL', views: '2.4M', duration: '35:22' },
    { id: 'ga2', videoId: 'G_qXrxrzNvQ', source: 'GARRETT', type: 'cash', title: 'Garrett Adelstein DESTROYS Everyone - HCL', views: '8.5M', duration: '28:44' },
    { id: 'ga3', videoId: 'iDQrDO4qC4A', source: 'GARRETT', type: 'cash', title: 'He Wants Garrett to Give Back Robbis Money', views: '1.8M', duration: '22:18' },
    { id: 'ga4', videoId: '3pnJjgNSYTQ', source: 'GARRETT', type: 'cash', title: 'The RETURN of Garrett Adelstein - PokerGO', views: '2.1M', duration: '42:55' },
];

export const SOURCES = [
    { id: 'ALL', name: 'All Sources', logo: null },
    // Major Live Streams
    { id: 'HCL', name: 'Hustler Casino Live', logo: '/images/video-sources/hcl.png' },
    { id: 'LODGE', name: 'The Lodge', logo: '/images/video-sources/lodge.png' },
    { id: 'TRITON', name: 'Triton Poker', logo: '/images/video-sources/triton.jpg' },
    { id: 'LATB', name: 'Bally Poker Live', logo: '/images/video-sources/latb.png' },
    { id: 'TCH', name: 'TCH Live', logo: '/images/video-sources/tch.png' },
    { id: 'POKERGO', name: 'PokerGO', logo: '/images/video-sources/pokergo.jpg' },
    // Major Tours
    { id: 'WSOP', name: 'WSOP', logo: '/images/video-sources/wsop.png' },
    { id: 'WPT', name: 'WPT', logo: '/images/video-sources/wpt.jpg' },
    { id: 'EPT', name: 'EPT', logo: '/images/video-sources/ept.jpg' },
    // Top Vloggers
    { id: 'BRAD_OWEN', name: 'Brad Owen', logo: '/images/video-sources/brad_owen.png' },
    { id: 'NEEME', name: 'Andrew Neeme', logo: '/images/video-sources/neeme.jpg' },
    { id: 'RAMPAGE', name: 'Rampage Poker', logo: '/images/video-sources/rampage.jpg' },
    { id: 'MARIANO', name: 'Mariano', logo: '/images/video-sources/mariano.jpg' },
    { id: 'WOLFGANG', name: 'Wolfgang Poker', logo: '/images/video-sources/wolfgang.jpg' },
    { id: 'JOHNNIE', name: 'Johnnie Vibes', logo: '/images/video-sources/johnnie.jpg' },
    // Training/Strategy
    { id: 'JLITTLE', name: 'Jonathan Little', logo: '/images/video-sources/jlittle.jpg' },
    { id: 'POLK', name: 'Doug Polk', logo: '/images/video-sources/polk.jpg' },
    { id: 'BART', name: 'Bart Hanson', logo: '/images/video-sources/bart.jpg' },
    { id: 'UPSWING', name: 'Upswing Poker', logo: '/images/video-sources/upswing.svg' },
    // Celebrity Pros
    { id: 'NEGREANU', name: 'Daniel Negreanu', logo: '/images/video-sources/negreanu.jpg' },
    { id: 'HELLMUTH', name: 'Phil Hellmuth', logo: '/images/video-sources/hellmuth.jpg' },
    { id: 'IVEY', name: 'Phil Ivey', logo: '/images/video-sources/ivey.jpg' },
    { id: 'DWAN', name: 'Tom Dwan', logo: '/images/video-sources/dwan.jpg' },
    { id: 'GARRETT', name: 'Garrett Adelstein', logo: '/images/video-sources/garrett.jpg' },
];
