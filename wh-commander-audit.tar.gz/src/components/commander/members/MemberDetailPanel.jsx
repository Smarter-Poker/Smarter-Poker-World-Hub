export { default } from '@smarter-poker/commander-shared/components/commander/members/MemberDetailPanel';
