/**
 * Venue Detail Page
 * View venue info, live games, waitlist, and promotions
 * UI: Dark industrial sci-fi gaming theme, no emojis, Inter font
 */
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import SEOHead from '../../../../src/components/seo/SEOHead';
import { ArrowLeft, MapPin, Clock, Users, Phone, Star, Gift, Loader2, MessageSquare, Zap, ExternalLink } from 'lucide-react';
import { supabase } from '../../../../src/lib/supabase';
import CommanderPageShell from '../../../../src/components/commander/CommanderPageShell';

function GameRow({ game, onJoinWaitlist }) {
  const isFull = (game.player_count || 0) >= (game.max_players || 9);
  const waitlistCount = game.waitlist_count || 0;

  return (
    <div className="flex items-center justify-between p-4 border-b border-[#4A5E78] last:border-b-0">
      <div>
        <p className="font-medium text-white">
          {game.stakes} {game.game_type?.toUpperCase() || 'NLHE'}
        </p>
        <div className="flex items-center gap-3 text-sm text-[#64748B]">
          <span>Table {game.table_number}</span>
          <span>{game.player_count || 0}/{game.max_players || 9} players</span>
          {waitlistCount > 0 && (
            <span className="text-[#F59E0B]">{waitlistCount} waiting</span>
          )}
        </div>
      </div>
      <button
        onClick={() => onJoinWaitlist?.(game)}
        className={
          isFull
            ? 'bg-[#F59E0B] text-white hover:bg-[#D97706] px-4 py-2 rounded-lg text-sm font-medium transition-colors'
            : 'cmd-btn cmd-btn-primary px-4 py-2 text-sm transition-colors'
        }
      >
        {isFull ? 'Join Waitlist' : 'Sit Now'}
      </button>
    </div>
  );
}

export default function VenueDetailPage() {
  const router = useRouter();
  const { id } = router.query;

  const [venue, setVenue] = useState(null);
  const [games, setGames] = useState([]);
  const [promotions, setPromotions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviews, setReviews] = useState([]);
  const [reviewsTotal, setReviewsTotal] = useState(0);
  const [liveGames, setLiveGames] = useState([]);
  const [socialPageSlug, setSocialPageSlug] = useState(null); // linked social page slug/id

  const fetchData = useCallback(async () => {

  if (!router.isReady) return null;

    if (!id) return;

    try {
      const [venueRes, gamesRes, promosRes, reviewsRes, liveGamesRes] = await Promise.all([
        fetch(`/api/commander/venues/${id}`).catch(() => ({ ok: false })),
        fetch(`/api/commander/games/venue/${id}`).catch(() => ({ ok: false })),
        fetch(`/api/commander/promotions?venue_id=${id}&active=true`).catch(() => ({ ok: false })),
        fetch(`/api/commander/venues/${id}/reviews?limit=10`).catch(() => ({ ok: false })),
        fetch(`/api/commander/games/live?venue_id=${id}`).catch(() => ({ ok: false }))
      ]);

      if (!venueRes.ok) throw new Error(`Request failed (${venueRes.status})`);
      const venueData = await venueRes.json();
      if (!gamesRes.ok) throw new Error(`Request failed (${gamesRes.status})`);
      const gamesData = await gamesRes.json();
      if (!promosRes.ok) throw new Error(`Request failed (${promosRes.status})`);
      const promosData = await promosRes.json();
      if (!reviewsRes.ok) throw new Error(`Request failed (${reviewsRes.status})`);
      const reviewsData = await reviewsRes.json();
      if (!liveGamesRes.ok) throw new Error(`Request failed (${liveGamesRes.status})`);
      const liveGamesData = await liveGamesRes.json();

      if (venueData.success || venueData.venue) {
        setVenue(venueData.venue || venueData.data?.venue);
      }
      if (gamesData.success) {
        setGames(gamesData.data?.games || []);
      }
      if (promosData.success) {
        setPromotions(promosData.data?.promotions || []);
      }
      if (reviewsData.success && reviewsData.data) {
        setReviews(reviewsData.data.reviews || []);
        setReviewsTotal(reviewsData.data.total || 0);
      }
      if (liveGamesData.success && liveGamesData.data) {
        setLiveGames(liveGamesData.data.games || []);
      }
    } catch (err) {
      console.warn('Fetch failed:', err);
      setVenue(null);
      setGames([]);
      setPromotions([]);
    } finally {
      setLoading(false);
    }

    // Fetch linked social page (best-effort, non-blocking)
    try {
      const spRes = await fetch(`/api/social/pages?linked_venue_id=${id}&limit=1`);
      if (spRes.ok) {
        const spJson = await spRes.json();
        const sp = spJson.data?.pages?.[0] || spJson.data?.[0];
        if (sp) setSocialPageSlug(sp.slug || sp.id);
      }
    } catch (_) { /* non-critical */ }
  }, [id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);
  // Realtime listener — live updates for venues/[id].js
  useEffect(() => {
    if (!id) return;
    const ch = supabase
      .channel(`venue-detail:${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'commander_games', filter: `venue_id=eq.${id}` }, () => { fetchData(); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id]);

  function handleJoinWaitlist(game) {
    router.push(`/hub/commander/waitlist/${id}?game=${game.id}`);
  }

  function handleCheckIn() {
    router.push(`/hub/commander/check-in/${id}`);
  }

  if (loading) {
    return (
      <div className="cmd-page flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#22D3EE]" />
      </div>
    );
  }

  if (!venue) {
    return (
      <div className="cmd-page flex items-center justify-center p-4">
        <div className="text-center">
          <MapPin className="w-12 h-12 text-[#4A5E78] mx-auto mb-3" />
          <p className="text-[#64748B]">Venue Not Found</p>
        </div>
      </div>
    );
  }

  const activeGames = games.filter(g => g.status !== 'closed');

  return (
    <CommanderPageShell>
    <>
      <SEOHead
                title="Venue Details"
                description="Smarter.Poker — The Future Of The Game."
                noindex={true}
            />

      <div className="cmd-page">
        {/* Header */}
        <header className="cmd-header-full text-white">
          <div className="max-w-lg mx-auto px-4 py-4">
            <button
              onClick={() => router.back()}
              className="flex items-center gap-2 text-white/80 hover:text-white mb-4"
            >
              <ArrowLeft className="w-5 h-5" />
              Back
            </button>

            <h1 className="text-2xl font-bold">{venue.name}</h1>
            <p className="text-white/80 flex items-center gap-1 mt-1">
              <MapPin className="w-4 h-4" />
              {venue.city}, {venue.state}
            </p>

            {venue.rating && (
              <div className="flex items-center gap-1 mt-2">
                <Star className="w-5 h-5 text-[#F59E0B] fill-[#F59E0B]" />
                <span className="font-medium">{venue.rating.toFixed(1)}</span>
              </div>
            )}
          </div>
        </header>

        <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
          {/* Check-In Button */}
          <button
            onClick={handleCheckIn}
            className="cmd-btn cmd-btn-primary w-full h-14 text-lg flex items-center justify-center gap-2"
          >
            <Users className="w-6 h-6" />
            Check In
          </button>

          {/* Edit Social Page — shown when a linked social page exists */}
          {socialPageSlug && (
            <button
              id="btn-edit-social-page"
              onClick={() => router.push(`/hub/social-pages/${socialPageSlug}/manage`)}
              className="w-full h-12 flex items-center justify-center gap-2 text-sm font-semibold rounded-xl border border-[#22D3EE] text-[#22D3EE] bg-transparent hover:bg-[#22D3EE]/10 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              Edit Social Page
            </button>
          )}

          {/* Venue Info */}
          <div className="cmd-panel overflow-hidden">
            <div className="p-4 border-b border-[#4A5E78]">
              <h2 className="font-semibold text-white">Info</h2>
            </div>
            <div className="divide-y divide-[#4A5E78]">
              {venue.address && (
                <div className="flex items-center gap-3 p-4">
                  <MapPin className="w-5 h-5 text-[#64748B]" />
                  <span className="text-white">{venue.address}</span>
                </div>
              )}
              {venue.phone && (
                <a href={`tel:${venue.phone}`} className="flex items-center gap-3 p-4 hover:bg-[#132240]">
                  <Phone className="w-5 h-5 text-[#64748B]" />
                  <span className="text-[#22D3EE]">{venue.phone}</span>
                </a>
              )}
              {venue.hours && (
                <div className="flex items-center gap-3 p-4">
                  <Clock className="w-5 h-5 text-[#64748B]" />
                  <span className="text-white">{venue.hours}</span>
                </div>
              )}
              {venue.total_tables && (
                <div className="flex items-center gap-3 p-4">
                  <Users className="w-5 h-5 text-[#64748B]" />
                  <span className="text-white">{venue.total_tables} tables</span>
                </div>
              )}
            </div>
          </div>

          {/* Live Games */}
          <div className="cmd-panel overflow-hidden">
            <div className="p-4 border-b border-[#4A5E78] flex items-center justify-between">
              <h2 className="font-semibold text-white">Live Games</h2>
              <span className="text-sm text-[#64748B]">{activeGames.length} running</span>
            </div>
            {activeGames.length === 0 ? (
              <div className="p-8 text-center">
                <Users className="w-12 h-12 text-[#4A5E78] mx-auto mb-3" />
                <p className="text-[#64748B]">No Games Running</p>
              </div>
            ) : (
              <div>
                {activeGames.map((game) => (
                  <GameRow
                    key={game.id}
                    game={game}
                    onJoinWaitlist={handleJoinWaitlist}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Promotions */}
          {promotions.length > 0 && (
            <div className="cmd-panel overflow-hidden">
              <div className="p-4 border-b border-[#4A5E78]">
                <h2 className="font-semibold text-white flex items-center gap-2">
                  <Gift className="w-5 h-5 text-[#F59E0B]" />
                  Active Promotions
                </h2>
              </div>
              <div className="divide-y divide-[#4A5E78]">
                {promotions.map((promo) => (
                  <div key={promo.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium text-white">{promo.name}</p>
                      <p className="text-sm text-[#64748B]">{promo.frequency}</p>
                    </div>
                    <span className="text-lg font-bold text-[#10B981]">
                      ${promo.prize_amount?.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Live Games (from /api/commander/games/live) */}
          {liveGames.length > 0 && (
            <div className="cmd-panel overflow-hidden">
              <div className="p-4 border-b border-[#4A5E78] flex items-center justify-between">
                <h2 className="font-semibold text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-[#22D3EE]" />
                  Live Games Now
                </h2>
                <span className="cmd-badge cmd-badge-live text-xs">LIVE</span>
              </div>
              <div>
                {liveGames.map((game) => (
                  <div key={game.id} className="flex items-center justify-between p-4 border-b border-[#4A5E78] last:border-b-0">
                    <div>
                      <p className="font-medium text-white">
                        {game.stakes} {game.game_type?.toUpperCase() || 'NLHE'}
                      </p>
                      <div className="flex items-center gap-3 text-sm text-[#64748B]">
                        {game.commander_tables?.table_number && (
                          <span>Table {game.commander_tables.table_number}</span>
                        )}
                        <span>{game.player_count || 0}/{game.max_players || 9} players</span>
                        {game.waitlist_count > 0 && (
                          <span className="text-[#F59E0B]">{game.waitlist_count} waiting</span>
                        )}
                        <span className={`text-xs font-medium ${game.status === 'running' ? 'text-[#10B981]' : 'text-[#F59E0B]'}`}>
                          {game.status === 'running' ? 'Running' : 'Starting'}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleJoinWaitlist(game)}
                      className="cmd-btn cmd-btn-primary px-4 py-2 text-sm"
                    >
                      Join
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reviews */}
          <div className="cmd-panel overflow-hidden">
            <div className="p-4 border-b border-[#4A5E78]">
              <h2 className="font-semibold text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-[#22D3EE]" />
                Reviews
                {reviewsTotal > 0 && (
                  <span className="text-sm text-[#64748B] font-normal">({reviewsTotal})</span>
                )}
              </h2>
            </div>
            {reviews.length === 0 ? (
              <div className="p-8 text-center">
                <MessageSquare className="w-12 h-12 text-[#4A5E78] mx-auto mb-3" />
                <p className="text-[#64748B]">No Reviews Yet</p>
              </div>
            ) : (
              <div className="divide-y divide-[#4A5E78]">
                {reviews.map((review) => (
                  <div key={review.id} className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-[#22D3EE]/10 flex items-center justify-center overflow-hidden">
                          {review.reviewer?.avatar_url ? (
                            <img src={review.reviewer.avatar_url} alt="" width={32} height={32} loading="lazy" decoding="async" className="w-8 h-8 rounded-full object-cover" />
                          ) : (
                            <Users className="w-4 h-4 text-[#22D3EE]" />
                          )}
                        </div>
                        <span className="font-medium text-white text-sm">
                          {review.reviewer?.display_name || 'Anonymous'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-4 h-4 ${s <= review.overall_rating ? 'text-[#F59E0B] fill-[#F59E0B]' : 'text-[#4A5E78]'}`}
                          />
                        ))}
                      </div>
                    </div>
                    {review.title && (
                      <p className="font-medium text-white text-sm mb-1">{review.title}</p>
                    )}
                    {review.content && (
                      <p className="text-sm text-[#CBD5E1]">{review.content}</p>
                    )}
                    <p className="text-xs text-[#64748B] mt-2">
                      {new Date(review.created_at).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Description */}
          {venue.description && (
            <div className="cmd-panel p-4">
              <h2 className="font-semibold text-white mb-2">About</h2>
              <p className="text-[#64748B]">{venue.description}</p>
            </div>
          )}
        </main>
      </div>
    </>
    </CommanderPageShell>
  );
}
