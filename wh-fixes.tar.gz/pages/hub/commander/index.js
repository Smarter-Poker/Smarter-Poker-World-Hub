/**
 * Player Commander Hub - Browse venues and manage waitlists
 * UI: Dark industrial sci-fi gaming UI with metallic chrome frames
 */
import { useState, useEffect, useRef } from 'react';
import LocationEnableModal from '../../../src/components/ui/LocationEnableModal';
import SEOHead from '../../../src/components/seo/SEOHead';
import Link from 'next/link';
import { MapPin, Search, RefreshCw, AlertCircle, Trophy, FileText, Shield, Zap, Radio, Users, Clock, CreditCard, Globe, Menu } from 'lucide-react';
import VenueCard from '../../../src/components/commander/player/VenueCard';
import WaitlistCard from '../../../src/components/commander/player/WaitlistCard';
import HamburgerMenu from '../../../src/components/ui/HamburgerMenu';
import { supabase } from '../../../src/lib/supabase';
import { getAuthUser, getAccessToken } from '../../../src/lib/authUtils';
import { useAvatar } from '../../../src/contexts/AvatarContext';
// NOTE: PushNotificationProvider removed — _app.js OneSignalProvider covers all pages globally

export default function CommanderHub() {
  const { user } = useAvatar();
  const [venues, setVenues] = useState([]);
  const [confirmLeaveId, setConfirmLeaveId] = useState(null);
  const [myWaitlists, setMyWaitlists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [userLocation, setUserLocation] = useState(null);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [liveGames, setLiveGames] = useState([]);
  const [hasClubPage, setHasClubPage] = useState(null); // null=loading, false=no page, string=page id
  const [menuOpen, setMenuOpen] = useState(false);

  async function fetchVenues() {
    try {
      let url = '/api/commander/venues?limit=30';
      if (userLocation) {
        url += `&lat=${userLocation.lat}&lng=${userLocation.lng}&radius=100`;
      }
      const token = getAccessToken();
      const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch(url, { headers });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = await res.json();
      if (data.success) {
        setVenues(data.data.venues || []);
      }
    } catch (err) {
      console.warn('Failed to fetch venues:', err);
      setError('Failed to load venues');
    } finally {
      setLoading(false);
    }
  }

  async function fetchMyWaitlists() {
    try {
      const token = getAccessToken();
      const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch('/api/commander/waitlist/my', { headers });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = await res.json();
      if (data.success) {
        setMyWaitlists(data.data.entries || []);
      }
    } catch (err) {
      console.warn('Failed to fetch waitlists:', err);
    }
  }

  async function fetchLiveGames() {
    try {
      const token = getAccessToken();
      const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch('/api/commander/games/live?limit=10', { headers });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = await res.json();
      if (data.success) {
        setLiveGames(data.data?.games || []);
      }
    } catch (err) {
      console.warn('Failed to fetch live games:', err);
    }
  }

  function getUserLocation() {
    if (!navigator.geolocation) { setShowLocationModal(true); return; }
    setLocationLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({ lat: position.coords.latitude, lng: position.coords.longitude });
        setLocationLoading(false);
      },
      (err) => { setLocationLoading(false); if (err.code === 1) setShowLocationModal(true); }
    );
  }

  useEffect(() => {
    const _ctrl = new AbortController();
    fetchVenues();
    fetchMyWaitlists();
    fetchLiveGames();
    // Check if user has a club page
    (async () => {
      try {
        const token = getAccessToken();
        if (!token) return;
        const user = getAuthUser();
        if (user) {
          const res = await fetch(`/api/social/pages?owner_id=${user.id}`, { headers: { 'Authorization': `Bearer ${token}` } });
          if (!res.ok) throw new Error(`Request failed (${res.status})`);
          const json = await res.json();
          // 2026-07-25 audit fix: /api/social/pages may return {data:{pages:[...]}}
          // or {data:[...]} — normalize both shapes (venues/[id].js handles both too).
          const pages = Array.isArray(json.data) ? json.data : (json.data?.pages || []);
          if (json.success && pages.length > 0) {
            setHasClubPage(pages[0].id);
          } else {
            setHasClubPage(false);
          }
        }
      } catch (e) { setHasClubPage(false); }
    setLocationLoading(false);
    })();
    return () => _ctrl.abort();
  }, [userLocation]);
  // Realtime listener — live updates for index.js
  // NOTE: user object not available here — use a stable channel name
  useEffect(() => {
    const user = getAuthUser();
    if (!user?.id) return;
    const ch = supabase
      .channel(`cmd-home-live-${Date.now()}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'commander_waitlist', filter: `player_id=eq.${user.id}` }, () => { fetchVenues(); fetchMyWaitlists(); })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'commander_games' }, () => { fetchVenues(); fetchLiveGames(); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [userLocation]);

  const isLeavingRef = useRef(false);

  async function handleLeaveWaitlist(entryId) {
    if (confirmLeaveId !== entryId) {
      setConfirmLeaveId(entryId);
      setTimeout(() => setConfirmLeaveId(null), 4000);
      return;
    }
    
    if (isLeavingRef.current) return;
    isLeavingRef.current = true;
    
    setConfirmLeaveId(null);
    try {
      const token = getAccessToken();
      const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch(`/api/commander/waitlist/${entryId}`, { method: 'DELETE', headers });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = await res.json();
      if (data.success) fetchMyWaitlists();
    } catch (err) {
      console.warn('Failed to leave waitlist:', err);
    } finally {
      isLeavingRef.current = false;
    }
  }

  const filteredVenues = venues.filter(venue =>
    venue.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    venue.city?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <SEOHead
        title="Club Commander"
        description="Smarter.Poker — The Future Of The Game."
        noindex={true}
      />

      <div className="cmd-page">
        {/* Header with chrome rail and glow strip */}
        <header className="cmd-header-full sticky top-0 z-50">
          <div className="max-w-3xl mx-auto px-4 py-5">
            <div className="flex items-center gap-4">
              <div className="cmd-icon-box cmd-icon-box-glow w-14 h-14">
                <Zap className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-wider cmd-text-glow">LIVE POKER</h1>
                <p className="text-sm text-[#64748B] font-medium tracking-wide">Find Games And Join Waitlists</p>
              </div>
              {/* Rivets */}
              <div className="ml-auto flex gap-4 items-center">
                <div className="flex gap-2">
                  <span className="cmd-rivet" />
                  <span className="cmd-rivet" />
                  <span className="cmd-rivet" />
                </div>
                <button onClick={() => setMenuOpen(true)} className="cmd-icon-box hover:cmd-icon-box-glow transition-all" style={{ width: 40, height: 40 }}>
                  <Menu className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-3xl mx-auto px-4 py-8 space-y-8">
          {/* Quick Links - Metallic framed panels */}
          <section className="grid grid-cols-3 gap-4">
            {[
              { href: '/hub/commander/player-card', icon: CreditCard, label: 'My Card', sub: 'Check In' },
              { href: '/hub/commander/leagues', icon: Trophy, label: 'Leagues', sub: 'Compete' },
              { href: '/hub/commander/hand-history', icon: FileText, label: 'Hands', sub: 'Review' },
              { href: '/hub/commander/responsible-gaming', icon: Shield, label: 'Limits', sub: 'Settings' },
              { href: hasClubPage ? `/hub/social-media?viewPage=${hasClubPage}` : '/hub/social-media?createPage=true', icon: Globe, label: hasClubPage ? 'Club Page' : 'Create Page', sub: hasClubPage ? 'Edit' : 'Build' },
            ].map(({ href, icon: Icon, label, sub }) => (
              <Link
                key={href}
                href={href}
                className="cmd-panel cmd-corner-lights p-5 hover:shadow-[0_0_30px_rgba(34,211,238,0.3)] transition-all group text-center block"
              >
                {/* Corner glow lights */}
                <span className="cmd-light cmd-light-tl" />
                <span className="cmd-light cmd-light-br" />

                {/* Rivets */}
                <div className="absolute top-3 left-3"><span className="cmd-rivet cmd-rivet-sm" /></div>
                <div className="absolute top-3 right-3"><span className="cmd-rivet cmd-rivet-sm" /></div>
                <div className="absolute bottom-3 left-3"><span className="cmd-rivet cmd-rivet-sm" /></div>
                <div className="absolute bottom-3 right-3"><span className="cmd-rivet cmd-rivet-sm" /></div>

                <div className="cmd-icon-box w-14 h-14 mx-auto mb-4 group-hover:cmd-icon-box-glow transition-all">
                  <Icon className="w-7 h-7" />
                </div>
                <p className="font-bold text-white text-lg group-hover:text-[#22D3EE] transition-colors">{label}</p>
                <p className="text-xs text-[#64748B] font-semibold uppercase tracking-widest mt-1">{sub}</p>
              </Link>
            ))}
          </section>

          {/* My Waitlists */}
          {myWaitlists.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-4">
                <div className="cmd-badge cmd-badge-live">
                  <span className="cmd-live-dot" style={{ width: 8, height: 8 }} />
                  MY WAITLISTS
                </div>
              </div>
              <div className="space-y-4">
                {myWaitlists.map((entry) => (
                  <WaitlistCard
                    key={entry.waitlist_entry.id}
                    entry={entry}
                    onLeave={() => handleLeaveWaitlist(entry.waitlist_entry.id)}
                    confirmingLeave={confirmLeaveId === entry.waitlist_entry.id}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Live Games */}
          {liveGames.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-4">
                <div className="cmd-badge cmd-badge-live">
                  <span className="cmd-live-dot" style={{ width: 8, height: 8 }} />
                  LIVE GAMES NOW
                </div>
              </div>
              <div className="space-y-3">
                {liveGames.slice(0, 5).map((game) => (
                  <div key={game.id} className="cmd-panel p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-white">
                          {game.stakes} {game.game_type?.toUpperCase() || 'NLHE'}
                        </p>
                        <p className="text-sm text-[#64748B]">
                          {game.poker_venues?.name || 'Unknown Venue'}
                          {game.poker_venues?.city && ` - ${game.poker_venues.city}, ${game.poker_venues.state}`}
                        </p>
                        <div className="flex items-center gap-3 text-sm text-[#64748B] mt-1">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {game.player_count || 0}/{game.max_players || 9}
                          </span>
                          {game.waitlist_count > 0 && (
                            <span className="text-[#F59E0B] flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {game.waitlist_count} waiting
                            </span>
                          )}
                          <span className={`text-xs font-medium ${game.status === 'running' ? 'text-[#10B981]' : 'text-[#F59E0B]'}`}>
                            {game.status === 'running' ? 'Running' : 'Starting'}
                          </span>
                        </div>
                      </div>
                      {game.poker_venues?.id && (
                        <a
                          href={`/hub/commander/venues/${game.poker_venues.id}`}
                          className="cmd-btn cmd-btn-secondary px-3 py-2 text-sm"
                        >
                          View
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Search */}
          <section>
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-5 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#64748B]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search Venues..."
                  className="cmd-input pl-14"
                />
              </div>
              <button
                onClick={getUserLocation}
                disabled={locationLoading}
                className="cmd-btn cmd-btn-secondary"
                title="Use My Location"
              >
                {locationLoading ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <MapPin className="w-5 h-5" />
                )}
              </button>
            </div>
            {userLocation && (
              <div className="mt-4">
                <span className="cmd-badge cmd-badge-live">
                  <MapPin className="w-4 h-4" />
                  NEAR YOU
                </span>
              </div>
            )}
          </section>

          {/* Glow strip separator */}
          <div className="cmd-glow-strip" />

          {/* Venues */}
          <section>
            <div className="flex items-center gap-3 mb-5">
              <div className="cmd-header-bar">
                <Radio className="w-5 h-5 text-[#22D3EE]" />
                <span className="cmd-header-bar-text">VENUES WITH LIVE GAMES</span>
              </div>
            </div>

            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="cmd-panel p-6 animate-pulse">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-[#1A2E4A]" />
                      <div className="flex-1">
                        <div className="h-6 bg-[#1A2E4A] rounded w-1/3 mb-3" />
                        <div className="h-4 bg-[#1A2E4A] rounded w-1/4" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="cmd-panel cmd-corner-lights p-10 text-center">
                <span className="cmd-light cmd-light-tl" />
                <span className="cmd-light cmd-light-tr" />
                <span className="cmd-light cmd-light-bl" />
                <span className="cmd-light cmd-light-br" />
                <div className="cmd-icon-box mx-auto mb-5" style={{ borderColor: '#EF4444', color: '#EF4444' }}>
                  <AlertCircle className="w-7 h-7" />
                </div>
                <p className="text-[#CBD5E1] font-semibold text-lg">{error}</p>
                <button onClick={fetchVenues} className="cmd-btn cmd-btn-primary mt-6">
                  RETRY CONNECTION
                </button>
              </div>
            ) : filteredVenues.length === 0 ? (
              <div className="cmd-panel cmd-corner-lights p-10 text-center">
                <span className="cmd-light cmd-light-tl" />
                <span className="cmd-light cmd-light-tr" />
                <span className="cmd-light cmd-light-bl" />
                <span className="cmd-light cmd-light-br" />
                <div className="cmd-icon-box mx-auto mb-5">
                  <MapPin className="w-7 h-7" />
                </div>
                <p className="text-[#CBD5E1] font-semibold text-lg">
                  {searchQuery ? 'No venues match your search' : 'No poker venues found'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredVenues.map((venue) => {
                  const venueGames = liveGames.filter(g =>
                    g.venue_id === venue.id || g.poker_venues?.id === venue.id
                  );
                  const waitlistCounts = {};
                  venueGames.forEach(g => {
                    const key = `${g.game_type}-${g.stakes}`;
                    if (g.waitlist_count) waitlistCounts[key] = g.waitlist_count;
                  });
                  return (
                    <VenueCard key={venue.id} venue={venue} games={venueGames} waitlistCounts={waitlistCounts} />
                  );
                })}
              </div>
            )}
          </section>

          {/* Divider */}
          <div className="cmd-divider" />

          {/* Footer */}
          <div className="text-center pb-8">
            <p className="text-xs text-[#64748B] uppercase tracking-[0.3em] mb-2">Powered By</p>
            <p className="text-xl font-extrabold cmd-text-chrome tracking-wider">CLUB COMMANDER</p>
          </div>
        </main>

        {showLocationModal && (
          <LocationEnableModal
            onClose={() => setShowLocationModal(false)}
            onRetry={() => { setShowLocationModal(false); getUserLocation(); }}
            onManualEntry={() => setShowLocationModal(false)}
          />
        )}

        <HamburgerMenu
          isOpen={menuOpen}
          onClose={() => setMenuOpen(false)}
          direction="right"
          theme="dark"
          user={user}
        />
      </div>
    </>
  );
}
