/**
 * Digital Player Card
 * /hub/commander/player-card
 * QR code for instant check-in, quick actions, membership display
 */
import { useState, useEffect, useRef } from 'react';
import useSWR from 'swr';
import { useRouter } from 'next/router';
import SEOHead from '../../../src/components/seo/SEOHead';
import { ArrowLeft, QrCode, CreditCard, Users, Clock, Gift, Star, Loader2, RefreshCw, Trophy, Crown } from 'lucide-react';
import { useRequireAuth, getAccessToken } from '../../../src/lib/authUtils';
import useTrainingBus from '../../../src/hooks/useTrainingBus';
import CommanderPageShell from '../../../src/components/commander/CommanderPageShell';

const TIER_COLORS = {
  bronze: { bg: 'linear-gradient(135deg, #92400E, #D97706)', text: '#FFFBEB' },
  silver: { bg: 'linear-gradient(135deg, #6B7280, #D1D5DB)', text: '#F9FAFB' },
  gold: { bg: 'linear-gradient(135deg, #B45309, #FCD34D)', text: '#FFFBEB' },
  platinum: { bg: 'linear-gradient(135deg, #1E3A5F, #60A5FA)', text: '#EBF5FF' },
  diamond: { bg: 'linear-gradient(135deg, #4C1D95, #A78BFA)', text: '#F5F3FF' },
};

export default function PlayerCard() {
  const router = useRouter();
  const [qrData, setQrData] = useState(null);
  // 2026-07-25 audit fix: real scannable QR image (data URL) — the old SVG
  // dot pattern was decorative and could not be read by any scanner.
  const [qrImageUrl, setQrImageUrl] = useState(null);
  const [qrRefresh, setQrRefresh] = useState(0);
  const intervalRef = useRef(null);

  const { checking: authChecking } = useRequireAuth('/hub/commander/player-card');
  useTrainingBus('player-card');

  const getToken = () => getAccessToken();

  // QR rotation timer
  useEffect(() => {
    intervalRef.current = setInterval(() => setQrRefresh(r => r + 1), 30000);
    return () => clearInterval(intervalRef.current);
  }, []);

  // SWR-backed profile fetch
  const { data: player, isLoading: loading } = useSWR('/api/hub/profile', (url) => {
    const token = getToken();
    if (!token) return null; // useRequireAuth handles redirect
    return fetch(url, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(json => json.success || json.data ? (json.data || json) : null);
  });

  useEffect(() => {
    if (player) generateQR();
  }, [player, qrRefresh]);

  const generateQR = () => {
    // QR payload: timestamped token for scanning
    const ts = Date.now();
    const payload = JSON.stringify({
      pid: player?.id,
      ts,
      exp: ts + 30000, // 30 second expiry
      v: 1
    });
    // Base64 encode for QR
    const encoded = btoa(payload);
    setQrData(encoded);
    // 2026-07-25 audit fix: encode the SAME payload into a real QR image via
    // the qrcode package so kiosks can actually scan it.
    import('qrcode')
      .then(QRCode => (QRCode.default || QRCode).toDataURL(encoded, { width: 180, margin: 1 }))
      .then(url => setQrImageUrl(url))
      .catch(err => {
        console.warn('[player-card] QR render failed:', err?.message || err);
        setQrImageUrl(null);
      });
  };

  const quickActions = [
    { label: 'Join Waitlist', icon: Users, href: '/hub/commander/venues', color: '#1877F2' },
    { label: 'My Rewards', icon: Gift, href: '/hub/commander/rewards', color: '#F59E0B' },
    { label: 'Tournaments', icon: Trophy, href: '/hub/commander/tournaments', color: '#8B5CF6' },
    { label: 'Session History', icon: Clock, href: '/hub/commander/history', color: '#10B981' },
    { label: 'Rate Table', icon: Star, href: '/hub/commander/rate-table', color: '#EF4444' },
    { label: 'Request Service', icon: CreditCard, href: '/hub/commander/services', color: '#3B82F6' },
  ];

  const tier = player?.tier || player?.membership_tier || 'bronze';
  const tierStyle = TIER_COLORS[tier] || TIER_COLORS.bronze;

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', background: '#111827', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Loader2 size={32} color="#1877F2" className="spin" />
      </div>
    );
  }

  return (
    <CommanderPageShell>
    <>
      <SEOHead
        title="Player Card"
        description="Smarter.Poker — The Future Of The Game."
        noindex={true}
      />
      <div style={{ minHeight: '100vh', background: '#111827', fontFamily: 'Inter, system-ui, sans-serif' }}>
        {/* Header */}
        <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={() => router.push('/hub/commander')} style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer', padding: 4 }}>
            <ArrowLeft size={22} />
          </button>
          <QrCode size={22} color="white" />
          <span style={{ color: 'white', fontWeight: 700, fontSize: 17 }}>Digital Player Card</span>
        </div>

        <div style={{ padding: '0 16px 24px', maxWidth: 420, margin: '0 auto' }}>
          {/* Card */}
          <div style={{
            borderRadius: 20, overflow: 'hidden', marginBottom: 20,
            background: tierStyle.bg, color: tierStyle.text,
            boxShadow: '0 20px 60px rgba(0,0,0,0.5)'
          }}>
            {/* Card Top */}
            <div style={{ padding: '24px 20px 16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, opacity: 0.8 }}>Smarter.Poker</div>
                  <div style={{ fontSize: 24, fontWeight: 800, marginTop: 4 }}>
                    {player?.display_name || player?.full_name || 'Player'}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Crown size={16} />
                  <span style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase' }}>{tier}</span>
                </div>
              </div>

              {/* Member info */}
              <div style={{ display: 'flex', gap: 20, fontSize: 12, opacity: 0.85 }}>
                <div>
                  <div style={{ opacity: 0.7, fontSize: 10 }}>MEMBER SINCE</div>
                  <div style={{ fontWeight: 600 }}>
                    {player?.created_at ? new Date(player.created_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—'}
                  </div>
                </div>
                <div>
                  <div style={{ opacity: 0.7, fontSize: 10 }}>MEMBER ID</div>
                  <div style={{ fontWeight: 600, fontFamily: 'monospace' }}>{(player?.id || '').slice(0, 8).toUpperCase()}</div>
                </div>
              </div>
            </div>

            {/* QR Code */}
            <div style={{ background: 'white', margin: '0 16px 16px', borderRadius: 14, padding: 16, textAlign: 'center' }}>
              <div style={{ display: 'inline-block', padding: 8, background: 'white', borderRadius: 8 }}>
                {qrData && qrImageUrl ? (
                  <div style={{ position: 'relative' }}>
                    {/* 2026-07-25 audit fix: real scannable QR (qrcode package)
                        encoding the same qrData payload — replaces the
                        decorative SVG dot pattern scanners couldn't read. */}
                    <img
                      src={qrImageUrl}
                      alt="Player check-in QR code"
                      width={180}
                      height={180}
                      style={{ display: 'block' }}
                    />
                    <div style={{ position: 'absolute', bottom: -4, right: -4 }}>
                      <button onClick={() => setQrRefresh(r => r + 1)}
                        style={{ background: '#F0F2F5', border: 'none', borderRadius: '50%', width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                        <RefreshCw size={14} color="#65676B" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div style={{ width: 180, height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Loader2 size={24} color="#65676B" className="spin" />
                  </div>
                )}
              </div>
              <div style={{ marginTop: 8, fontSize: 11, color: '#65676B' }}>
                Scan at kiosk or show to staff • Refreshes every 30s
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#9CA3AF', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 }}>
              Quick Actions
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              {quickActions.map(a => (
                <button key={a.label} onClick={() => router.push(a.href)}
                  style={{
                    background: '#1F2937', border: '1px solid #374151', borderRadius: 12, padding: '14px 8px',
                    cursor: 'pointer', textAlign: 'center', transition: 'all 0.15s'
                  }}>
                  <a.icon size={22} color={a.color} style={{ margin: '0 auto 6px' }} />
                  <div style={{ fontSize: 11, color: '#D1D5DB', fontWeight: 600 }}>{a.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          {player && (
            <div style={{ background: '#1F2937', borderRadius: 14, border: '1px solid #374151', padding: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#9CA3AF', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                My Stats
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
                {[
                  { label: 'Total Sessions', val: player.total_sessions || player.session_count || '—' },
                  { label: 'Hours Played', val: player.total_hours || player.play_hours || '—' },
                  { label: 'Comp Balance', val: player.comp_balance ? `$${player.comp_balance}` : '—' },
                  { label: 'Achievements', val: player.achievements_count || player.badges?.length || '—' },
                ].map(s => (
                  <div key={s.label} style={{ padding: 10, background: '#111827', borderRadius: 10, textAlign: 'center' }}>
                    <div style={{ fontSize: 20, fontWeight: 800, color: 'white' }}>{s.val}</div>
                    <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 2 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`.spin { animation: spin 1s linear infinite; } @keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </>
    </CommanderPageShell>
  );
}
