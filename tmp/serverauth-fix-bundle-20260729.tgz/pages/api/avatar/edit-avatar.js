import { getServerUserWithFallback } from '../../../src/lib/serverAuth';
/**
 * 🎨 AI AVATAR EDIT - IMAGE EDITING
 * Uses Grok Vision to analyze existing avatar + grok-2-image-1212 to regenerate with edits
 * Uses Sharp (Node.js native) for professional-grade background removal
 * 
 * Created 2026-01-29: Edit existing avatars with AI
 */

import { getGrokClient } from '../../../src/lib/grokClient';
import { createClient } from '../../../src/lib/supabaseServerClient';
import sharp from 'sharp';
import { reportApiError } from '../../../src/lib/sentryWrap';

import { applyRateLimit, LIMITS } from '../../../src/lib/apiRateLimit';

export const config = {
    maxDuration: 60, // 60 second timeout for Vercel
};

// Use Grok for image generation
const grok = getGrokClient();

let _supabase = null;
function getSupabase() {
    if (!_supabase) {
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://kuklfnapbkmacvwxktbh.supabase.co';
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
        _supabase = createClient(url, key);
    }
    return _supabase;
}

/**
 * Remove white/near-white background using Sharp with multi-threshold algorithm
 */
async function removeBackgroundWithSharp(inputBuffer) {
    const { data, info } = await sharp(inputBuffer)
        .ensureAlpha()
        .raw()
        .toBuffer({ resolveWithObject: true });

    const pixels = new Uint8ClampedArray(data);
    const { width, height } = info;

    const whiteThreshold = 240;
    const nearWhiteThreshold = 225;
    const grayThreshold = 200;

    for (let i = 0; i < pixels.length; i += 4) {
        const r = pixels[i];
        const g = pixels[i + 1];
        const b = pixels[i + 2];

        const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
        const isWhite = r > whiteThreshold && g > whiteThreshold && b > whiteThreshold;
        const isNearWhite = r > nearWhiteThreshold && g > nearWhiteThreshold && b > nearWhiteThreshold;

        const maxChannel = Math.max(r, g, b);
        const minChannel = Math.min(r, g, b);
        const colorVariance = maxChannel - minChannel;
        const isGrayish = luminance > grayThreshold && colorVariance < 30;
        const isCheckerboard = (r > 200 && g > 200 && b > 200) && colorVariance < 15;

        if (isWhite || isNearWhite || isGrayish || isCheckerboard) {
            pixels[i + 3] = 0;
        }
    }

    // Corner-based background detection
    const cornerPositions = [
        0,
        (width - 1) * 4,
        (height - 1) * width * 4,
        ((height - 1) * width + (width - 1)) * 4,
    ];

    for (const pos of cornerPositions) {
        if (pixels[pos + 3] !== 0) {
            const cornerR = pixels[pos];
            const cornerG = pixels[pos + 1];
            const cornerB = pixels[pos + 2];

            if (cornerR > 180 && cornerG > 180 && cornerB > 180) {
                for (let i = 0; i < pixels.length; i += 4) {
                    const r = pixels[i];
                    const g = pixels[i + 1];
                    const b = pixels[i + 2];

                    const tolerance = 35;
                    if (Math.abs(r - cornerR) < tolerance &&
                        Math.abs(g - cornerG) < tolerance &&
                        Math.abs(b - cornerB) < tolerance) {
                        pixels[i + 3] = 0;
                    }
                }
            }
        }
    }

    return sharp(pixels, {
        raw: { width: info.width, height: info.height, channels: 4 }
    })
        .png({ compressionLevel: 9 })
        .toBuffer();
}

export default async function handler(req, res) {
  try {
    if (!applyRateLimit(req, res, LIMITS.ai)) return;

      // Require JWT auth for write operations
      if (req.method !== 'GET') {
          const _token = req.headers.authorization?.replace('Bearer ', '');
          if (!_token) return res.status(401).json({ success: false, error: 'Authentication required' });
          // BUGFIX: this previously referenced undeclared `_authErr`, which threw a
          // ReferenceError on EVERY authenticated request and turned all avatar
          // edits into 500s. Use the destructured values directly.
          const { user: authUser, error: authErr } = await getServerUserWithFallback(req, getSupabase());
          if (authErr || !authUser) return res.status(401).json({ success: false, error: 'Invalid token' });
          if (req.body) req.body.userId = authUser.id;
      }
      if (req.method !== 'POST') {
          return res.status(405).json({ success: false, error: 'Method not allowed' });
      }

      try {
          const { imageUrl, editPrompt, userId } = req.body;

          if (!imageUrl) {
              return res.status(400).json({ success: false, error: 'Image URL is required' });
          }

          if (!editPrompt) {
              return res.status(400).json({ success: false, error: 'Edit prompt is required' });
          }

          // Get the original prompt to preserve the character
          const { originalPrompt } = req.body;


          // Download the original image and convert to base64
          // IMPROVED APPROACH: Combine original prompt with edit to preserve character

          const editedPrompt = `Create a 3D Pixar-style CHARACTER PORTRAIT.

  ORIGINAL CHARACTER: ${originalPrompt || 'A character'}

  MODIFICATION: ${editPrompt}

  STRICT RULES:
  - Keep the SAME character as described in "ORIGINAL CHARACTER"
  - Apply ONLY the modification described in "MODIFICATION"
  - PURE WHITE BACKGROUND (#FFFFFF)
  - Head and upper shoulders only (bust portrait)
  - High quality 3D render
  - Professional character design
  - Maintain the same art style and character identity`;

          const imageResponse = await grok.images.generate({
              model: "dall-e-3", // Mapped to grok-2-image by grokClient
              prompt: editedPrompt,
              n: 1,
          });

          if (!imageResponse?.data?.[0]?.url) {
              throw new Error('Grok API returned no image URL');
          }

          const newImageUrl = imageResponse.data[0].url;

          // Download the edited image
          const editedImageResponse = await fetch(newImageUrl);
          const editedBuffer = Buffer.from(await editedImageResponse.arrayBuffer());

          const transparentBuffer = await removeBackgroundWithSharp(editedBuffer);

          const timestamp = Date.now();
          const safeUserId = userId || 'anonymous';
          const filename = `edited_${safeUserId}_${timestamp}.png`;
          const storagePath = `generated/${filename}`;

          const { data: uploadData, error: uploadError } = await getSupabase().storage
              .from('custom-avatars')
              .upload(storagePath, transparentBuffer, {
                  contentType: 'image/png',
                  cacheControl: '3600',
                  upsert: true
              });

          if (uploadError) {
              console.warn('❌ Supabase upload error:', uploadError);
              throw new Error('Failed to upload avatar to storage');
          }

          const { data: { publicUrl } } = getSupabase().storage
              .from('custom-avatars')
              .getPublicUrl(storagePath);


          // Update the avatar in the database gallery
          // Find the most recent avatar for this user and update it with the edited version
          if (userId) {
              const { data: existingAvatars, error: fetchError } = await getSupabase()
                  .from('custom_avatar_gallery')
                  .select('id')
                  .eq('user_id', userId)
                  .eq('is_deleted', false)
                  .order('created_at', { ascending: false })
                  .limit(1);

              if (!fetchError && existingAvatars && existingAvatars.length > 0) {
                  // Update the most recent avatar with the edited version
                  const { error: updateError } = await getSupabase()
                      .from('custom_avatar_gallery')
                      .update({
                          image_url: publicUrl,
                          prompt: `${editPrompt} (edited)`,
                          updated_at: new Date().toISOString()
                      })
                      .eq('id', existingAvatars[0].id);

                  if (updateError) {
                      console.warn('⚠️ Failed to update gallery:', updateError);
                  } else {
                  }
              }
          }

          return res.status(200).json({
              success: true,
              imageUrl: publicUrl,
              editApplied: editPrompt
          });

      } catch (error) {
          console.warn('❌ Avatar edit error:', error);
          console.warn('Error details:', {
              message: error.message,
              status: error.status,
              response: error.response?.data,
              stack: error.stack
          });
          return res.status(500).json({
              success: false,
              error: error.message || 'Failed to edit avatar',
              details: error.response?.data || error.toString()
          });
      }

  } catch (err) {
      try { reportApiError(err, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
    console.warn('[API Error]', err);
    if (!res.headersSent) return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}
// Force fresh deployment 1769671621
