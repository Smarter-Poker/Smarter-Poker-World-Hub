import { getServerUserWithFallback } from '../../../../src/lib/serverAuth';
/**
 * Venue Claim API
 *
 * POST: Submit a venue ownership claim
 * GET: Check claim status for a venue
 */

import { supabase } from '../../../../src/lib/supabase';
import { createClient } from '../../../../src/lib/supabaseServerClient';
import { applyRateLimit, LIMITS } from '../../../../src/lib/apiRateLimit';
import { reportApiError } from '../../../../src/lib/sentryWrap';

let _supabase = null;
function getSupabase() {
    if (!_supabase) {
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://kuklfnapbkmacvwxktbh.supabase.co';
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
        _supabase = createClient(url, key);
    }
    return _supabase;
}

// Generate a 4-digit verification code
function generateVerificationCode() {
    return Math.floor(1000 + Math.random() * 9000).toString();
}

export default async function handler(req, res) {
  try {
    // CDN cache: fresh for 60s, serve stale up to 300s
    if (req.method === 'GET') {
      res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
    }

    if (['POST','PUT','PATCH','DELETE'].includes(req.method)) {
      if (!applyRateLimit(req, res, LIMITS.write)) return;
    }

      if (req.method === 'GET') {
          return handleGet(req, res);
      } else if (req.method === 'POST') {
          return handlePost(req, res);
      }

      return res.status(405).json({ success: false, error: 'Method not allowed' });

  } catch (err) {
    try { reportApiError(err, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
    console.warn('[API Error]', err);
    if (!res.headersSent) return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

async function handleGet(req, res) {
    try {
        const safeQ = (v) => v ? (Array.isArray(v) ? String(v[0]) : typeof v === 'object' ? null : String(v)) : v;
        const venue_id = safeQ(req.query.venue_id);

        if (!venue_id) {
            return res.status(400).json({ success: false, error: 'venue_id required' });
        }

        // Get auth user
        const authHeader = req.headers.authorization;
        let userId = null;

        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.replace('Bearer ', '');
            const { user: authUser, error: authErr } = await getServerUserWithFallback(req, getSupabase());
    const authData = { user: authUser };
            const user = authData?.user;
            userId = user?.id;
        }

        // Check if venue is claimed
        const { data: venue, error: venueError } = await getSupabase()
            .from('poker_venues')
            .select('id, name, is_claimed, claimed_at')
            .eq('id', parseInt(venue_id))
            .maybeSingle();

        if (venueError || !venue) {
            return res.status(404).json({ success: false, error: 'Venue not found' });
        }

        // Get user's claim status if logged in
        let userClaim = null;
        if (userId) {
            const { data: claim } = await getSupabase()
                .from('venue_claims')
                .select('id, status, created_at, updated_at')
                .eq('venue_id', parseInt(venue_id))
                .eq('user_id', userId)
                .order('created_at', { ascending: false })
                .limit(1)
                .maybeSingle();

            userClaim = claim;
        }

        // Check if user is a manager
        let isManager = false;
        if (userId) {
            const { data: manager } = await getSupabase()
                .from('venue_managers')
                .select('id, role')
                .eq('venue_id', parseInt(venue_id))
                .eq('user_id', userId)
                .eq('is_active', true)
                .maybeSingle();

            isManager = !!manager;
        }

        return res.status(200).json({
            venue_id: venue.id,
            venue_name: venue.name,
            is_claimed: venue.is_claimed,
            claimed_at: venue.claimed_at,
            user_claim: userClaim,
            is_manager: isManager
        });

    } catch (error) {
        console.warn('Venue claim GET error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
}

async function handlePost(req, res) {
    try {
        // Get auth user
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, error: 'Authentication required' });
        }

        const token = authHeader.replace('Bearer ', '');
        const { user: authUser, error: authErr } = await getServerUserWithFallback(req, getSupabase());
    const authData = { user: authUser };
        const user = authData?.user;

        if (authErr || !user) {
            return res.status(401).json({ success: false, error: 'Invalid or expired token' });
        }

        const {
            venue_id,
            claimant_name,
            claimant_title,
            claimant_email,
            claimant_phone,
            verification_method = 'email',
            notes
        } = req.body;

        // Validate required fields
        if (!venue_id || !claimant_name || !claimant_email) {
            return res.status(400).json({
                success: false, error: 'Missing required fields',
                required: ['venue_id', 'claimant_name', 'claimant_email']
            });
        }

        // Check venue exists
        const { data: venue, error: venueError } = await getSupabase()
            .from('poker_venues')
            .select('id, name, is_claimed, phone')
            .eq('id', parseInt(venue_id))
            .maybeSingle();

        if (venueError || !venue) {
            return res.status(404).json({ success: false, error: 'Venue not found' });
        }

        // Check if venue is already claimed
        if (venue.is_claimed) {
            return res.status(400).json({
                success: false, error: 'Venue already claimed',
                message: 'This venue has already been claimed by another user. Contact support if you believe this is an error.'
            });
        }

        // Check for existing pending claim by this user
        const { data: existingClaim } = await getSupabase()
            .from('venue_claims')
            .select('id, status')
            .eq('venue_id', parseInt(venue_id))
            .eq('user_id', user.id)
            .in('status', ['pending', 'under_review'])
            .maybeSingle();

        if (existingClaim) {
            return res.status(400).json({
                success: false, error: 'Claim already submitted',
                claim_id: existingClaim.id,
                status: existingClaim.status
            });
        }

        // Generate verification code
        const verificationCode = generateVerificationCode();

        // Create the claim
        const { data: claim, error: claimError } = await getSupabase()
            .from('venue_claims')
            .insert({
                venue_id: parseInt(venue_id),
                user_id: user.id,
                status: 'pending',
                verification_method,
                claimant_name,
                claimant_title,
                claimant_email,
                claimant_phone,
                verification_code: verificationCode,
                claimant_notes: notes
            })
            .select()
            .maybeSingle();

        if (claimError) {
            console.warn('Error creating claim:', claimError);
            return res.status(500).json({ success: false, error: 'Failed to create claim' });
        }

        // Log the claim submission
        const { error: err_venue_verification_log_lrup4 } = await getSupabase()
          .from('venue_verification_log')
          .insert({
                claim_id: claim.id,
                venue_id: parseInt(venue_id),
                action: 'claim_submitted',
                performed_by: user.id,
                details: {
                    verification_method,
                    claimant_email
                },
                ip_address: req.headers['x-forwarded-for'] || req.socket?.remoteAddress,
                user_agent: req.headers['user-agent']
            });
        if (err_venue_verification_log_lrup4) console.warn('[Supabase] Silent mutation failed in venue_verification_log:', err_venue_verification_log_lrup4.message);

        // TODO: Send verification code via email/phone based on method
        // For now, we'll return success and let admin handle verification
        // In production:
        // - If method is 'email': Send email with code
        // - If method is 'phone': Send SMS with code
        // - If method is 'document': Direct to document upload

        return res.status(201).json({
            success: true,
            claim_id: claim.id,
            status: claim.status,
            verification_method,
            message: `Claim submitted successfully. ${verification_method === 'email'
                ? 'Check your email for verification instructions.'
                : verification_method === 'phone'
                    ? 'You will receive an SMS with a verification code.'
                    : 'Our team will review your claim within 1-2 business days.'
                }`,
            // In development, include the code for testing
            ...(process.env.NODE_ENV === 'development' ? { verification_code: verificationCode } : {})
        });

    } catch (error) {
        try { reportApiError(error, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
        console.warn('Venue claim POST error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
}
