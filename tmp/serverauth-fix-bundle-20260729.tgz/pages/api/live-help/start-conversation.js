import { getServerUserWithFallback } from '../../../src/lib/serverAuth';
/* ═══════════════════════════════════════════════════════════════════════════
   API: Start Live Help Conversation
   Creates new conversation or resumes existing active one
   ═══════════════════════════════════════════════════════════════════════════ */

import { createClient } from '../../../src/lib/supabaseServerClient';
import { applyRateLimit, LIMITS } from '../../../src/lib/apiRateLimit';
import { reportApiError } from '../../../src/lib/sentryWrap';

let _supabase = null;
function getSupabase() {
    if (!_supabase) {
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://kuklfnapbkmacvwxktbh.supabase.co';
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
        _supabase = createClient(url, key);
    }
    return _supabase;
}


const AGENTS = ['jarvis']; // Single comprehensive expert


export default async function handler(req, res) {
  try {
    if (['POST','PUT','PATCH','DELETE'].includes(req.method)) {
      if (!applyRateLimit(req, res, LIMITS.write)) return;
    }

      if (req.method !== 'POST') {
          return res.status(405).json({ error: 'Method not allowed' });
      }

      try {
          // Get authenticated user from Authorization header
          const authHeader = req.headers.authorization;
          if (!authHeader?.startsWith('Bearer ')) {
              return res.status(401).json({ error: 'Unauthorized' });
          }

          const token = authHeader.replace('Bearer ', '');
          const { user: authUser, error: authErr } = await getServerUserWithFallback(req, getSupabase());
    const authData = { user: authUser };
          const user = authData?.user;

          if (authErr || !user) {
              return res.status(401).json({ error: 'Invalid token' });
          }

          // Fetch user profile for personalized greeting
          const { data: profile } = await getSupabase()
              .from('profiles')
              .select('first_name, username')
              .eq('id', user.id)
              .maybeSingle();

          const userName = profile?.first_name || profile?.username || 'there';

          const { agentId, context } = req.body;

          // Check for existing active conversation
          const { data: existingConversation } = await getSupabase()
              .from('live_help_conversations')
              .select('*, live_help_messages(*)')
              .eq('user_id', user.id)
              .eq('status', 'active')
              .order('created_at', { ascending: false })
              .limit(1)
              .maybeSingle();

          if (existingConversation) {
              // Resume existing conversation
              return res.status(200).json({
                  conversationId: existingConversation.id,
                  agentId: existingConversation.agent_id,
                  greeting: null, // No greeting for resumed conversations
                  messages: existingConversation.live_help_messages || []
              });
          }

          // Create new conversation
          const selectedAgent = agentId || AGENTS[Math.floor(Math.random() * AGENTS.length)];

          const { data: conversation, error: convError } = await getSupabase()
              .from('live_help_conversations')
              .insert({
                  user_id: user.id,
                  agent_id: 'jarvis',
                  status: 'active'
              })
              .select()
              .maybeSingle();

          if (convError) {
              console.warn('[LiveHelp] Failed to create conversation:', {
                  error: convError,
                  message: convError.message,
                  details: convError.details,
                  hint: convError.hint,
                  code: convError.code
              });
              return res.status(500).json({
                  error: 'Failed to create conversation',
                  details: convError.message,
                  hint: convError.hint
              });
          }

          // Create personalized greeting message
          const greetingMessage = `Hi ${userName}! I'm Jarvis, your Smarter.Poker expert. I can help you with:\n\n• Training games and GTO strategy\n• Club Arena and tournament management\n• Diamond Store and VIP features\n• Social features and messaging\n• Technical support and troubleshooting\n\nWhat can I help you with today?`;

          const { data: greeting, error: greetingError } = await getSupabase()
              .from('live_help_messages')
              .insert({
                  conversation_id: conversation.id,
                  sender_type: 'agent',
                  agent_id: selectedAgent,
                  content: greetingMessage,
                  metadata: { isGreeting: true }
              })
              .select()
              .maybeSingle();

          if (greetingError) {
              console.warn('Failed to create greeting message:', greetingError);
          }

          return res.status(200).json({
              conversationId: conversation.id,
              agentId: selectedAgent,
              greeting: greeting?.content || greetingMessage,
              messages: greeting ? [greeting] : []
          });

      } catch (error) {
          console.warn('Start conversation error:', error);
          return res.status(500).json({ error: 'Internal server error' });
      }

  } catch (err) {
      try { reportApiError(err, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
    console.warn('[API Error]', err);
    if (!res.headersSent) return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

/**
 * Get greeting message for Jarvis
 */
function getAgentGreeting(agentId) {
    return "Hi! I'm Jarvis, I can help you with anything you have a question about. What can I help you with?";
}

