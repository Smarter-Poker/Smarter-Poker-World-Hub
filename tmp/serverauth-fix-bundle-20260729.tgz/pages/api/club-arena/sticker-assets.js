/**
 * GET /api/club-arena/sticker-assets
 * Returns all active sticker_assets for the Club Arena lobby.
 * Auth: Bearer token (any authenticated user)
 */
import { createClient } from '../../../src/lib/supabaseServerClient';
import { applyRateLimit, LIMITS } from '../../../src/lib/apiRateLimit';
import { getServerUserWithFallback } from '../../../src/lib/serverAuth';
import { reportApiError } from '../../../src/lib/sentryWrap';

let _supabase = null;
function getSupabase() {
    if (!_supabase) {
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://kuklfnapbkmacvwxktbh.supabase.co';
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY not configured');
        _supabase = createClient(url, key);
    }
    return _supabase;
}

export default async function handler(req, res) {
  try {
      if (req.method !== 'GET') return res.status(405).json({ error: 'GET only' });
    if (!applyRateLimit(req, res, LIMITS.read)) return;

      // Auth: local HMAC verify first, GoTrue network fallback if JWT secret missing
      const { user } = await getServerUserWithFallback(req, getSupabase());
      if (!user) return res.status(401).json({ error: 'Auth required' });

      try {
          const { data: stickers, error } = await getSupabase()
              .from('sticker_assets')
              .select('key, label, category, storage_path, applies_to, is_dynamic, dynamic_field, sort_order')
              .order('sort_order', { ascending: true });

          if (error) throw error;

          return res.status(200).json({ stickers: stickers || [] });
      } catch (err) {
          console.warn('[sticker-assets]', err);
          return res.status(500).json({ error: 'Failed to load sticker assets' });
      }

  } catch (err) {
      try { reportApiError(err, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
    console.warn('[API Error]', err);
    if (!res.headersSent) return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}
