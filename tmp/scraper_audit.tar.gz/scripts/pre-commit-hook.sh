#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# PRE-COMMIT HOOK: Combined Safety Gate
# ═══════════════════════════════════════════════════════════════════════════════
#
# CHECK A: Club Arena Build Enforcement
#   Blocks any commit that touches public/hub/club-arena/ UNLESS it was
#   triggered by scripts/build-club-arena.sh.
#
# CHECK B: Merge / Stash Conflict Marker Detection  ★ CRITICAL ★
#   Blocks commits containing <<<<<<< / ======= / >>>>>>> markers.
#   These cause "Module parse failed" Vercel build failures that are
#   extremely hard to diagnose. See April 2026 incident (7 files corrupted).
#
# CHECK C: Dangerous Supabase Auth Pattern Detection
#   Blocks commits containing supabase.auth.getUser() or getSession()
#   (must use authUtils.ts safe wrappers instead).
#
# TO BYPASS (emergency only):
#   git commit --no-verify -m "message"
# ═══════════════════════════════════════════════════════════════════════════════

# ─── CHECK A: Club Arena Build Enforcement ───────────────────────────────────
ARENA_PATH="public/hub/club-arena/"

ARENA_STAGED=$(git diff --cached --name-only | grep "^${ARENA_PATH}" | wc -l | tr -d ' ')

if [ "$ARENA_STAGED" -gt 0 ]; then
    if [ "${ARENA_BUILD:-0}" = "1" ]; then
        echo "[pre-commit] ✓ Club Arena build script authorized — $ARENA_STAGED files committed"
    else
        echo ""
        echo "╔══════════════════════════════════════════════════════════════╗"
        echo "║  🚫  CLUB ARENA DIRECT COMMIT BLOCKED                       ║"
        echo "╠══════════════════════════════════════════════════════════════╣"
        echo "║                                                              ║"
        echo "║  You are trying to commit $ARENA_STAGED files in:                   ║"
        echo "║    public/hub/club-arena/                                    ║"
        echo "║                                                              ║"
        echo "║  Direct commits to this directory are FORBIDDEN.            ║"
        echo "║  They cause phantom pending changes (the 792-commit bug).   ║"
        echo "║                                                              ║"
        echo "║  THE ONLY AUTHORIZED WAY TO DEPLOY CLUB ARENA:             ║"
        echo "║                                                              ║"
        echo "║    bash scripts/build-club-arena.sh \"your message\"          ║"
        echo "║                                                              ║"
        echo "║  That script builds → cleans → copies → commits → pushes   ║"
        echo "║  atomically, preventing all stale artifact accumulation.    ║"
        echo "║                                                              ║"
        echo "╚══════════════════════════════════════════════════════════════╝"
        echo ""
        echo "Blocked files (first 10):"
        git diff --cached --name-only | grep "^${ARENA_PATH}" | head -10
        echo ""
        exit 1
    fi
fi

# ─── CHECK B: Merge / Stash Conflict Marker Detection ───────────────────────
# ★ CRITICAL — This check alone prevents the April 2026 "Module parse failed"
# incident that took down Vercel deployments for hours. Conflict markers from
# git merge, git stash pop, or git rebase are syntactically invalid JS/TS and
# cause opaque SWC parser errors that are nearly impossible to trace back to
# the source file without manual grep auditing.
# ─────────────────────────────────────────────────────────────────────────────
FILES=$(git diff --cached --name-only --diff-filter=ACM | grep -E '\.(js|jsx|ts|tsx|json|css)$' | grep -v 'public/hub/club-arena/assets/' | grep -v 'node_modules/')

CONFLICT_FAIL=0
if [ -n "$FILES" ]; then
    for file in $FILES; do
        # Check for all three types of conflict markers:
        #   <<<<<<< (merge/stash start)
        #   ======= (divider — only block if exactly 7 '=' on a line by itself)
        #   >>>>>>> (merge/stash end)
        if git show ":$file" 2>/dev/null | grep -qE '^<{7} |^>{7} '; then
            echo "🚫 CONFLICT MARKER: $file"
            # Show the offending lines for quick diagnosis
            git show ":$file" 2>/dev/null | grep -nE '^<{7} |^={7}$|^>{7} ' | head -6
            CONFLICT_FAIL=1
        fi
    done
fi

if [ $CONFLICT_FAIL -eq 1 ]; then
    echo ""
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║  🚫  GIT CONFLICT MARKERS DETECTED                         ║"
    echo "╠══════════════════════════════════════════════════════════════╣"
    echo "║                                                              ║"
    echo "║  One or more staged files contain unresolved conflict        ║"
    echo "║  markers (<<<<<<< / ======= / >>>>>>>).                     ║"
    echo "║                                                              ║"
    echo "║  These cause 'Module parse failed' errors on Vercel that     ║"
    echo "║  are extremely hard to diagnose.                             ║"
    echo "║                                                              ║"
    echo "║  FIX: Open the flagged files, resolve the conflicts, then   ║"
    echo "║  stage and commit again.                                     ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""
    exit 1
fi

# ─── CHECK C: Dangerous Supabase Auth Patterns ──────────────────────────────
echo "🔍 Scanning for dangerous Supabase auth patterns..."

# Re-filter to just JS/TS files (excluding allowlisted utility files)
AUTH_FILES=$(git diff --cached --name-only --diff-filter=ACM | grep -E '\.(js|jsx|ts|tsx)$' | grep -v 'public/hub/club-arena/assets/' | grep -v 'authUtils' | grep -v 'AvatarContext' | grep -v 'safeSupabase' | grep -v 'eslint-plugin')

if [ -z "$AUTH_FILES" ]; then
    echo "✅ No relevant files to check"
    exit 0
fi

DANGEROUS=0
for file in $AUTH_FILES; do
    if git show ":$file" 2>/dev/null | grep -q 'supabase\.auth\.getUser'; then
        echo "🚫 BLOCKED: $file contains supabase.auth.getUser()"
        echo "   Use: import { getAuthUser } from '@/lib/authUtils'"
        DANGEROUS=1
    fi
    if git show ":$file" 2>/dev/null | grep -q 'supabase\.auth\.getSession'; then
        echo "🚫 BLOCKED: $file contains supabase.auth.getSession()"
        echo "   Use: import { getAuthUser } from '@/lib/authUtils'"
        DANGEROUS=1
    fi
done

if [ $DANGEROUS -eq 1 ]; then
    echo ""
    echo "❌ Commit blocked! Remove dangerous Supabase auth calls."
    echo "   See: src/lib/authUtils.ts for safe alternatives"
    exit 1
fi

echo "✅ All checks passed (conflict markers, auth patterns)"
exit 0
