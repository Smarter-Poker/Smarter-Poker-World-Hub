/**
 * SeriesTabPanel — Extracted from poker-near-me.js renderSeries() + renderSeriesCalendar()
 * Series listing with search, state filter, grid/calendar toggle, and paginated grid.
 */
import React from 'react';
import dynamic from 'next/dynamic';

const SeriesCard = dynamic(() => import('./NewSeriesVenueCard'), { ssr: false });

const US_STATES = ['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY','DC'];

const TOUR_COLORS = {
    'WSOP': { bg: 'linear-gradient(135deg, #c9a227, #8b6914)', text: '#000', border: '#c9a227' },
    'WPT': { bg: 'linear-gradient(135deg, #dc2626, #991b1b)', text: '#fff', border: '#dc2626' },
    'WSOPC': { bg: 'linear-gradient(135deg, #c9a227, #8b6914)', text: '#000', border: '#c9a227' },
    'MSPT': { bg: 'linear-gradient(135deg, #1e40af, #1e3a8a)', text: '#fff', border: '#3b82f6' },
    'RGPS': { bg: 'linear-gradient(135deg, #059669, #047857)', text: '#fff', border: '#10b981' },
    'PGT': { bg: 'linear-gradient(135deg, #7c3aed, #5b21b6)', text: '#fff', border: '#8b5cf6' },
    'default': { bg: 'linear-gradient(135deg, #374151, #1f2937)', text: '#fff', border: '#4b5563' }
};

/**
 * Parse a date-only string ('2026-08-01') as a LOCAL date.
 * `new Date('2026-08-01')` is parsed as UTC midnight, which in every US timezone
 * reads back as the PREVIOUS day via getFullYear/getMonth/getDate — shifting every
 * series one day early on the calendar. Building the Date from parts avoids that.
 */
function parseLocalDate(value) {
    if (!value) return null;
    const m = String(value).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
}

function SeriesCalendar({ series, router, openVenueModal }) {
    const today = new Date();
    const months = [];
    for (let m = 0; m < 4; m++) {
        const d = new Date(today.getFullYear(), today.getMonth() + m, 1);
        months.push({ year: d.getFullYear(), month: d.getMonth(), label: d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) });
    }

    return (
        <div className="calendar-view">
            {months.map((mo, mi) => {
                const daysInMonth = new Date(mo.year, mo.month + 1, 0).getDate();
                const firstDay = new Date(mo.year, mo.month, 1).getDay();
                const monthSeries = series.filter(s => {
                    if (!s.start_date) return false;
                    const start = parseLocalDate(s.start_date);
                    if (!start) return false;
                    const end = parseLocalDate(s.end_date) || start;
                    const moStart = new Date(mo.year, mo.month, 1);
                    const moEnd = new Date(mo.year, mo.month + 1, 0);
                    return start <= moEnd && end >= moStart;
                });

                return (
                    <div key={mi} className="calendar-month">
                        <h3 className="calendar-month-title">{mo.label}</h3>
                        <div className="calendar-grid-header">
                            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                                <div key={d} className="cal-header-cell">{d}</div>
                            ))}
                        </div>
                        <div className="calendar-grid-body">
                            {Array.from({ length: firstDay }).map((_, i) => (
                                <div key={'empty-' + i} className="cal-cell empty"></div>
                            ))}
                            {Array.from({ length: daysInMonth }).map((_, di) => {
                                const dayNum = di + 1;
                                const dayDate = new Date(mo.year, mo.month, dayNum);
                                const daySeries = monthSeries.filter(s => {
                                    const start = parseLocalDate(s.start_date);
                                    if (!start) return false;
                                    const end = parseLocalDate(s.end_date) || start;
                                    return dayDate >= new Date(start.getFullYear(), start.getMonth(), start.getDate()) &&
                                        dayDate <= new Date(end.getFullYear(), end.getMonth(), end.getDate());
                                });
                                const isToday = dayDate.toDateString() === today.toDateString();
                                return (
                                    <div key={dayNum} className={'cal-cell' + (isToday ? ' today' : '') + (daySeries.length > 0 ? ' has-events' : '')}>
                                        <span className="cal-day-num">{dayNum}</span>
                                        {daySeries.slice(0, 2).map((s, si) => {
                                            const tourColor = TOUR_COLORS[s.tour_code] || TOUR_COLORS.default;
                                            return (
                                                <div key={s.id || si} className="cal-event"
                                                    style={{ background: tourColor.border, color: tourColor.text === '#000' ? '#000' : '#fff', cursor: s.id ? 'pointer' : 'default' }}
                                                    onClick={() => {
                                                        // No id — navigating to a positional index lands on an unrelated series
                                                        if (!s.id) return;
                                                        const path = '/hub/series/' + s.id;
                                                        if (openVenueModal) openVenueModal(path); else router.push(path);
                                                    }}
                                                    title={s.name}>
                                                    {(s.tour_code || s.short_name || '').slice(0, 5)}
                                                </div>
                                            );
                                        })}
                                        {daySeries.length > 2 && <div className="cal-more">+{daySeries.length - 2}</div>}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                );
            })}
        </div>
    );
}

export default function SeriesTabPanel({
    series,
    filters,
    setFilters,
    displayCount,
    loadMore,
    seriesViewMode,
    setSeriesViewMode,
    isFavorited,
    toggleFavorite,
    router,
    openVenueModal,
}) {
    const seriesStateVal = filters.hubSeriesState || 'all';
    let filteredSeries = series;
    if (seriesStateVal !== 'all') {
        filteredSeries = filteredSeries.filter(s => s.state === seriesStateVal);
    }

    return (
        <>
            {/* State Filter */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                <select value={seriesStateVal}
                    onChange={(e) => setFilters(f => ({ ...f, hubSeriesState: e.target.value }))}
                    className="sort-select" style={{ minWidth: 100 }}>
                    <option value="all">All States</option>
                    {US_STATES.map(st => (
                        <option key={st} value={st}>{st}</option>
                    ))}
                </select>
            </div>
            <div className="results-bar">
                <span className="results-count"><span style={{ color: '#ffffff', fontWeight: 800 }}>{filteredSeries.length}</span> series</span>
                <div className="view-toggle">
                    <button className={'view-btn' + (seriesViewMode === 'grid' ? ' active' : '')} onClick={() => setSeriesViewMode('grid')}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /></svg>
                        Grid
                    </button>
                    <button className={'view-btn' + (seriesViewMode === 'calendar' ? ' active' : '')} onClick={() => setSeriesViewMode('calendar')}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>
                        Calendar
                    </button>
                </div>
            </div>

            {filteredSeries.length === 0 ? (
                <div className="empty-state">
                    <p>No Matching Series</p>
                    <p style={{ fontSize: 13, opacity: 0.5, marginTop: 4 }}>{seriesStateVal !== 'all' ? 'Try adjusting your filters.' : 'Check back soon for poker series.'}</p>
                    <button onClick={() => setFilters(f => ({ ...f, hubSeriesState: 'all' }))}>Clear Series Filters</button>
                </div>
            ) : seriesViewMode === 'calendar' ? <SeriesCalendar series={filteredSeries} router={router} openVenueModal={openVenueModal} /> : (
                <>
                    <div className="card-grid">
                        {filteredSeries.slice(0, displayCount.series).map((s, i) => (
                            <SeriesCard
                                key={s.id || i}
                                series={s}
                                index={i}
                                isFavorited={s.id ? isFavorited('series', s.id) : false}
                                onFavorite={s.id ? ((e) => toggleFavorite('series', s.id, e)) : undefined}
                                onNavigate={(path) => openVenueModal ? openVenueModal(path) : router.push(path)}
                            />
                        ))}
                    </div>
                    {displayCount.series < filteredSeries.length && (
                        <div className="load-more">
                            <button className="load-more-btn" onClick={() => loadMore('series')}>
                                Load More ({filteredSeries.length - displayCount.series} remaining)
                            </button>
                        </div>
                    )}
                </>
            )}
        </>
    );
}
