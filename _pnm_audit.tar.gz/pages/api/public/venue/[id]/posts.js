/**
 * Public Venue Posts API
 * GET /api/public/venue/[id]/posts - Get public posts for a venue
 */
import { createClient } from '../../../../../src/lib/supabaseServerClient';
import { reportApiError } from '../../../../../src/lib/sentryWrap';

// NOTE: Removed edge runtime — this handler uses Node.js Pages Router API (req.query/res.status/etc)
// and cannot run on Vercel Edge Runtime. Keep as Node.js runtime.

let _supabase = null;
function getSupabase() {
    if (!_supabase) {
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://kuklfnapbkmacvwxktbh.supabase.co';
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
        _supabase = createClient(url, key);
    }
    return _supabase;
}

export default async function handler(req, res) {
  try {
    // CDN cache: fresh for 60s, serve stale up to 300s
    if (req.method === 'GET') {
      res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
    }

    if (req.method !== 'GET') {
      return res.status(405).json({
        success: false,
        error: { code: 'METHOD_NOT_ALLOWED', message: 'Only GET allowed' }
      });
    }

    try {
      const safeQ = (v) => v ? (Array.isArray(v) ? String(v[0]) : typeof v === 'object' ? null : String(v)) : v;
      const id = safeQ(req.query.id);
      const limit = safeQ(req.query.limit) || 20;
      const offset = safeQ(req.query.offset) || 0;

      if (!id) {
        return res.status(400).json({
          success: false,
          error: { code: 'MISSING_ID', message: 'Venue ID required' }
        });
      }

      // Fetch published posts from commander_venue_posts (Commander-managed venues)
      // Note: commander_venue_posts.venue_id may be integer, so UUID strings will cause a type error
      let posts = null;
      let count = null;
      const { data: cmdPosts, error: cmdError, count: cmdCount } = await getSupabase()
        .from('commander_venue_posts')
        .select(`
          id,
          author_name,
          content,
          post_type,
          image_urls,
          video_url,
          likes_count,
          comments_count,
          shares_count,
          is_pinned,
          created_at
        `, { count: 'exact' })
        .eq('venue_id', id)
        .eq('is_published', true)
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);

      // If no type error, use commander posts
      if (!cmdError) {
        posts = cmdPosts;
        count = cmdCount;
      }

      // If commander posts exist, return them
      if (posts && posts.length > 0) {
        return res.status(200).json({
          success: true,
          data: {
            posts,
            total: count,
            limit: parseInt(limit),
            offset: parseInt(offset)
          }
        });
      }

      // Fallback: check social_page_posts (social-media ClubPageDashboard posts)
      const { data: socialPosts, error: spError, count: spCount } = await getSupabase()
        .from('social_page_posts')
        .select(`
          id,
          author_id,
          content,
          content_type,
          media_urls,
          like_count,
          comment_count,
          share_count,
          is_pinned,
          created_at
        `, { count: 'exact' })
        .eq('page_id', id)
        .eq('is_approved', true)
        .eq('visibility', 'public')
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);

      if (spError) throw spError;

      // Map social_page_posts to the expected response shape
      const mappedPosts = (socialPosts || []).map(p => ({
        id: p.id,
        author_name: 'Venue',
        content: p.content,
        post_type: p.content_type || 'text',
        image_urls: Array.isArray(p.media_urls) ? p.media_urls.filter(u => typeof u === 'string') : [],
        video_url: null,
        likes_count: p.like_count || 0,
        comments_count: p.comment_count || 0,
        shares_count: p.share_count || 0,
        is_pinned: p.is_pinned || false,
        created_at: p.created_at,
      }));

      return res.status(200).json({
        success: true,
        data: {
          posts: mappedPosts,
          total: spCount,
          limit: parseInt(limit),
          offset: parseInt(offset)
        }
      });
    } catch (error) {
      console.warn('Public venue posts API error:', error);
      return res.status(500).json({
        success: false,
        error: { code: 'SERVER_ERROR', message: 'Failed to fetch posts' }
      });
    }

  } catch (err) {
      try { reportApiError(err, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
    console.warn('[API Error]', err);
    if (!res.headersSent) return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}
