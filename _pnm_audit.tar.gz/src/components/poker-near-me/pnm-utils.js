/**
 * pnm-utils.js — Shared utilities for Poker Near Me components
 * 
 * CONSOLIDATION: Previously, Haversine distance was duplicated across 4 files:
 *   - LiveGamesFeed.jsx (R=3959)
 *   - NearMeNowFeed.jsx (R=3958.8)
 *   - TripCostCalculator.jsx (R=3958.8)
 *   - RoadTripPlanner.jsx (R=3958.8)
 * 
 * This module provides the single source of truth.
 */

/**
 * Haversine formula — distance in miles between two lat/lng coordinates.
 * Uses the mean Earth radius 3958.8 miles (6,371 km).
 * 
 * @param {number} lat1 - Latitude of point 1
 * @param {number} lng1 - Longitude of point 1
 * @param {number} lat2 - Latitude of point 2
 * @param {number} lng2 - Longitude of point 2
 * @returns {number} Distance in miles
 */
export function haversineMiles(lat1, lng1, lat2, lng2) {
    if (lat1 == null || lng1 == null || lat2 == null || lng2 == null) return Infinity;
    const R = 3958.8;
    const toRad = (d) => (d * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 
        + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Relative time string from a date string.
 * 
 * @param {string|Date} dateStr - ISO date string or Date object
 * @returns {string} Human-readable relative time (e.g., "3m ago", "2h ago")
 */
export function timeAgo(dateStr) {
    if (!dateStr) return '';
    const ts = new Date(dateStr).getTime();
    if (isNaN(ts)) return '';
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 0) return 'Just now';
    if (diff < 30) return 'Just now';
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

/**
 * Activity heat level for visual theming of live venue cards.
 * 
 * @param {number} totalTables - Total number of tables running
 * @returns {{ color: string, label: string, border: string, bg: string }}
 */
export function getHeatLevel(totalTables) {
    if (totalTables >= 20) return { color: '#ef4444', label: 'HOT', border: 'rgba(239,68,68,0.5)', bg: 'rgba(239,68,68,0.08)' };
    if (totalTables >= 8) return { color: '#f59e0b', label: 'WARM', border: 'rgba(245,158,11,0.4)', bg: 'rgba(245,158,11,0.06)' };
    if (totalTables >= 3) return { color: '#3fb950', label: 'ACTIVE', border: 'rgba(63,185,80,0.4)', bg: 'rgba(63,185,80,0.06)' };
    return { color: '#ffffff', label: 'OPEN', border: 'rgba(255,255,255,0.3)', bg: 'rgba(255,255,255,0.05)' };
}

/**
 * Parse the minimum stake value from a game name string.
 * Handles formats like "1/2 No Limit Holdem", "5-10 NLH", "2/5 PLO".
 * 
 * @param {string} gameName - Game name containing stakes
 * @returns {number} The smaller stake value, or 0 if not parseable
 */
export function parseMinStake(gameName) {
    const match = (gameName || '').match(/(\d+)[\/\-](\d+)/);
    if (match) return Math.min(parseInt(match[1]), parseInt(match[2]));
    return 0;
}

// ─── NEW UTILITIES ───

export function getVenueLogoUrl(venue) {
    if (!venue) return null;
    // Priority 1: Supabase venue-logos bucket (hand-curated, verified logos)
    if (venue.logo_url) return venue.logo_url;
    // Priority 2: Profile photo from social page (scraped/external)
    if (venue.profile_photo_url) return venue.profile_photo_url;
    // Priority 3: Cover photo
    if (venue.cover_photo_url) return venue.cover_photo_url;
    
    // We intentionally removed the dynamic s2/favicons fallback here because it generates 
    // generic blue globes without byte-size validation. The backend daemon already tests 
    // Favicon API strictly, and injects verified ones into logo_url/profile_photo_url.
    return null;
}

export function getVenueLogoFallback(venue) {
    // Intentionally removed dynamic fallbacks like icon.horse
    // to force the monogram UI 
    return null;
}

/**
 * Parse operating hours and determine open/closed status.
 * Handles formats: "24/7", "12:00pm - 4:00am", "12pm-4am", etc.
 * 
 * @param {object} venue - Venue object with hours, hours_weekday, hours_weekend
 * @returns {{ open: boolean, label: string, always: boolean, nextChange: string|null } | null}
 */
export function getOpenStatus(venue) {
    if (!venue) return null;
    
    // Venue types that NEVER operate 24/7:
    // - Charity rooms always have cut-off times (legal requirement)
    // - Home games run on a schedule set by the host
    const NEVER_24_7_TYPES = ['charity', 'home_game'];
    const isNever24 = NEVER_24_7_TYPES.includes(venue.venue_type);
    
    // 24/7 venues — only for casinos, card rooms, poker clubs
    if (!isNever24 && (venue.is_24_hours || venue.hours === '24/7' || venue.hours_weekday === '24/7')) {
        return { open: true, label: 'Open 24/7', always: true, nextChange: null };
    }
    
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0=Sun, 6=Sat
    // [BUG FIX] dayOfWeek === 5 is FRIDAY, not a weekend day.
    // Saturday = 6, Sunday = 0. Friday erroneously used weekend_hours.
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    
    // Pick the right hours string
    let hoursStr = null;
    if (isWeekend && venue.hours_weekend) {
        hoursStr = venue.hours_weekend;
    } else if (venue.hours_weekday) {
        hoursStr = venue.hours_weekday;
    } else if (venue.hours) {
        hoursStr = venue.hours;
    }
    
    if (!hoursStr || hoursStr === '24/7') {
        // For charity/home_game: no hours data = show nothing (never assume 24/7)
        if (isNever24) return null;
        // For casinos/card_rooms/poker_clubs: safe to assume 24/7
        return { open: true, label: 'Open 24/7', always: true, nextChange: null };
    }
    
    // Parse "12:00pm - 4:00am" or "12pm-4am" or "10am - 2am" format
    const timePattern = /(\d{1,2})(?::(\d{2}))?\s*(am|pm)\s*[-–—to]+\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i;
    const match = hoursStr.match(timePattern);
    if (!match) return null;
    
    let openHour = parseInt(match[1]);
    const openMin = parseInt(match[2] || '0');
    const openAmPm = match[3].toLowerCase();
    let closeHour = parseInt(match[4]);
    const closeMin = parseInt(match[5] || '0');
    const closeAmPm = match[6].toLowerCase();
    
    // Convert to 24h
    if (openAmPm === 'pm' && openHour !== 12) openHour += 12;
    if (openAmPm === 'am' && openHour === 12) openHour = 0;
    if (closeAmPm === 'pm' && closeHour !== 12) closeHour += 12;
    if (closeAmPm === 'am' && closeHour === 12) closeHour = 0;
    
    const openMinutes = openHour * 60 + openMin;
    const closeMinutes = closeHour * 60 + closeMin;
    const nowMinutes = now.getHours() * 60 + now.getMinutes();
    
    let isOpen;
    if (closeMinutes > openMinutes) {
        // Same-day hours (e.g., 10am - 10pm)
        isOpen = nowMinutes >= openMinutes && nowMinutes < closeMinutes;
    } else {
        // Overnight hours (e.g., 12pm - 4am)
        isOpen = nowMinutes >= openMinutes || nowMinutes < closeMinutes;
    }
    
    // Format next change time
    const formatTime = (h, m) => {
        const hr = h % 12 || 12;
        const ampm = h >= 12 ? 'PM' : 'AM';
        return m > 0 ? `${hr}:${String(m).padStart(2, '0')} ${ampm}` : `${hr} ${ampm}`;
    };
    
    if (isOpen) {
        return {
            open: true,
            label: 'Open Now',
            always: false,
            nextChange: `Closes ${formatTime(closeHour, closeMin)}`,
        };
    } else {
        return {
            open: false,
            label: 'Closed',
            always: false,
            nextChange: `Opens ${formatTime(openHour, openMin)}`,
        };
    }
}

/**
 * Compute a crowd level from available data points.
 * Returns a 0-100 score and semantic label.
 * 
 * @param {object} venue - Venue with optional live_data, checkinCount
 * @param {number} [checkinCount] - Number of current check-ins
 * @returns {{ score: number, label: string, color: string }}
 */
export function getCrowdLevel(venue, checkinCount = 0) {
    let score = 0;
    
    // Live table data (0-50 points)
    if (venue?.live_data?.tables_running) {
        const tables = venue.live_data.tables_running;
        const maxTables = venue.poker_tables || 20;
        score += Math.min((tables / maxTables) * 50, 50);
    }
    
    // Waitlist data (0-30 points)
    if (venue?.live_data?.players_waiting) {
        score += Math.min(venue.live_data.players_waiting * 3, 30);
    }
    
    // Check-in data (0-20 points)
    if (checkinCount > 0) {
        score += Math.min(checkinCount * 5, 20);
    }
    
    score = Math.min(Math.round(score), 100);
    
    if (score >= 80) return { score, label: 'Packed', color: '#ef4444' };
    if (score >= 60) return { score, label: 'Busy', color: '#f59e0b' };
    if (score >= 35) return { score, label: 'Active', color: '#3fb950' };
    if (score >= 10) return { score, label: 'Quiet', color: '#ffffff' };
    return { score, label: 'Empty', color: '#6b7280' };
}

/**
 * Estimate wait time in minutes based on players waiting and game data.
 * Uses industry heuristic: ~15-20 min per waitlisted player at a given stake level.
 * 
 * @param {number} playersWaiting - Number of players on waitlist
 * @param {number} tablesRunning - Number of tables currently running
 * @returns {{ minutes: number, label: string }}
 */
export function estimateWaitTime(playersWaiting, tablesRunning = 1) {
    if (!playersWaiting || playersWaiting <= 0) {
        return { minutes: 0, label: 'No wait' };
    }
    // Heuristic: ~12 min per waiting player, scaled by table count
    // More tables = faster seat turnover
    const turnoverFactor = Math.max(1, tablesRunning * 0.3);
    const minutes = Math.round((playersWaiting * 12) / turnoverFactor);
    
    if (minutes <= 5) return { minutes, label: '< 5 min' };
    if (minutes <= 15) return { minutes, label: '~15 min' };
    if (minutes <= 30) return { minutes, label: '~30 min' };
    if (minutes <= 60) return { minutes, label: '~1 hour' };
    return { minutes, label: `~${Math.round(minutes / 60)}h ${minutes % 60}m` };
}

/**
 * Save PNM filter state to localStorage (cross-session persistence).
 * @param {string} key - Filter group key
 * @param {object} filters - Filter values to persist
 */
export function saveFilters(key, filters) {
    if (typeof window === 'undefined') return;
    try {
        localStorage.setItem(`pnm_filters_${key}`, JSON.stringify(filters));
    } catch { /* quota exceeded or private mode */ }
}

/**
 * Load PNM filter state from localStorage (cross-session persistence).
 * Falls back to sessionStorage for migration from older versions.
 * @param {string} key - Filter group key
 * @param {object} defaults - Default filter values
 * @returns {object} Merged filter values
 */
export function loadFilters(key, defaults) {
    if (typeof window === 'undefined') return defaults;
    try {
        // Primary: localStorage (new persistent storage)
        const saved = localStorage.getItem(`pnm_filters_${key}`);
        if (saved) return { ...defaults, ...JSON.parse(saved) };
        // Migration: check sessionStorage for existing data from old version
        const legacy = sessionStorage.getItem(`pnm_filters_${key}`);
        if (legacy) {
            const parsed = { ...defaults, ...JSON.parse(legacy) };
            // Migrate to localStorage and clean up sessionStorage
            localStorage.setItem(`pnm_filters_${key}`, legacy);
            sessionStorage.removeItem(`pnm_filters_${key}`);
            return parsed;
        }
    } catch { /* parse error */ }
    return defaults;
}

// ─── CURATED INITIALS COLOR PALETTE ───
const INITIALS_PALETTE = [
    { bg: 'rgba(255,255,255,0.25)', border: 'rgba(255,255,255,0.5)', text: '#ffffff' },   // Gold
    { bg: 'rgba(0,212,255,0.2)', border: 'rgba(0,212,255,0.5)', text: '#00d4ff' },       // Cyan
    { bg: 'rgba(239,68,68,0.2)', border: 'rgba(239,68,68,0.5)', text: '#ef4444' },       // Red
    { bg: 'rgba(34,197,94,0.2)', border: 'rgba(34,197,94,0.5)', text: '#22c55e' },       // Green
    { bg: 'rgba(139,92,246,0.2)', border: 'rgba(139,92,246,0.5)', text: '#8b5cf6' },     // Purple
    { bg: 'rgba(59,130,246,0.2)', border: 'rgba(59,130,246,0.5)', text: '#3b82f6' },     // Blue
    { bg: 'rgba(236,72,153,0.2)', border: 'rgba(236,72,153,0.5)', text: '#ec4899' },     // Pink
    { bg: 'rgba(245,158,11,0.2)', border: 'rgba(245,158,11,0.5)', text: '#f59e0b' },     // Amber
    { bg: 'rgba(20,184,166,0.2)', border: 'rgba(20,184,166,0.5)', text: '#14b8a6' },     // Teal
    { bg: 'rgba(249,115,22,0.2)', border: 'rgba(249,115,22,0.5)', text: '#f97316' },     // Orange
    { bg: 'rgba(168,85,247,0.2)', border: 'rgba(168,85,247,0.5)', text: '#a855f7' },     // Violet
    { bg: 'rgba(6,182,212,0.2)', border: 'rgba(6,182,212,0.5)', text: '#06b6d4' },       // Sky
];

/**
 * Get a curated color for venue initials based on venue ID.
 * Provides better visual diversity than random hash-based colors.
 * 
 * @param {number|string} venueId - Venue ID for consistent color mapping
 * @returns {{ bg: string, border: string, text: string }}
 */
export function getInitialsColor(venueId) {
    const idx = (typeof venueId === 'number' ? venueId : Math.abs(String(venueId).split('').reduce((a, c) => a + c.charCodeAt(0), 0))) % INITIALS_PALETTE.length;
    return INITIALS_PALETTE[idx];
}

/**
 * Check if venue data is stale (exceeds 30-minute threshold).
 * 
 * @param {string} lastUpdated - ISO timestamp of last data update
 * @returns {{ stale: boolean, age: string, minutes: number }}
 */
export function isStaleData(lastUpdated) {
    if (!lastUpdated) return { stale: true, age: 'No data', minutes: Infinity };
    const ts = new Date(lastUpdated).getTime();
    if (isNaN(ts)) return { stale: true, age: 'No data', minutes: Infinity };
    const minutes = Math.floor((Date.now() - ts) / 60000);
    const stale = minutes > 30;
    let age = '';
    if (minutes < 1) age = 'just now';
    else if (minutes < 60) age = `${minutes}m ago`;
    else age = `${Math.floor(minutes / 60)}h ${minutes % 60}m ago`;
    return { stale, age, minutes };
}

/**
 * Map a search radius (in miles) to an appropriate Leaflet zoom level.
 * Calibrated for US geography at mid-latitudes (~37°N).
 * 
 * Zoom levels approximate visible diameter:
 *   5 mi  → zoom 12 (neighborhood level)
 *   10 mi → zoom 11 (city district)
 *   25 mi → zoom 10 (metro area)
 *   50 mi → zoom 9  (metro region)
 *   100 mi → zoom 8 (multi-county)
 *   200 mi → zoom 7 (state-level)
 *   250 mi → zoom 6 (multi-state)
 *   500 mi → zoom 5 (regional US)
 *   'any'  → zoom 4 (continental US)
 * 
 * @param {number|string} radiusMiles - Radius in miles, or 'any'/'Any' for full US
 * @returns {number} Leaflet zoom level (4-12)
 */
export function radiusToZoom(radiusMiles) {
    // 'any' or invalid → show full US
    if (!radiusMiles || radiusMiles === 'any' || radiusMiles === 'Any') return 4;
    
    const miles = Number(radiusMiles);
    if (isNaN(miles) || miles <= 0) return 4;
    
    // Sorted lookup table: [maxRadius, zoomLevel]
    const ZOOM_TABLE = [
        [5, 12],
        [10, 11],
        [25, 10],
        [50, 9],
        [100, 8],
        [200, 7],
        [250, 6],
        [500, 5],
    ];
    
    for (const [maxMiles, zoom] of ZOOM_TABLE) {
        if (miles <= maxMiles) return zoom;
    }
    
    // Beyond 500 miles → full US overview
    return 4;
}

/**
 * Escape HTML special characters for safe injection into innerHTML strings.
 * Prevents XSS via venue names, tour names, or other user-facing data.
 */
export function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/**
 * Compute the Levenshtein distance between two strings.
 * Used for zero-latency fuzzy search on the client.
 */
export function levenshteinDistance(a, b) {
    if (!a?.length) return b?.length || 0;
    if (!b?.length) return a?.length || 0;
    
    const matrix = [];
    for (let i = 0; i <= b.length; i++) {
        matrix[i] = [i];
    }
    for (let j = 0; j <= a.length; j++) {
        matrix[0][j] = j;
    }
    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1, // substitution
                    Math.min(matrix[i][j - 1] + 1, // insertion
                             matrix[i - 1][j] + 1) // deletion
                );
            }
        }
    }
    return matrix[b.length][a.length];
}

/**
 * Fuzzy matches a search query against a target string.
 * Uses exact substring priority fallback to Levenshtein distance for typos.
 * Returns a score where lower is better (0 = exact match). Returns Infinity if no valid match.
 */
export function fuzzyMatchScore(query, target) {
    if (!query || !target) return Infinity;
    
    const q = query.toLowerCase().trim();
    const t = target.toLowerCase().trim();
    
    if (t === q) return 0;
    if (t.includes(q)) return q.length / t.length; // 0.1 to 0.9 depending on coverage
    
    // Check if any word in target matches query closely
    const targetWords = t.split(/\s+/);
    let bestDist = Infinity;
    
    for (const w of targetWords) {
        if (w.includes(q)) return 0.5;
        const dist = levenshteinDistance(q, w);
        // If typo is small relative to word length
        if (dist <= 2 && q.length >= 3) {
            bestDist = Math.min(bestDist, dist);
        }
    }
    
    // Overall string distance
    const totalDist = levenshteinDistance(q, t);
    if (totalDist <= 3 && q.length >= 4) {
        bestDist = Math.min(bestDist, totalDist);
    }
    
    return bestDist === Infinity ? Infinity : bestDist;
}

/**
 * Get the distance (in miles) from a user location to the nearest stop of a poker tour.
 * Tours may have a direct lat/lng, a headquarters location, or an array of stops.
 *
 * @param {object} tour - Tour object (may have latitude/longitude, stops, venues arrays)
 * @param {{ lat: number, lng: number }} userLocation - User's GPS coordinates
 * @returns {number|null} Distance in miles to the nearest tour stop, or null if no coordinates
 */
export function getNearestTourDistance(tour, userLocation) {
    if (!tour || !userLocation?.lat || !userLocation?.lng) return null;

    let minDist = null;

    // Direct lat/lng on the tour object (headquarters or primary location)
    if (tour.latitude != null && tour.longitude != null) {
        const d = haversineMiles(userLocation.lat, userLocation.lng, tour.latitude, tour.longitude);
        if (isFinite(d)) minDist = d;
    }

    // Array of stops or venues with their own coordinates
    const stopArrays = [tour.stops, tour.venues, tour.tour_stops].filter(Array.isArray);
    for (const arr of stopArrays) {
        for (const stop of arr) {
            if (stop?.latitude != null && stop?.longitude != null) {
                const d = haversineMiles(userLocation.lat, userLocation.lng, stop.latitude, stop.longitude);
                if (isFinite(d) && (minDist === null || d < minDist)) minDist = d;
            }
        }
    }

    return minDist;
}

