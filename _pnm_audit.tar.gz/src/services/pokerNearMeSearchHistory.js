/**
 * Poker Near Me Search History Service
 * Tracks user's search history for poker venues
 */

import { supabase } from '../lib/supabase';

/**
 * Get search history for a user
 */
export async function getSearchHistory(userId, limit = 20) {
    const { data, error } = await supabase
        .from('poker_near_me_search_history')
        .select('*')
        .eq('user_id', userId)
        .order('searched_at', { ascending: false })
        .limit(limit);

    if (error) {
        console.warn('Error fetching search history:', error);
        throw error;
    }

    return data || [];
}

/**
 * Add a search query to history
 */
export async function addSearchHistory(userId, searchQuery, searchData = {}) {
    if (!userId || !searchQuery) return null;

    const { data, error } = await supabase
        .from('poker_near_me_search_history')
        .upsert({
            user_id: userId,
            search_query: searchQuery,
            searched_at: new Date().toISOString()
        }, { onConflict: 'user_id,search_query', ignoreDuplicates: false })
        .select()
        .maybeSingle();

    if (error) {
        console.warn('Error adding search history:', error);
        throw error;
    }

    return data || null;
}

/**
 * Clear search history
 */
export async function clearSearchHistory(userId) {
    const { error } = await supabase
        .from('poker_near_me_search_history')
        .delete()
        .eq('user_id', userId);

    if (error) {
        console.warn('Error clearing search history:', error);
        throw error;
    }

    return true;
}

/**
 * Remove a specific search from history
 */
export async function removeSearchHistory(userId, searchId) {
    const { error } = await supabase
        .from('poker_near_me_search_history')
        .delete()
        .eq('user_id', userId)
        .eq('id', searchId);

    if (error) {
        console.warn('Error removing search history:', error);
        throw error;
    }

    return true;
}
