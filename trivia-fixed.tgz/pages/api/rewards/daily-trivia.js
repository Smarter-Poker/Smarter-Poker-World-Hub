/**
 * DAILY TRIVIA CHALLENGE REWARD API
 * ═══════════════════════════════════════════════════════════════════════════
 * Awards diamonds for COMPLETING the daily trivia challenge (any score).
 * Uses diamond_reward_claims for dedup.
 *
 * ANTI-FARMING SAFEGUARDS:
 *  0. Proof of play — a completed daily play must exist for today's CST date.
 *     (Previously absent: any authenticated user could curl this endpoint once
 *     a day forever and collect diamonds without opening the trivia page.)
 *  1. Account must be 24+ hours old — fails CLOSED when the age is unknown.
 *  2. One claim per calendar day (CST), enforced by check + unique index.
 *  3. Per-user daily diamond cap across all reward types.
 *  4. Platform-wide daily budget for this reward type.
 *
 * Idempotency: the claim row (user_id, reward_type, claim_date) is the dedup
 * key and the RPC reference_id is derived from it, so a retry after a lost
 * response cannot double-credit. The dedup bucket is a DAY, not a minute —
 * a minute-bucketed key would let a determined caller re-claim 1,440x/day.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { createClient } from '../../../src/lib/supabaseServerClient';
import { applyRateLimit, LIMITS } from '../../../src/lib/apiRateLimit';
import { reportApiError } from '../../../src/lib/sentryWrap';
import { getTodayCST } from '../../../src/lib/trivia/getTodayCST';

const TRIVIA_REWARD = 15;
/** Per-user cap across every reward type, per CST day. */
const PER_USER_DAILY_CAP = 500;
/** Platform-wide cap on daily_trivia claims per CST day (defence in depth). */
const GLOBAL_DAILY_CLAIM_LIMIT = Number(process.env.TRIVIA_REWARD_GLOBAL_DAILY_LIMIT) || 50000;
const MIN_ACCOUNT_AGE_MS = 24 * 60 * 60 * 1000;

let _supabase = null;
let _warnedNoServiceRole = false;
function getSupabase() {
    if (!_supabase) {
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://kuklfnapbkmacvwxktbh.supabase.co';
        const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!serviceKey && !_warnedNoServiceRole) {
            _warnedNoServiceRole = true;
            console.warn('[DailyTrivia] SUPABASE_SERVICE_ROLE_KEY missing — RLS reads/writes will silently fail');
        }
        _supabase = createClient(url, serviceKey || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
    }
    return _supabase;
}

/**
 * Did this user actually complete today's daily trivia?
 * Accepts either write path (the hub pages write daily_trivia_plays directly;
 * the submit API writes trivia_scores).
 */
async function hasCompletedTodaysTrivia(supabase, userId, today) {
    const [{ data: play }, { data: scoreRow }] = await Promise.all([
        supabase
            .from('daily_trivia_plays')
            .select('id')
            .eq('user_id', userId)
            .eq('played_date', today)
            .maybeSingle(),
        supabase
            .from('trivia_scores')
            .select('id')
            .eq('user_id', userId)
            .eq('play_date', today)
            .limit(1)
            .maybeSingle(),
    ]);
    return !!play || !!scoreRow;
}

export default async function handler(req, res) {
  try {
    if (['POST','PUT','PATCH','DELETE'].includes(req.method)) {
      if (!applyRateLimit(req, res, LIMITS.write)) return;
    }

      const supabase = getSupabase();
      if (req.method !== 'POST') {
          res.setHeader('Allow', 'POST');
          return res.status(405).json({ error: 'Method not allowed' });
      }

      // ── Auth: JWT required (awards diamonds) ──
      const authHeader = req.headers.authorization;
      if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'Auth required' });
      const token = authHeader.slice(7).trim();
      if (!token) return res.status(401).json({ error: 'Auth required' });
      const { data: authData, error: authErr } = await supabase.auth.getUser(token);
      const authUser = authData?.user;
      if (authErr || !authUser?.id) return res.status(401).json({ error: 'Invalid token' });

      const userId = authUser.id; // Use JWT identity — never a body-supplied id
      const now = new Date();
      const today = getTodayCST(now);

      try {
          // ── SAFEGUARD 0: proof of play ──────────────────────────────────
          const played = await hasCompletedTodaysTrivia(supabase, userId, today);
          if (!played) {
              return res.status(403).json({
                  claimed: false,
                  reason: 'No completed trivia play found for today',
                  diamondsAwarded: 0,
              });
          }

          // ── SAFEGUARD 1: account age (24 hours minimum), FAIL CLOSED ────
          // Guarding this with `if (userProfile?.created_at)` let brand-new
          // accounts with no profile row skip the check entirely — precisely
          // the accounts the safeguard exists to stop.
          const { data: userProfile } = await supabase
              .from('profiles')
              .select('created_at')
              .eq('id', userId)
              .maybeSingle();

          const createdAt = userProfile?.created_at || authUser.created_at || null;
          if (!createdAt) {
              return res.status(200).json({ claimed: false, reason: 'Account too new', diamondsAwarded: 0 });
          }
          const createdMs = new Date(createdAt).getTime();
          if (!Number.isFinite(createdMs) || (now.getTime() - createdMs) < MIN_ACCOUNT_AGE_MS) {
              return res.status(200).json({ claimed: false, reason: 'Account too new', diamondsAwarded: 0 });
          }

          // ── SAFEGUARD 2: already claimed today? ─────────────────────────
          const { data: existingClaim } = await supabase
              .from('diamond_reward_claims')
              .select('id')
              .eq('user_id', userId)
              .eq('reward_type', 'daily_trivia')
              .eq('claim_date', today)
              .maybeSingle();

          if (existingClaim) {
              return res.status(200).json({ claimed: false, reason: 'Already claimed today', diamondsAwarded: 0 });
          }

          // ── SAFEGUARD 3: PER-USER daily cap across reward types ─────────
          // (This was labelled "Global daily cap" but filters by user_id — the
          // documented platform-wide property did not exist. It does now, as
          // safeguard 4.)
          const { data: todayClaims } = await supabase
              .from('diamond_reward_claims')
              .select('diamonds_awarded')
              .eq('user_id', userId)
              .eq('claim_date', today);

          const todayTotal = (todayClaims || []).reduce((sum, c) => sum + (c.diamonds_awarded || 0), 0);
          if (todayTotal >= PER_USER_DAILY_CAP) {
              return res.status(200).json({ claimed: false, reason: 'Daily cap reached', diamondsAwarded: 0 });
          }

          // ── SAFEGUARD 4: platform-wide daily budget ─────────────────────
          const { count: globalClaims } = await supabase
              .from('diamond_reward_claims')
              .select('id', { count: 'exact', head: true })
              .eq('reward_type', 'daily_trivia')
              .eq('claim_date', today);

          if ((globalClaims || 0) >= GLOBAL_DAILY_CLAIM_LIMIT) {
              console.warn('[DailyTrivia] platform daily budget exhausted:', globalClaims);
              return res.status(200).json({ claimed: false, reason: 'Daily reward budget exhausted', diamondsAwarded: 0 });
          }

          const diamonds = Math.min(TRIVIA_REWARD, PER_USER_DAILY_CAP - todayTotal);
          if (diamonds <= 0) {
              return res.status(200).json({ claimed: false, reason: 'Daily cap reached', diamondsAwarded: 0 });
          }

          // ── INSERT CLAIM (the idempotency key) ──────────────────────────
          const { error: claimError } = await supabase
              .from('diamond_reward_claims')
              .insert({
                  user_id: userId,
                  reward_type: 'daily_trivia',
                  diamonds_awarded: diamonds,
                  claim_date: today,
                  metadata: { source: 'daily_trivia_challenge' }
              });

          if (claimError) {
              // Unique constraint = already claimed (concurrent request won)
              if (claimError.code === '23505') {
                  return res.status(200).json({ claimed: false, reason: 'Already claimed', diamondsAwarded: 0 });
              }
              throw claimError;
          }

          // ── CREDIT DIAMONDS (atomic: balance + transaction in one RPC) ──
          // Stable, DAY-scoped reference_id: if the RPC commits but response
          // delivery fails, the rollback below lets the user retry and the RPC
          // dedups on the same reference_id instead of double-crediting.
          const { error: rpcError } = await supabase.rpc('add_diamonds_to_balance', {
              p_user_id: userId,
              p_amount: diamonds,
              p_type: 'daily_trivia',
              p_description: `Daily Trivia Challenge reward — ${diamonds} diamonds`,
              p_reference_id: `daily_trivia_${userId}_${today}`
          });

          if (rpcError) {
              // Roll back the idempotency claim row so the user can retry.
              // Without this, safeguard 2 returns "already claimed today"
              // forever and the user never receives their diamonds.
              try {
                  const { error: rollbackDbErr } = await supabase
                    .from('diamond_reward_claims')
                    .delete()
                      .eq('user_id', userId)
                      .eq('reward_type', 'daily_trivia')
                      .eq('claim_date', today);
                  if (rollbackDbErr) console.warn('[DailyTrivia] rollback delete failed:', rollbackDbErr.message);
              } catch (rollbackErr) {
                  console.warn('[DailyTrivia] Rollback delete failed:', rollbackErr?.message || rollbackErr);
              }
              console.warn('[DailyTrivia] RPC error (claim rolled back so user can retry):', rpcError);
              return res.status(500).json({ error: 'Failed to credit diamonds — please retry' });
          }

          return res.status(200).json({
              claimed: true,
              diamondsAwarded: diamonds,
              reward: 'daily_trivia'
          });

      } catch (error) {
          console.warn('Daily trivia reward error:', error);
          try { reportApiError(error, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
          return res.status(500).json({ error: 'Internal server error' });
      }

  } catch (err) {
      try { reportApiError(err, req); } catch (_sentryErr) { console.warn('[App] Handled exception:', _sentryErr?.message || _sentryErr); }
    console.warn('[API Error]', err);
    if (!res.headersSent) return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}
